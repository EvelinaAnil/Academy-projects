<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'practisecrud');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('COOKIE_NAME', 'user_cookie');
?>
