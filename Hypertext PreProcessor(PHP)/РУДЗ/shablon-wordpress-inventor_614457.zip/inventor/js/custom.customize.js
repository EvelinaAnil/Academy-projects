jQuery(document).ready(function(e) {
    jQuery('.accordion-section-title').eq(0).after('<a style="position:relative;left:15px;padding:2px 10px;bottom:31px;background:#efc62c;color:#ffffff;" href="https://flythemes.net/wordpress-themes/inventor-wordpress-theme/" target="_blank">'+ inventorjsvar.upgrade +'</a>');
	jQuery('.accordion-section-title').eq(0).css('padding-bottom','35px');
});