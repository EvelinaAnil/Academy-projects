<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HW_1_Als_Wikki</title>
</head>
<style>
    body{
        font-size: larger;
        font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }
</style>

<body>
    <?php
    include ('Login.php');
    ?>

    <?php
    echo '<h4 style="color:rgb(173, 173, 173); size: 4%;">Эта статья — об интерфейсах программирования.</h4>
    <h2 style="color:blue; size: 9%;">API</h2>';
    echo '<div> <a href="https://ru.wikipedia.org/wiki/API"> <b style="color:blue;" >API</b> </a> (от англ. <b style="color:blue;">Application Programming Interface</b>) — описание способов взаимодействия одной компьютерной программы с другими. Обычно входит в описание какого-либо <a href="/wiki/%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82-%D0%BF%D1%80%D0%BE%D1%82%D0%BE%D0%BA%D0%BE%D0%BB">интернет-протокола</a>  
    (например, SCIM), программного каркаса (
       <a href="/wiki/%D0%A4%D1%80%D0%B5%D0%B9%D0%BC%D0%B2%D0%BE%D1%80%D0%BA">фреймворка</a> 
       ) или стандарта вызовов функций операционной системы. Часто реализуется отдельной
       <a href="https://ru.wikipedia.org/wiki/%D0%91%D0%B8%D0%B1%D0%BB%D0%B8%D0%BE%D1%82%D0%B5%D0%BA%D0%B0_(%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5)">программной библиотекой</a>  или сервисом операционной системы. Используется программистами при написании всевозможных приложений.</div><br>
<div>Проще говоря, это набор компонентов, с помощью которых компьютерная программа (бот или же сайт) может использовать другую программу.</div><br>
<div>Если программу (модуль, библиотеку) рассматривать как чёрный ящик, то <a href="https://ru.wikipedia.org/wiki/API"> API</a> — это набор «ручек», которые доступны пользователю данного ящика и которые он может вертеть и переключать.</div><br>
<div> Понятие протокола близко по смыслу к понятию <a href="https://ru.wikipedia.org/wiki/API"> API</a>. И то, и другое является абстракцией функциональности, только в первом случае речь идёт о передаче данных, а во втором — о взаимодействии приложений. <a href="https://ru.wikipedia.org/wiki/API"> API</a> библиотеки функций и классов включает в себя описание сигнатур и семантики функций.</div><br>
';
    
    ?>






</body>
</html>