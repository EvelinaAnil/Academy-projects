<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $antwoord = $_POST['antwoord'];
    ?>

   <?php 
   if ($antwoord == null){
    echo 'You didn not get aт antwoord yet...';
   }
    ?>
    
    <?php if ($antwoord != null){
         echo "Antwoord:<br>$antwoord";
    }
   ?>
    <form action="AntwoordDo.php" method="POST">
    <input type="submit" value="Send antwoord">
    </form>
</body>
</html>