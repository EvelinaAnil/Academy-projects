<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Antwoord</title>
</head>
<body>
<form action="Antwoord.php" method="POST">
    <label for="antwoord">Antwoord: </label>
    <input type="text" name="antwoord"> <br>
    <input type="submit" value="See antwoord">
    
    </form>
</body>
</html>