<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message</title>
</head>
<style>
    span{
        display: none;
    }
</style>
<body>
    <form action="Antwoord.php" method="POST">
    <label for="yourtext">Your Text: </label>
    <input type="text" name="yourtext"> <br>
   <span><label for="antwoord"></label>
    <input type="text" name="antwoord"> <br></span> 
    <input type="submit" value="See antwoord">
    
    </form>
</body>
</html>