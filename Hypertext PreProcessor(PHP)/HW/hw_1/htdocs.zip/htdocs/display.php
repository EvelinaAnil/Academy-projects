<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>display</title>
</head>
<body>
<form action="Login.php" method="POST">
    <?php
        $login = $_POST['login'];
        $password = $_POST['password'];
        echo "login: $login, password: $password</br>";
        //echo 'login: '.$login.', password: '.$password;
        
        echo "Спасибо за регестрацию, $login  на нашем сайте!</br>";
      
    ?>
    <input type="submit" value="Change login and password">
    </form>
    <form action="message.php" method="POST">
    <input type="submit" value="Send message">
    </form>
</body>
</html>