﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ConsoleUdpServer
{
	class Program
    {
        static void Main(string[] args)
        {
			try
			{
				using (UdpClient udpClient = new UdpClient(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 52345)))
				{
					Console.WriteLine("Waiting ...");

					IPEndPoint clientEP = null;
					byte[] bytes = udpClient.Receive(ref clientEP);

					Console.WriteLine($"Received {bytes.Length} bytes from {clientEP}");

					Console.WriteLine($"Message:\n\t{Encoding.UTF8.GetString(bytes)}");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			Console.ReadKey();
        }
    }
}
