﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ConsoleUdpClient
{
    class Program
    {
        /* ----------- 1 -----------
        static void Main(string[] args)
        {
            UdpClient udpClient = null;
            try
            {
                udpClient = new UdpClient();

                //// 1
                //IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 52345);
                //udpClient.Connect(remoteEP);

                ////2
                //udpClient.Connect(IPAddress.Parse("127.0.0.1"), 52345);

                //3
                udpClient.Connect("localhost", 52345);


                Console.WriteLine("Input message:");
                byte[] data = Encoding.UTF8.GetBytes(Console.ReadLine());

                udpClient.Send(data, data.Length);

                Console.WriteLine("Data sent!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                udpClient?.Close();
            }

            Console.ReadKey();
        }
        */

        /* ----------- 2 (without Connect()) -----------
        static void Main(string[] args)
        {
            try
            {
                using (UdpClient udpClient = new UdpClient(51112)) // local port
                {
                    Console.WriteLine("Input message:");
                    byte[] data = Encoding.UTF8.GetBytes(Console.ReadLine());

                    IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 52345);
                    udpClient.Send(data, data.Length, remoteEP);

                    Console.WriteLine("Data sent!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }*/

        /* ----------- 3 (without Connect()) -----------*/
        static void Main(string[] args)
        {
            try
            {
                using (UdpClient udpClient = new UdpClient(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 51112))) // local EP
                {
                    Console.WriteLine("Input message:");
                    byte[] data = Encoding.UTF8.GetBytes(Console.ReadLine());

                    udpClient.Send(data, data.Length, "localhost", 52345);

                    Console.WriteLine("Data sent!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }

        /* ----------- 4 (without Connect()) ----------- THIS DOESN'T WORK !!!!!
        static void Main(string[] args)
        {
            try
            {
                using (UdpClient udpClient = new UdpClient("localhost", 52345)) // remote
                {
                    Console.WriteLine("Input message:");
                    byte[] data = Encoding.UTF8.GetBytes(Console.ReadLine());

                    udpClient.Send(data, data.Length);

                    Console.WriteLine("Data sent!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }*/
    }
}
