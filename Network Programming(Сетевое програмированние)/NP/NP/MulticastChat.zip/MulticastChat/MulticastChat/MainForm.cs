﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MulticastChat
{
    // Class D: 224.0.0.0 - 239.255.255.255
    // 172.12.105.255

    public partial class MainForm : Form
    {
        private bool _done = true;
        private UdpClient _udpClient;
        private IPAddress _groupAddress;
        private int _localPort;
        private int _remotePort;
        private int _ttl;

        private IPEndPoint _remoteEP;
        private UTF8Encoding _encoding;
        private string _name;
        private string _message;

        public MainForm()
        {
            InitializeComponent();

            _encoding = new UTF8Encoding();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                NameValueCollection valueCollection = ConfigurationManager.AppSettings;
                _groupAddress = IPAddress.Parse(valueCollection["GroupAddress"]);
                _localPort = Convert.ToInt32(valueCollection["LocalPort"]); // int.Parse(...)
                _remotePort = Convert.ToInt32(valueCollection["RemotePort"]);
                _ttl = Convert.ToInt32(valueCollection["TTL"]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Close();
            }
        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {
            btnStart.Enabled = !string.IsNullOrWhiteSpace(tbName.Text);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                _udpClient = new UdpClient(_localPort);

                _udpClient.JoinMulticastGroup(_groupAddress, _ttl);

                _remoteEP = new IPEndPoint(_groupAddress, _remotePort);

                Task.Run(Listener);

                _name = tbName.Text;
                tbName.ReadOnly = true;
                tbMessage.Enabled = true;

                byte[] data = _encoding.GetBytes($"{_name} connected to chat");
                _udpClient.Send(data, data.Length, _remoteEP);

                btnStart.Enabled = false;
                btnStop.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Listener()
        {
            _done = false;
            try
            {
                while (!_done)
                {
                    IPEndPoint endPoint = null;
                    _message = _encoding.GetString(_udpClient.Receive(ref endPoint));

                    BeginInvoke(new Action(() =>
                    lbMessages.Items.Add($"{DateTime.Now.ToShortTimeString()} {_message}")
                    ));
                }
            }
            catch (SocketException se)
            {
                if (se.ErrorCode != 10004) // ignore WSACancelBlockingСаll (WINSOCK.DLL)
                {
                    MessageBox.Show(se.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tbMessage_TextChanged(object sender, EventArgs e)
        {
            btnSend.Enabled = !string.IsNullOrWhiteSpace(tbMessage.Text);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            lbMessages.Items.Add($"\t{DateTime.Now.ToShortTimeString()} {tbMessage.Text}");
            try
            {
                byte[] data = _encoding.GetBytes($"{_name}: {tbMessage.Text}");
                _udpClient.Send(data, data.Length, _remoteEP);
                
                tbMessage.Clear();
                tbMessage.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopListener();
        }

        private void StopListener()
        {
            byte[] data = _encoding.GetBytes($"{_name} left the chat");

            try
            {
                _udpClient.Send(data, data.Length, _remoteEP);
            }
            catch { }
            finally
            {
                _udpClient.DropMulticastGroup(_groupAddress);
                _udpClient.Close();

                _done = true;

                tbName.Clear();
                btnStart.Enabled = btnStop.Enabled = btnSend.Enabled = tbMessage.Enabled = tbName.ReadOnly = false;

                lbMessages.Items.Clear();
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!_done)
            {
                StopListener();
            }
        }
    }
}
