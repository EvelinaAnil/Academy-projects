﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsTcpServer
{
    public partial class Form1 : Form
    {
        private TcpListener _tcpListener;
        private string _message;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                _tcpListener = new TcpListener(IPAddress.Parse(tbIPAddress.Text), int.Parse(tbPort.Text));

                _tcpListener.Start();

                lblStatus.Text = "Server running!";

                btnStart.Text = "Stop";
                btnStart.Click -= btnStart_Click;
                btnStart.Click += btnStop_Click;

                Task.Run(AcceptThread);
            }
            catch (SocketException se)
            {
                MessageBox.Show($"Socket error: {se.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AcceptThread()
        {
            while (true)
            {
                try
                {
                    using (TcpClient client = _tcpListener.AcceptTcpClient())
                    {
                        using (StreamReader reader = new StreamReader(client.GetStream(), Encoding.UTF8))
                        {
                            _message = reader.ReadLine();

                            BeginInvoke(new Action(() => lbMessages.Items.Add(_message.Substring(0, _message.LastIndexOf("::")))));

                            using (TcpClient tcpClient = new TcpClient())
                            {
                                tcpClient.Connect((client.Client.RemoteEndPoint as IPEndPoint).Address, int.Parse(_message.Substring(_message.LastIndexOf("::") + 2)));

                                byte[] data = Encoding.UTF8.GetBytes("OK!");

                                using (NetworkStream stream = tcpClient.GetStream())
                                {
                                    stream.Write(data, 0, data.Length);
                                }
                            }
                        }
                    }
                }
                catch
                {
                    break;
                }
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _tcpListener?.Stop();
            _tcpListener = null;

            lblStatus.Text = "Server stopped";

            btnStart.Text = "Start";
            btnStart.Click -= btnStop_Click;
            btnStart.Click += btnStart_Click;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            _tcpListener?.Stop();
        }
    }
}