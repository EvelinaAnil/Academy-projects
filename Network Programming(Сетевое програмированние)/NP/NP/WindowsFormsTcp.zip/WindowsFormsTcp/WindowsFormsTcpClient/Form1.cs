﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsTcpClient
{
    public partial class Form1 : Form
    {
        private TcpClient _tcpClient;
        private TcpListener _tcpListener;
        private byte[] _data;
        private bool _isFirstSend = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void tbMessage_TextChanged(object sender, EventArgs e)
        {
            btnSend.Enabled = !string.IsNullOrWhiteSpace(tbMessage.Text);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if (_isFirstSend)
                {
                    _tcpListener = new TcpListener(IPAddress.Parse(tbIPAddress.Text), int.Parse(tbListenerPort.Text));
                    _tcpListener.Start();

                    _isFirstSend = false;
                }

                Task.Run(GetAnswer);

                _tcpClient = new TcpClient();

                _tcpClient.Connect(IPAddress.Parse(tbServerIPAddress.Text), int.Parse(tbServerPort.Text));

                _data = Encoding.UTF8.GetBytes($"{tbMessage.Text}::{int.Parse(tbListenerPort.Text)}");

                using (NetworkStream stream = _tcpClient.GetStream())
                {
                    stream.Write(_data, 0, _data.Length);
                }
            }
            catch (SocketException se)
            {
                MessageBox.Show($"Socket error: {se.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                tbMessage.Text = "";
                _tcpClient?.Close();
            }
        }

        private void GetAnswer()
        {
            try
            {
                using (TcpClient client = _tcpListener?.AcceptTcpClient())
                {
                    if (client != null)
                    {
                        using (StreamReader reader = new StreamReader(client.GetStream(), Encoding.UTF8))
                        {
                            MessageBox.Show(reader.ReadToEnd());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            _tcpListener?.Stop();
            _tcpClient?.Close();
        }
    }
}