﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace FileEncryptDecrypt
{
    public partial class Form1 : Form
    {
        private byte[] _iv = { 1, 2, 3, 4, 5, 6, 7, 8 };

        public Form1()
        {
            InitializeComponent();
        }

        private void btnFileEncrypt_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Text files(*.txt)|*.txt|Image files(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                tbEncrypt.Text = openFileDialog.FileName;
                btnEncrypt.Enabled = true;
            }
        }

        private void btnFileDecrypt_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Encrypted file (*.enc)|*.enc";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                tbDecrypt.Text = openFileDialog.FileName;
                btnDecrypt.Enabled = true;
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                //RC2CryptoServiceProvider
                //TripleDESCryptoServiceProvider
                DESCryptoServiceProvider serviceProvider = new DESCryptoServiceProvider
                {
                    Key = Encoding.UTF8.GetBytes(tbKey.Text),
                    IV = _iv
                };

                using (FileStream inFile = new FileStream(tbEncrypt.Text, FileMode.Open))
                {
                    using (FileStream outFile = new FileStream($"{tbEncrypt.Text}.enc", FileMode.Create))
                    {
                        using (CryptoStream stream = new CryptoStream(outFile, serviceProvider.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            byte[] data = new byte[inFile.Length];
                            inFile.Read(data, 0, data.Length);
                            stream.Write(data, 0, data.Length);
                        }
                    }
                }
                MessageBox.Show("Encryption done!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string path = $"D:{tbDecrypt.Text.Substring(tbDecrypt.Text.LastIndexOf('\\')).Replace(".enc", "")}";

                DESCryptoServiceProvider serviceProvider = new DESCryptoServiceProvider
                {
                    Key = Encoding.UTF8.GetBytes(tbKey.Text),
                    IV = _iv
                };

                using (FileStream inFile = new FileStream(tbDecrypt.Text, FileMode.Open))
                {
                    using (CryptoStream stream = new CryptoStream(inFile, serviceProvider.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        /*using (StreamWriter writer = new StreamWriter(path))
                        {
                            writer.Write(new StreamReader(stream).ReadToEnd());
                        }*/

                        using (FileStream outFile = new FileStream(path, FileMode.Create))
                        {
                            byte[] data = new byte[inFile.Length];
                            stream.Read(data, 0, data.Length);
                            outFile.Write(data, 0, data.Length);
                        }
                    }
                }

                MessageBox.Show("Decryption done!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}