﻿using System;

namespace FileDetailsLibrary
{
    [Serializable]
    public class FileDetails
    {
        public long FileSize { get; set; }
        public string FileType { get; set; }
    }
}
