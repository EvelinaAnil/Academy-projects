﻿using FileDetailsLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleUdpFileServer
{
    class Program
    {
        private static IPEndPoint _remoteEndPoint;
        private static UdpClient _udpClient;
        private static FileStream _fileStream;

        static Program()
        {
            _remoteEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 52673);
            _udpClient = new UdpClient();
        }

        static void Main(string[] args)
        {
            try
            {
                Console.Write("Input file name: ");
                //string path = @Console.ReadLine(); // @"C:\Test\test.pdf";
                _fileStream = new FileStream(@Console.ReadLine(), FileMode.Open, FileAccess.Read);

                SendFileInfo();

                Thread.Sleep(5000);

                SendFile();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                _fileStream?.Close();
                _udpClient?.Close();
            }

            Console.ReadKey();
        }

        private static void SendFileInfo()
        {
            try
            {
                // info
                // info. info
                // info.info.pdf
                if (!_fileStream.Name.Contains("."))
                {
                    throw new Exception("No extension!");
                }

                FileDetails fileDetails = new FileDetails
                {
                    FileSize = _fileStream.Length,
                    FileType = _fileStream.Name.Substring(_fileStream.Name.LastIndexOf(".") + 1)
                };

                BinaryFormatter formatter = new BinaryFormatter();

                using (MemoryStream stream = new MemoryStream())
                {
                    formatter.Serialize(stream, fileDetails);
                    stream.Position = 0;

                    byte[] bytes = new byte[stream.Length];
                    stream.Read(bytes, 0, bytes.Length);

                    _udpClient.Send(bytes, bytes.Length, _remoteEndPoint);

                    Console.WriteLine("File info sent!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                Console.ReadKey();

                Environment.Exit(-1);
            }
        }

        private static void SendFile()
        {
            try
            {
                byte[] bytes = new byte[_fileStream.Length];
                _fileStream.Read(bytes, 0, bytes.Length);

                _udpClient.Send(bytes, bytes.Length, _remoteEndPoint);

                Console.WriteLine($"Sent {_fileStream.Length} bytes!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
