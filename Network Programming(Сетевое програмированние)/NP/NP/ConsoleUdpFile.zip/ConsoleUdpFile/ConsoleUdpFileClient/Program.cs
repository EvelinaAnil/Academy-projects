﻿using FileDetailsLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUdpFileClient
{
    class Program
    {
        private static FileDetails _fileDetails;
        private static UdpClient _udpClient;
        private static IPEndPoint _iPEndPoint;
        private static byte[] _data;

        static Program()
        {
            _udpClient = new UdpClient(52673);
        }

        static void Main(string[] args)
        {
            if (GetFileDetails())
            {
                GetFile();
            }
            else
            {
                Console.WriteLine("File error!");
            }

            Console.ReadKey();
        }

        private static bool GetFileDetails()
        {
            try
            {
                Console.WriteLine("Waiting information ...");

                _data = _udpClient.Receive(ref _iPEndPoint);

                BinaryFormatter formatter = new BinaryFormatter();
                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(_data, 0, _data.Length);
                    stream.Position = 0;

                    _fileDetails = formatter.Deserialize(stream) as FileDetails;

                    Console.WriteLine($"File type {_fileDetails.FileType} size {_fileDetails.FileSize}");
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        private static void GetFile()
        {
            try
            {
                Console.WriteLine("File waiting ...");
                _data = _udpClient.Receive(ref _iPEndPoint);

                using (FileStream fileStream = new FileStream($"Temp.{_fileDetails.FileType}", FileMode.Create))
                {
                    fileStream.Write(_data, 0, _data.Length);

                    Console.WriteLine("File saved!");

                    Process.Start(fileStream.Name);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}