﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsHash
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tbMessage_TextChanged(object sender, EventArgs e)
        {
            btnHash.Enabled = !string.IsNullOrEmpty(tbMessage.Text);
        }

        private void btnHash_Click(object sender, EventArgs e)
        {
            byte[] data = Encoding.Unicode.GetBytes(tbMessage.Text);

            tbMD5.Text = Encoding.Unicode.GetString(new MD5CryptoServiceProvider().ComputeHash(data));
            tbSHA1.Text = Encoding.Unicode.GetString(new SHA1Managed().ComputeHash(data));
            tbSHA256.Text = Encoding.Unicode.GetString(new SHA256Managed().ComputeHash(data));
            tbSHA384.Text = Encoding.Unicode.GetString(new SHA384Managed().ComputeHash(data));
            tbSHA512.Text = Encoding.Unicode.GetString(new SHA512Managed().ComputeHash(data));
        }
    }
}
