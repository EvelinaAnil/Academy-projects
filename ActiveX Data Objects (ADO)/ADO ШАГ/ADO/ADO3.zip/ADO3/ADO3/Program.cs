﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DatabaseClass.CreateDatabase("script.sql");

                DatabaseClass databaseClass = new DatabaseClass();

                //databaseClass.SetCriticalDebtor(1);

                databaseClass.SelectDB("SELECT * FROM Students;SELECT * FROM CriticalDebtors;");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
