﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Text;

namespace ADO3
{
    class DatabaseClass
    {
        private string _connectionString;

        public DatabaseClass()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["connectStr"].ConnectionString;
        }

        public static void CreateDatabase(string fileName)
        {
            string dbName = "University39";
            string createDB = "USE master;" +
                $"IF(SELECT name FROM master.sys.databases WHERE name LIKE '{dbName}') IS NULL " +
                "BEGIN " +
                $"CREATE DATABASE {dbName};" +
                $"END " +
                $"ELSE " +
                $"ROLLBACK";
            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["master"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(createDB, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }

                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connectStr"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(File.ReadAllText(fileName, Encoding.Default), connection))
                    {
                        connection.Open();
                        if (command.ExecuteNonQuery() <= 0)
                        {
                            throw new Exception("...");
                        }
                        Console.WriteLine("Commands completed successfuly!");
                    }
                }
            }
            catch (Exception ex)
            {
                if (!ex.Message.Contains("ROLLBACK"))
                {
                    throw;
                }
            }
        }

        public void SelectDB(string commandText)
        {
            try
            {
                SqlConnection connection = new SqlConnection(_connectionString);
                try
                {
                    SqlCommand command = new SqlCommand
                    {
                        CommandText = commandText,
                        Connection = connection
                    };
                    try
                    {
                        connection.Open();

                        SqlDataReader reader = command.ExecuteReader();
                        try
                        {
                            do
                            {
                                while (reader.Read())
                                {
                                    for (int i = 0; i < reader.FieldCount; i++)
                                    {
                                        Console.Write($"{reader.GetName(i)}: {reader.GetValue(i)}\t\t");
                                    }
                                    Console.WriteLine();
                                }
                                Console.WriteLine("\n----------------------------\n");
                            } while (reader.NextResult());
                        }
                        finally
                        {
                            reader.Close();
                        }
                    }
                    finally
                    {
                        command.Dispose();
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
            catch
            {
                throw;
            }
        }

        public void SetCriticalDebtor(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand insertCommand = new SqlCommand($"INSERT INTO CriticalDebtors SELECT * FROM Students WHERE Id = {id};", connection);

                    SqlCommand removeCommand = new SqlCommand($"DELETE FROM Students WHERE Id = {id};", connection);

                    SqlTransaction transaction = null;
                    try
                    {
                        connection.Open();

                        transaction = connection.BeginTransaction(/*System.Data.IsolationLevel.RepeatableRead*/);

                        insertCommand.Transaction = transaction;
                        removeCommand.Transaction = transaction;

                        if (insertCommand.ExecuteNonQuery() > 0)
                        {
                            removeCommand.ExecuteNonQuery();

                            transaction.Commit();

                            Console.WriteLine("Commands completed successfuly!");
                        }
                    }
                    catch
                    {
                        transaction.Rollback();

                        throw;
                    }
                    finally
                    {
                        insertCommand.Dispose();
                        removeCommand.Dispose();
                        transaction.Dispose();
                    }
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
