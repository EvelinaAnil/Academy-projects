﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace ADO4_DataSet_1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DataSet dataSet = new DataSet("Example1");

                dataSet.ExtendedProperties["Date"] = DateTime.Now;
                dataSet.ExtendedProperties["Company"] = "ITStep";

                DataTable dataTable = new DataTable("People");

                DataColumn dataColumn = new DataColumn("Id", typeof(int))
                {
                    AllowDBNull = false,
                    AutoIncrement = true,
                    AutoIncrementSeed = 1,
                    AutoIncrementStep = 1
                };
                dataTable.Columns.Add(dataColumn);

                dataColumn = new DataColumn
                {
                    ColumnName = "FirstName",
                    DataType = typeof(string),
                    MaxLength = 20,
                    Caption = "Ім'я"
                };
                dataTable.Columns.Add(dataColumn);

                dataColumn = new DataColumn
                {
                    ColumnName = "LastName",
                    DataType = typeof(string),
                    MaxLength = 30,
                    Caption = "Прізвище"
                };
                dataTable.Columns.Add(dataColumn);

                dataColumn = new DataColumn
                {
                    ColumnName = "BirthDate",
                    DataType = typeof(DateTime),
                    Caption = "Днюха"
                };
                dataTable.Columns.Add(dataColumn);

                //DataRow dataRow = new DataRow(); ERROR
                DataRow dataRow = dataTable.NewRow();
                dataRow[1] = "Mark";
                dataRow[2] = "Lourens";
                dataRow[3] = new DateTime(1998, 4, 12);
                dataTable.Rows.Add(dataRow);

                dataRow = dataTable.NewRow();
                dataRow["FirstName"] = "Jennifer";
                dataRow["LastName"] = "Aniston";
                dataRow["BirthDate"] = new DateTime(1969, 2, 11);
                dataTable.Rows.Add(dataRow);

                dataSet.Tables.Add(dataTable);

                //PrintDS(dataSet);

                //dataTable.Rows[0]["LastName"] = "McCalister";

                //dataTable.Rows.RemoveAt(1);

                //PrintDS(dataSet);

                /*dataSet.WriteXml("DataSetExample1.xml");

                Console.WriteLine("Write file");

                dataSet.Clear();

                dataSet.ReadXml("DataSetExample1.xml");

                Console.WriteLine("Read file");

                PrintDS(dataSet);*/

                dataSet.RemotingFormat = SerializationFormat.Binary;

                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream("DataSetExample1.bin", FileMode.Create))
                {
                    formatter.Serialize(stream, dataSet);
                }

                dataSet.Clear();

                using (FileStream stream = new FileStream("DataSetExample1.bin", FileMode.Open))
                {
                    dataSet = formatter.Deserialize(stream) as DataSet;
                }

                PrintDS(dataSet);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }

        private static void PrintDS(DataSet dataSet)
        {
            Console.WriteLine($"DataSet name: {dataSet.DataSetName}\n");

            foreach (DictionaryEntry item in dataSet.ExtendedProperties)
            {
                Console.WriteLine($"Key: {item.Key}, Value = {item.Value}");
            }

            Console.WriteLine();

            foreach (DataTable table in dataSet.Tables)
            {
                Console.WriteLine($"\n\t\t\t{table.TableName}");

                foreach (DataColumn column in table.Columns)
                {
                    Console.Write($"{column.Caption}\t\t");
                }
                Console.WriteLine("\n------------------------------------------\n");

                foreach (DataRow row in table.Rows)
                {
                    foreach (object item in row.ItemArray)
                    {
                        Console.Write($"{item}\t\t");
                    }
                    Console.WriteLine();
                }

                /*for (int row = 0; row < table.Rows.Count; row++)
                {
                    for (int col = 0; col < table.Columns.Count; col++)
                    {
                        Console.Write($"{table.Rows[row][col]}\t\t");
                    }
                    Console.WriteLine();
                }*/
            }
        }
    }
}
