﻿using ADO4_DataSet_2.DBClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO4_DataSet_2
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                LibraryDB libraryDB = new LibraryDB();

                //libraryDB.AuthorAdd("Daniels", "Jack");

                //libraryDB.PrintDS();

                //libraryDB.PrintRelation("Authors", "Books", "AuthorBooks");

                libraryDB.GetAuthorByFirstChar('К'); // rus
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
