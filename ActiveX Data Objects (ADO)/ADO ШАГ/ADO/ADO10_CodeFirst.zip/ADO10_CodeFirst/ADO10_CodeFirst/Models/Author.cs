﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO10_CodeFirst.Models
{
    class Author
    {
        public int Id { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public virtual Account Account { get; set; }

        //public int CountryId { get; set; } // foreign key
        public virtual Country Country { get; set; } // navigation property

        public virtual ICollection<Book> Books { get; set; }

        public Author()
        {
            Books = new List<Book>();
        }

        public override string ToString()
        {
            return $"{LastName} {FirstName}";
        }
    }
}
