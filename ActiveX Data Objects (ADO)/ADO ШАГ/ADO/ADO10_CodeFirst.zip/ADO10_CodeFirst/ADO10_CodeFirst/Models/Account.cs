﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADO10_CodeFirst.Models
{
    class Account
    {
        [Key]
        [ForeignKey("Author")]
        public int Id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }

        public virtual Author Author { get; set; }
    }
}
