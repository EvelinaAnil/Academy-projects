﻿using System.Collections.Generic;

namespace ADO10_CodeFirst.Models
{
    class Country
    {
        public int Id { get; set; }
        public string CountryName { get; set; }

        public virtual ICollection<Author> Authors { get; set; }

        public Country()
        {
            Authors = new List<Author>();
        }
    }
}
