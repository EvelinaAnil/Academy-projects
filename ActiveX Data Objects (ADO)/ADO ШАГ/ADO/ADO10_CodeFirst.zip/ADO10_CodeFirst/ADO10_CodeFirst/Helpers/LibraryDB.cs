﻿using ADO10_CodeFirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace ADO10_CodeFirst.Helpers
{
    class LibraryDB
    {
        private LibraryContext _context;

        public LibraryDB()
        {
            try
            {
                _context = new LibraryContext();

                if (!_context.Database.Exists())
                {
                    Country country = new Country { CountryName = "Ukraine" };

                    Author author = new Author
                    {
                        LastName = "Schevchenko",
                        FirstName = "Taras"
                    };
                    Book book = new Book { Title = "Kobzar" };

                    author.Books.Add(book);
                    _context.Authors.Add(author);

                    _context.Accounts.Add(
                        new Account
                        {
                            Id = author.Id,
                            Login = "tarasS",
                            Password = "sdksd-5&hj"
                        });
                    country.Authors.Add(author);
                    _context.Countries.AddRange(
                        new List<Country>
                        {
                            country,
                            new Country { CountryName = "Poland" },
                            new Country { CountryName = "Litva" }
                        });

                    Publisher publisher = new Publisher { PublisherName = "Ranok" };
                    publisher.Books.Add(book);
                    _context.Publishers.Add(publisher);

                    _context.Books.Add(
                        new Book
                        {
                            Title = "C#",
                            Publishers = new List<Publisher>
                            {
                                new Publisher { PublisherName = "Microsoft" },
                                publisher
                            }
                        });
                    _context.SaveChanges();

                    _context.Authors.Add(
                        new Author
                        {
                            LastName = "Moore",
                            FirstName = "Oliver",
                            Country = _context.Countries.First(c => c.CountryName == "Litva")
                        });
                    _context.SaveChanges();

                    author = _context.Authors.FirstOrDefault(a => a.LastName == "Moore" && a.FirstName == "Oliver");
                    if (author != null)
                    {
                        (author.Books as List<Book>).AddRange(
                            new List<Book>
                            {
                                new Book{ Title = "Flowers" },
                                _context.Books.First(b => b.Title=="C#")
                            });
                    }
                    _context.SaveChanges();

                    Console.WriteLine("Database OK!");
                }
                else
                {
                    Console.WriteLine("Database exists!");
                }
            }
            catch
            {
                throw;
            }
        }

        public void Show()
        {
            // eager loading
            foreach (Book book in _context.Books.Include(b => b.Authors).Include(b => b.Publishers).ToList())
            {
                Console.Write(new string('\t', 2));
                Console.WriteLine(book.Title);

                foreach (Author author in book.Authors)
                {
                    Console.Write(new string('\t', 3));

                    // explicit loading
                    _context.Entry(author).Reference("Country").Load();

                    Console.WriteLine($"{author} {author.Country.CountryName}");
                }

                foreach (Publisher publisher in book.Publishers)
                {
                    Console.Write(new string('\t', 4));
                    Console.WriteLine(publisher.PublisherName);
                }
            }

            Console.WriteLine("\n--------------------------------------\n");

            // lazy loading
            foreach (Country country in _context.Countries)
            {
                Console.WriteLine(country.CountryName);

                foreach (Author author in country.Authors)
                {
                    Console.Write(new string('\t', 2));
                    Console.WriteLine(author);

                    foreach (Book book in author.Books)
                    {
                        Console.Write(new string('\t', 3));

                        Console.WriteLine(book.Title);

                        foreach (Publisher publisher in book.Publishers)
                        {
                            Console.Write(new string('\t', 4));
                            Console.WriteLine(publisher.PublisherName);
                        }
                    }
                }
            }
        }
    }
}