﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO1
{
    // localhost\sqlexpress
    // (local)\sqlexpress
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = @"Data Source=(local)\sqlexpress;Initial Catalog=University39;Integrated Security=True;Connect Timeout=20";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand("SELECT * FROM Students;", connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine($"Id: {reader[0]}\nLast name: {reader["LastName"]}\nFirst name: {reader["FirstName"]}\nDate of birth: {Convert.ToDateTime(reader["BirthDate"]).ToLongDateString()}\nGroup id: {reader["GroupId"]}\n");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
