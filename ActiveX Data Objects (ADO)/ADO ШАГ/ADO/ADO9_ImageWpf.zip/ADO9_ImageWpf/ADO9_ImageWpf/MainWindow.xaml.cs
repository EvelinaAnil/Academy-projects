﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ADO9_ImageWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ImageModelContainer _imageModel;
        public MainWindow()
        {
            try
            {
                _imageModel = new ImageModelContainer();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                Application.Current.Shutdown();
            }

            InitializeComponent();
        }

        private void create_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FileInfo fileInfo = new FileInfo("space.jpg");
                if (fileInfo.Exists)
                {
                    using (FileStream stream = fileInfo.OpenRead())
                    {
                        using (BinaryReader reader = new BinaryReader(stream))
                        {
                            Photo photo = new Photo
                            {
                                Name = "Space",
                                Image = reader.ReadBytes((int)fileInfo.Length)
                            };
                            _imageModel.Photos.Add(photo);
                            _imageModel.SaveChanges();
                        }
                    }
                    //download.IsEnabled = true;

                    MessageBox.Show("Create OK!");
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void download_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Photo photo = _imageModel.Photos.FirstOrDefault(p => p.Name == "Space");
                if (photo != null)
                {
                    using (MemoryStream stream = new MemoryStream(photo.Image))
                    {
                        BitmapImage bitmapImage = new BitmapImage();
                        bitmapImage.BeginInit();
                        bitmapImage.StreamSource = stream;
                        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapImage.EndInit();
                        image.Source = bitmapImage;

                        //pictureBox1.Image = new Bitmap(stream); for WindowsForms
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
