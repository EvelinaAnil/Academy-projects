﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO10_CodeFirstFromDatabase.Models
{
    class Class1
    {
    }
}
