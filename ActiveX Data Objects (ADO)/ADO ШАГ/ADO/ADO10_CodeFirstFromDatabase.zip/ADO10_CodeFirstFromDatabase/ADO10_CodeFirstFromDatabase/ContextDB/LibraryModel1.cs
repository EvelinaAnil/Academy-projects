namespace ADO10_CodeFirstFromDatabase.ContextDB
{
    using System.Data.Entity;
    using ADO10_CodeFirstFromDatabase.Models;

    public partial class LibraryModel1 : DbContext
    {
        public LibraryModel1()
            : base("name=LibraryModel1")
        {
        }

        public virtual DbSet<Author> Authors { get; set; }
        public virtual DbSet<Book> Books { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Faculty> Faculties { get; set; }
        public virtual DbSet<Group> Groups { get; set; }
        public virtual DbSet<Lib> Libs { get; set; }
        public virtual DbSet<Press> Presses { get; set; }
        public virtual DbSet<S_Cards> S_Cards { get; set; }
        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Theme> Themes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Author>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Author>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Author>()
                .HasMany(e => e.Books)
                .WithRequired(e => e.Author)
                .HasForeignKey(e => e.Id_Author);

            modelBuilder.Entity<Book>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Book>()
                .Property(e => e.Comment)
                .IsUnicode(false);

            modelBuilder.Entity<Book>()
                .HasMany(e => e.S_Cards)
                .WithRequired(e => e.Book)
                .HasForeignKey(e => e.Id_Book);

            modelBuilder.Entity<Category>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Category>()
                .HasMany(e => e.Books)
                .WithRequired(e => e.Category)
                .HasForeignKey(e => e.Id_Category);

            modelBuilder.Entity<Faculty>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Faculty>()
                .HasMany(e => e.Groups)
                .WithRequired(e => e.Faculty)
                .HasForeignKey(e => e.Id_Faculty);

            modelBuilder.Entity<Group>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Group>()
                .HasMany(e => e.Students)
                .WithRequired(e => e.Group)
                .HasForeignKey(e => e.Id_Group);

            modelBuilder.Entity<Lib>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Lib>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Lib>()
                .HasMany(e => e.S_Cards)
                .WithRequired(e => e.Lib)
                .HasForeignKey(e => e.Id_Lib);

            modelBuilder.Entity<Press>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Press>()
                .HasMany(e => e.Books)
                .WithRequired(e => e.Press)
                .HasForeignKey(e => e.Id_Press);

            modelBuilder.Entity<Student>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Student>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Student>()
                .HasMany(e => e.S_Cards)
                .WithRequired(e => e.Student)
                .HasForeignKey(e => e.Id_Student);

            modelBuilder.Entity<Theme>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Theme>()
                .HasMany(e => e.Books)
                .WithRequired(e => e.Theme)
                .HasForeignKey(e => e.Id_Themes);
        }
    }
}
