﻿using ADO9_ModelFirst.DbClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO9_ModelFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                UserDB userDB = new UserDB();

                userDB.Show();

                userDB.AdminsShow();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
