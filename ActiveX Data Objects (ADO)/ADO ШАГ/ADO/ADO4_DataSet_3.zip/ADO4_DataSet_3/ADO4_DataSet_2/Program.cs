﻿using ADO4_DataSet_2.DBClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO4_DataSet_2
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                LibraryDB libraryDB = new LibraryDB();

                //libraryDB.AuthorAdd("Daniels", "Jack");

                //libraryDB.BookUpdate("SQL", 5);

                //libraryDB.AuthorDelete("Daniels");

                //libraryDB.PrintDS();

                //libraryDB.PrintRelation("Authors", "Books", "AuthorBooks");

                //libraryDB.GetAuthorByFirstChar('К'); // rus

                /* вывести авторов чье ID больше 5 и меньше 15
                ////var result = from d in libraryDB.DataSet.Tables["Authors"].AsEnumerable()
                ////             where Convert.ToInt32(d["ID"]) > 5 && Convert.ToInt32(d["ID"]) < 15
                ////             orderby d["LastName"] descending
                ////             select d;
                //var result = from d in libraryDB.DataSet.Tables["Authors"].AsEnumerable()
                //             where d.Field<int>("ID") > 5 && d.Field<int>("ID") < 15
                //             orderby d["LastName"] descending
                //             select d;

                //foreach (var item in result)
                //{
                //    Console.WriteLine($"{item["LastName"]} {item["FirstName"]}");
                //}
                var result = from d in libraryDB.DataSet.Tables["Authors"].AsEnumerable()
                             where d.Field<int>("ID") > 5 && d.Field<int>("ID") < 15
                             orderby d["LastName"] descending
                             select new { FirstName = d.Field<string>("FirstName"), LastName = d.Field<string>("LastName") };

                foreach (var item in result)
                {
                    Console.WriteLine(item);
                }*/

                // вывести студентов из группы 9А
                var result = from st in libraryDB.DataSet.Tables["Students"].AsEnumerable()
                             from gr in libraryDB.DataSet.Tables["Groups"].AsEnumerable()
                             where st.Field<int>("Id_Group") == gr.Field<int>("Id") && gr.Field<string>("Name") == "9А"
                             select new
                             {
                                 FirstName = st.Field<string>("FirstName"),
                                 LastName = st.Field<string>("LastName"),
                                 GroupName = gr.Field<string>("Name")
                             };

                foreach (var item in result)
                {
                    Console.WriteLine(item);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
