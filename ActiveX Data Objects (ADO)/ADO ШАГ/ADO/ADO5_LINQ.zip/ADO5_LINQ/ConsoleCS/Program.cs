﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleCS
{
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int GroupId { get; set; }
    }

    class Group
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    static class ExtensionsClass
    {
        public static int WordsNumber(this string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return 0;
            }

            return data.Split(new char[] { ' ', ',', ':', '.' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }

        public static string StrConcat(this string data, string str)
        {
            return data + str;
        }
    }

    delegate int IntDelegate(int n);

    class Program
    {
        public static int Increment(int num)
        {
            return ++num;
        }

        static void Main(string[] args)
        {
            /*
            int n = 67;
            //IntDelegate intDelegate = new IntDelegate(Increment);
            //IntDelegate intDelegate = Increment;

            //Console.WriteLine(intDelegate(n));

            //IntDelegate intDelegate = delegate (int m)
            // {
            //     return m += 1;
            // };
            //Console.WriteLine(intDelegate(n));

            // delegate (int m)    { return m += 1; };
            //          (int m) => { return m += 1; };
            
            //IntDelegate intDelegate = (int m) =>  {  return m += 1;  };
            //IntDelegate intDelegate = m =>  {  return m += 1;  };
            //IntDelegate intDelegate = m => m += 1;

            int num = 3;
            IntDelegate intDelegate = m => m += num;

            Console.WriteLine(intDelegate(n));
            */

            /*
            string text = "Gets the number of characters in the current System.String object.";

            Console.WriteLine($"Number of words in string: {text.WordsNumber()}");

            string str = "Hello";

            Console.WriteLine(text.StrConcat(str));
            */

            /* ----------- Language Integrated Query (LINQ) -----------*/

            int[] array = { 5, 34, 67, 12, 94, 42, 35, 72 };

            //IEnumerable<int> query = from i in array
            //                         select i;

            //foreach (int item in query)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine();

            //array[0] = 25;

            //foreach (int item in query)
            //{
            //    Console.WriteLine(item);
            //}

            // ----------------------------------------------

            //IEnumerable<int> query = from i in array
            //                         where i % 2 == 0
            //                         orderby i descending
            //                         select i;

            //foreach (int item in query)
            //{
            //    Console.WriteLine(item);
            //}

            // ----------------------------------------------

            ////IEnumerable<IGrouping<int, int>> query = from i in array
            ////                                         group i by i % 10;
            //IEnumerable<IGrouping<int, int>> query = from i in array
            //                                         group i by i % 10 into res
            //                                         where res.Count() >= 2
            //                                         select res;

            //foreach (IGrouping<int, int> item in query)
            //{
            //    Console.WriteLine(item.Key);
            //    foreach (int value in item)
            //    {
            //        Console.WriteLine($"\t{value}");
            //    }
            //}

            // ----------------------------------------------

            //string[] poem = { "В этой сказке", "Нет порядка:", "Что ни слово -", "То загадка!" };

            //IEnumerable<string> query = from p in poem
            //                            let words = p.Split(' ')
            //                            from w in words
            //                            where w.Count() > 5
            //                            select w;

            //foreach (string item in query)
            //{
            //    Console.WriteLine(item);
            //}

            // ----------------------------------------------

            //var number = 4.5;
            ///*Error
            //var n1;
            //var n2 = null;*/

            ////var query = from i in array
            ////            where i % 2 == 0
            ////            orderby i descending
            ////            select i;
            ////foreach (var item in query)
            ////{
            ////    Console.WriteLine(item);
            ////}

            //var worker = new { Name = "Fiona", Salary = 5692.27 };
            //Console.WriteLine(worker);

            // ----------------------------------------------

            //List<Group> groups = new List<Group>
            //{
            //    new Group{Id = 1, Name = "39PR31"},
            //    new Group{Id = 2, Name = "37PR32"}
            //};

            //List<Student> students = new List<Student> {
            //    new Student { FirstName = "John", LastName = "Miller", GroupId = 2 },
            //    new Student { FirstName = "Candice", LastName = "Leman", GroupId = 1 },
            //    new Student { FirstName = "Joey", LastName = "Finch", GroupId = 3 },
            //    new Student { FirstName = "Nicole", LastName = "Taylor", GroupId = 1 }
            //};

            ////var query = from g in groups
            ////            join st in students on g.Id equals st.GroupId into res
            ////            from r in res
            ////            select r;

            //////Student student = students.First(s => s.LastName.Contains("il"));
            //////Student student = students.First(s => s.LastName.Contains("ol")); // Exception
            ////Student student = students.FirstOrDefault(s => s.LastName.Contains("ol"));
            //////if (student != null)
            //////{

            //////}
            ////Console.WriteLine(student?.LastName);

            ////foreach (var item in query)
            ////{
            ////    Console.WriteLine($"{item.LastName} {item.FirstName} {item.GroupId}");
            ////}
            ////foreach (var item in query)
            ////{
            ////    Console.WriteLine($"{item.LastName} {item.FirstName} {groups.First(g=>g.Id==item.GroupId).Name}");
            ////}

            ////var query = from g in groups
            ////            join st in students on g.Id equals st.GroupId
            ////            select new { LastName = st.LastName, FirstName = st.FirstName, GroupName = g.Name };
            //var query = from g in groups
            //            join st in students on g.Id equals st.GroupId
            //            select new { st.LastName, st.FirstName, GroupName = g.Name };

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item);
            //}

            // ----------------------------------------------

            List<Student> students = new List<Student> {
                new Student { FirstName = "John", LastName = "Miller", GroupId = 2 },
                new Student { FirstName = "Candice", LastName = "Leman", GroupId = 1 },
                new Student { FirstName = "Joey", LastName = "Finch", GroupId = 3 },
                new Student { FirstName = "Nicole", LastName = "Taylor", GroupId = 1 }
            };

            ////var query = from s in students
            ////            where s.LastName.Length == 5
            ////            select s;

            //var query = students.Where(s => s.LastName.Length == 5);

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item.LastName);
            //}

            //var query = students
            //    .Where(s => s.LastName.Length == 5)
            //    .Select(s => s.FirstName)
            //    .OrderByDescending(s => s);

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item);
            //}

            //var query = students.Where(s => s.LastName.Length == 5).OrderByDescending(s => s.LastName);

            //foreach (var item in query)
            //{
            //    Console.WriteLine(item.LastName);
            //}

            Console.WriteLine(students.Where(s => s.LastName.Length == 5).Max(s => s.FirstName));

            Console.ReadKey();
        }
    }
}