﻿using ADO8_DatabaseFirst.DbClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO8_DatabaseFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentDB studentDB = new StudentDB();

            //studentDB.SubjectInsert("C#");

            //studentDB.StudentInsert("Dark", "Jane", "AS5783810", new List<Subject>
            //{
            //    new Subject{ SubjectName = "JavaScript"},
            //    new Subject{ SubjectName = "C#"},
            //});

            //studentDB.StudentInsert("Doe", "John", "RT345921", new List<Subject>
            //{
            //    new Subject{ SubjectName = "ADO.NET"},
            //    new Subject{ SubjectName = "WPF"},
            //    new Subject{ SubjectName = "JavaScript"}
            //});

            //studentDB.StudentDelete("RT345921");

            studentDB.StudentUpdate("AS5783810", new List<Subject>
            {
                new Subject{ SubjectName = "ADO.NET"},
                new Subject{ SubjectName = "C#"},
                new Subject{ SubjectName = "Unity"}
            });

            studentDB.Show();

            Console.ReadKey();
        }
    }
}
