﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO8_DatabaseFirst.DbClasses
{
    class StudentDB
    {
        private DatabaseFirstContext _context;
        public StudentDB()
        {
            _context = new DatabaseFirstContext();
        }

        public void SubjectInsert(string name)
        {
            try
            {
                if (_context.Subjects.Any(s=>s.SubjectName == name))
                {
                    Console.WriteLine("Subject exists!");
                }
                else
                {
                    _context.Subjects.Add(new Subject { SubjectName = name });
                    _context.SaveChanges();

                    Console.WriteLine("Subject OK!");
                }
            }
            catch
            {
                throw;
            }
        }

        public void StudentInsert(string lName, string fName, string number, List<Subject> subjects)
        {
            try
            {
                if (_context.Students.Any(s => s.CardNumber == number))
                {
                    Console.WriteLine("Student exists!");
                }
                else
                {
                    Student student = new Student
                    {
                        LastName = lName,
                        FirstName = fName,
                        CardNumber = number
                    };

                    // student.Subjects = subjects; запрещено

                    foreach (Subject subject in subjects)
                    {
                        if (_context.Subjects.Any(s => s.SubjectName == subject.SubjectName))
                        {
                            student.Subjects.Add(_context.Subjects.First(s => s.SubjectName == subject.SubjectName));
                        }
                        else
                        {
                            student.Subjects.Add(subject);
                        }
                    }

                    _context.Students.Add(student);
                    _context.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
        }

        public void StudentDelete(string number)
        {
            Student student = _context.Students.FirstOrDefault(s => s.CardNumber == number);

            if (student != null)
            {
                // При удалении объектов, которые имеют связанные данные, вам может понадобиться обновить соответствующие данные для удаления, чтобы успешно выполнить запрос.
                _context.Entry(student).Collection(s => s.Subjects).Load();

                _context.Students.Remove(student);
                _context.SaveChanges();
            }
            else
            {
                Console.WriteLine("Student not exists!");
            }
        }

        public void StudentUpdate(string number, List<Subject> subjects)
        {
            Student student = _context.Students.FirstOrDefault(s => s.CardNumber == number);

            if (student != null)
            {
                student.Subjects.Clear();

                foreach (Subject subject in subjects)
                {
                    if (_context.Subjects.Any(s=>s.SubjectName==subject.SubjectName))
                    {
                        student.Subjects.Add(_context.Subjects.First(s => s.SubjectName == subject.SubjectName));
                    }
                    else
                    {
                        student.Subjects.Add(subject);
                    }

                    _context.Entry(student).State = System.Data.Entity.EntityState.Modified;
                    _context.SaveChanges();
                }
            }
            else
            {
                Console.WriteLine("Student not exists!");
            }
        }

        public void Show()
        {
            foreach (Student student in _context.Students)
            {
                Console.WriteLine(student);
                foreach (Subject subject in student.Subjects)
                {
                    Console.WriteLine($"\t{subject.SubjectName}");
                }
                Console.WriteLine("\n-------------------------\n");
            }
        }
    }
}
