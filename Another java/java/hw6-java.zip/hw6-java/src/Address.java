public class Address {
    public String city;
    public String street;
    public String houseNumber;
    public String roomNumber;

    public Address(String city, String street, String houseNumber, String roomNumber) {
        this.city = city;
        this.street = street;
        this.houseNumber = houseNumber;
        this.roomNumber = roomNumber;
    }
}