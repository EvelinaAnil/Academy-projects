public interface IAttack {
    void attack(Character target);
}
