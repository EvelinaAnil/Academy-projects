public interface IHeal {
    public void heal(Character target);
}
