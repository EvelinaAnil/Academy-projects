public enum DamageType {
    PHYSICAL,
    MAGICAL
}
