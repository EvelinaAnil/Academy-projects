public interface IntegerParser {
    int parse(String s);
}
