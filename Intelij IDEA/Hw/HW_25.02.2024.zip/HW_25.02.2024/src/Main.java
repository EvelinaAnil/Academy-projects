import java.util.Random;

public class Main {
    public static void main(String[] args) {
        // Створення двомірного масиву розміром 5x3
        int[][] array = new int[5][3];

        // Заповнення масиву випадковими числами від 20 до 80
        Random random = new Random();
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                array[i][j] = random.nextInt(61) + 20; // Генеруємо випадкове число в діапазоні від 20 до 80
            }
        }

        // Лічильники для парних та непарних чисел
        int evenCount = 0;
        int oddCount = 0;

        // Підрахунок парних та непарних чисел
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                if (array[i][j] % 2 == 0) {
                    evenCount++;
                } else {
                    oddCount++;
                }
            }
        }

        // Виведення результатів
        System.out.println("Кількість парних чисел: " + evenCount);
        System.out.println("Кількість непарних чисел: " + oddCount);
    }
}
