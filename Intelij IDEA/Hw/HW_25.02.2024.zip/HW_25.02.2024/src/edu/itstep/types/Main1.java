package edu.itstep.types;

import java.util.Arrays;

public class Main1 {
    public static void main(String[] args) {
        int[] arr = {2, 6, 4};
        System.out.println(arr);
        System.out.println(Arrays.toString(arr));
        String res = Arrays.toString(arr);
        System.out.println(res);
        //System.out.println(res[0]);

    }
}
