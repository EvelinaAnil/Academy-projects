package edu.itstep.types;

import java.util.Scanner;

public class Main5 {
    public static void main(String[] args) {
        //String
//        String st = "Hello World";
//        System.out.println(st);//ctrl + P
//        System.out.println(st.toString());

//        int[] arr = {1, 2, 3};
//        System.out.println(arr);

//        char[] chars = {'a', 'b', 'c'};
//        System.out.println(chars);

//        System.out.println(1 + 1);
//        System.out.println("1" + "1");

//        int[] a = {1, 1, 1};
//        int[] b = {1, 1, 1};
//        System.out.println(a == b);

//        String a = new String("www");
//        String b = new String("www");
//        System.out.println(a == b);
//        System.out.println(a.equals(b));

//        String a = "www";
//        String b = "www";
//        System.out.println(a == b);
//        System.out.println(a.equals(b));

//        Scanner scanner = new Scanner(System.in);
//        String a = scanner.nextLine();
//        String b = scanner.nextLine();
//        System.out.println(a == b);
//        System.out.println(a.equals(b));

//        String password = "acdc";
//        Scanner scanner = new Scanner(System.in);
//        String userInput = scanner.nextLine();
//        System.out.println(password == userInput);

//        Scanner scanner = new Scanner(System.in);
//        String a = scanner.nextLine();
//        String b = scanner.nextLine();
//        System.out.println(a == b);
//        System.out.println(a.equals(b));


    }
}
