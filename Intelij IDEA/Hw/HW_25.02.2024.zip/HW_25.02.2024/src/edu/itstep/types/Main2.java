package edu.itstep.types;

import java.util.Arrays;

public class Main2 {
    public static void main(String[] args) {
//        int original = 1;
//        int copy = original;
//        copy = 2;
//        System.out.println(original);//1

        int[] original = {1, 1, 1};
        System.out.println(original);
//        int[] copy = original;
//        copy[0] = 2;
//        copy[1] = 2;
//        copy[2] = 2;
//        System.out.println(Arrays.toString(original));

    }
}
