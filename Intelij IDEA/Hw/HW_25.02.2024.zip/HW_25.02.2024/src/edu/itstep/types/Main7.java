package edu.itstep.types;

public class Main7 {
    public static void main(String[] args) {
//        String original = "one";
//        String copy = original;
//        copy = "two";
//        System.out.println(original);//???

//        String a = "one";
//        String b = a + "two";

//        String res = "";
//        res += "1";
//        res += "2";
//        res += "3";

//        String original = new String("aaa");
//        String copy = original;
//        copy = "bbb";
//        System.out.println(original);

//        long start = System.currentTimeMillis();
//        String res = "";
//        for (int i = 1; i < 100; i++) {
//            res += i + " ";
//        }
//        long end = System.currentTimeMillis();
//        System.out.println(end - start);//19-18
//
//        System.out.println(res);

//        long start = System.currentTimeMillis();
//        StringBuilder res = new StringBuilder();
//        for (int i = 1; i < 100; i++) {
//            res.append(i).append(" ");
//        }
//        long end = System.currentTimeMillis();
//        System.out.println(end - start);//0
//
//        System.out.println(res);


//        Integer original = 100;
//        Integer copy = original;
//        copy = 200;
//        System.out.println(original);
    }
}
