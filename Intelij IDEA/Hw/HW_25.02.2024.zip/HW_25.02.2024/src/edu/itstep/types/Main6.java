package edu.itstep.types;

import java.util.ArrayList;

public class Main6 {
    public static void main(String[] args) {
//        ArrayList<String> arrayList = new ArrayList<>();
//        arrayList.add("one");
//        arrayList.add("two");
//        arrayList.add(3);
//        arrayList.removeFirst();
//        System.out.println(arrayList);

        //ArrayList<int> arrayList = new ArrayList<>();
//        byte b1 = 1;
//        Byte b2 = 1;
        //Byte b3 = new Byte((byte) 1);
//        System.out.println(b1);
//        System.out.println(b2);
        //System.out.println(b3);


//        int original = 1;
//        Integer copy = original;

//        Integer original = 1;
//        int copy = original;
//        System.out.println(original);
//        System.out.println(copy);

//        int a = 100;
//        int b = 100;
//        Integer x = 100;
//        Integer y = 100;
//        System.out.println(a == b);//true
//        System.out.println(x == y);//true

//        int a = 300;
//        int b = 300;
//        Integer x = 300;
//        Integer y = 300;
//        System.out.println(a == b);//true
//        System.out.println(x == y);//false
//        System.out.println(x.equals(y));


//        Byte a = 100;
//        Byte b = 100;
//        System.out.println(a == b);

//        Long a = 300L;
//        Long b = 300L;
//        System.out.println(a == b);

//        Double d1 = 100.0;
//        Double d2 = 100.0;
//        System.out.println(d1 == d2);
    }
}
