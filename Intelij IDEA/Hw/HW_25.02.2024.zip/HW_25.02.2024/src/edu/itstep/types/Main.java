package edu.itstep.types;

public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 3, 4, 5};
        //fori
        //itar
//        for (int i = 0; i < arr.length; i++) {
//            System.out.println(arr[i]);
//        }

        //iter
//        for (int value : arr) {
//            System.out.println(value);
//        }
//        for (int i : arr) {
//            i *= 2;
//        }
//        for (int i : arr) {
//            System.out.println(i);
//        }

//        for (int i = 0; i < arr.length; i++) {
//            arr[i] *= 2;
//        }
//        for (int i : arr) {
//            System.out.println(i);
//        }

        for (int i : arr) {
            System.out.print(i + " ");
        }

    }
}
