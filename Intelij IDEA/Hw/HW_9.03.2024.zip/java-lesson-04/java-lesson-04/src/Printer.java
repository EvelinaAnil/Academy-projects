public interface Printer {
    String execute(String data);
}
