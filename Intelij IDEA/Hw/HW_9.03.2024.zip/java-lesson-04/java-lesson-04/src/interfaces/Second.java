package interfaces;

public interface Second {
    void method2();
}
