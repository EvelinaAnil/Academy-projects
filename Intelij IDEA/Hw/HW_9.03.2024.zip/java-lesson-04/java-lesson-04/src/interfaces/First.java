package interfaces;

public interface First {
    void method1();
}
