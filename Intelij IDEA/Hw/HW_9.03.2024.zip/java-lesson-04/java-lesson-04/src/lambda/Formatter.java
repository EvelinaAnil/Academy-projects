package lambda;

public interface Formatter {
    String format(String string);

    String format(String first, String second);
}
