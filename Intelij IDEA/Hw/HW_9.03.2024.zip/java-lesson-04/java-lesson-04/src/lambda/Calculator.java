package lambda;

public interface Calculator {
    double execute(double a, double b);

}
