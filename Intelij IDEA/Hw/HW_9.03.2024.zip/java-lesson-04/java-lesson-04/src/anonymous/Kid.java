package anonymous;

public class Kid extends Parent{
    @Override
    public void print() {
        System.out.println("I'm Kid");
    }

    public void methodKid(){
        System.out.println("methodKid");
    }
}
