package anonymous;

public class Parent {
    private String name;

    public void print() {
        System.out.println("I'm Parent");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
