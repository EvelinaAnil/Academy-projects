package anonymous;

public interface Soldier {
    void shoot();
}
