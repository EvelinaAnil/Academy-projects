package inheritance;

public class Main {
    public static void main(String[] args) {
//        Rectangle rectangle = new Rectangle("green", "red", 2, 5);
//       rectangle.printName();
//        rectangle.setBorderColor("green");
//        System.out.println(rectangle);
//        System.out.println(rectangle.toString());
//        String res1 = rectangle;
//        String res2 = rectangle.toString();

//        Circle circle = new Circle("black", "red", 15);
//        System.out.println(circle);

//        Shape shape;
//        shape = new Rectangle("red", "green", 4, 6);
//        System.out.println(shape);
//        shape = new Circle("black", "white", 3);
//        System.out.println(shape);

        //Shape shape = new Shape("black", "white");

//        Shape shape;
//        shape = new Rectangle("red", "green", 4, 6);
//        System.out.println(shape);
//        shape = new Circle("black", "white", 3);
//        System.out.println(shape);

        Trangle triangle = new Trangle("red", "black", 4, 5, 6);

        System.out.println("-----" + '\\');
        // Використання toString()
        System.out.println(triangle);
    }
}
