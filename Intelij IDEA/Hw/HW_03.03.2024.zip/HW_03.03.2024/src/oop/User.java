package oop;

public class User {

    private String privateField = "private";

    String packagePrivate = "packagePrivate";

    protected  String protectedField = "protected";

    public String publicField = "public";
}
