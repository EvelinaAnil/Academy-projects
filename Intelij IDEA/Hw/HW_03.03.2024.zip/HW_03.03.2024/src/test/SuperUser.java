package test;

import oop.User;

public class SuperUser extends User {
    public SuperUser(){
        System.out.println(publicField);
        System.out.println(protectedField);

    }
}
