package incapsulation;

public class Main {
    public static void main(String[] args) {
//        Product product = new Product
//                ("Phone", 1000, "cyan"); //ctr + P
//        System.out.println(product);
//        System.out.println(product.getName());

//        int[] arr = {1,2,3,4};
//        System.out.println(arr.length);
//        arr.length = 10;


    }
}
