package stream_api;

public enum Speciality {
    DEVELOPER, TESTER, DESIGNER
}
