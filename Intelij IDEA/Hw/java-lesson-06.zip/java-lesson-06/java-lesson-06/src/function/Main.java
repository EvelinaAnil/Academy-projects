package function;

import comparable.User;

import java.lang.constant.Constable;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Main {
    public static void main(String[] args) {
//        Predicate<Integer> predicate = x -> x > 0;
//        System.out.println(predicate.test(7));

//        Consumer<String> consumer = System.out::println;
//        consumer.accept("Hello WOrld");

//        Function<User, String> function = user -> user.getName();
//        System.out.println(function.apply(new User("Ivan", 18)));

//        Supplier<Integer> supplier = () -> new Random().nextInt(100);
//        System.out.println(supplier.get());
    }
}
