package lambda_vs_anonymous;

public interface Printer {
    void print();

}
