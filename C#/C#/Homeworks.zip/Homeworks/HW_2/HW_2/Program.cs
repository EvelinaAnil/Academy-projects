﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //1
          //  Сжать массив, удалив из него все 0 
            //    и, заполнить освободившиеся справа элементы значениями –1
            int[] mas = new int[] { 1, 5, 8, 1, 0, 2, 1, 0, 3, 0 };
            int n = mas.Length;

            for (int i = 0; i < n; i++)
            {
                if (mas[i] == 0)
                {
                    n--;
                    for (int j = i; j < n; j++)
                    {
                        mas[j] = mas[j + 1];
                    }
                    mas[n] = -1;
                    i--;
                }
            }

            //2
            // Преобразовать массив так, чтобы сначала шли все
            //отрицательные элементы, а потом положительные
            //(0 считать положительным)
            





            //3
            // Написать программу, которая предлагает пользователю
            //      ввести число
            //      и считает, сколько раз это число
            //встречается в массиве (показывает это число на экран без дублирования).





            //4
            // В двумерном массиве порядка M на N поменяйте
            //местами заданные столбцы.

            int nn = 4;
            int m = 5;
            Random rnd = new Random();
            int[,] a = new int[m, nn];
            nn = rnd.Next(5, 10);
            m = rnd.Next(5, 10);
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    a[i, j] = rnd.Next(10);
                }
            }


            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    Console.Write(" {0} ", a[i, j]);
                }
                Console.WriteLine();
            }

            Console.Write("Меняем местами первый и предпоследний столбцы: ");
            int tmp;
            for (int i = 0; i < a.GetLength(0); i++)
            {
                tmp = a[i, 0];
                a[i, 0] = a[i, a.GetLength(1) - 2];
                a[i, a.GetLength(1) - 2] = tmp;
            }

            Console.ReadLine();


        }
    }
}
        
    

