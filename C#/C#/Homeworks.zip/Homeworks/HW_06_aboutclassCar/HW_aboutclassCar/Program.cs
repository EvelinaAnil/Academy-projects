﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_aboutclassCar
{


   
    class Car
    {
        public string Name { get; set; }
        public int Age_birth { get; set; }

        public int MAX_Speed { get; set; }
        public string Mark { get; set; }

        public void  SetName(string n)
        {
            Name = n;
        }
        public string GetName()
        {
            return Name;
        }

        public void SetAge_birth(int n)
        {
            Age_birth = n;
        }
        public int GetAge_birth()
        {
         return Age_birth;
        }
        public void SetMAXSpeed(int n)
        {
            MAX_Speed = n;
        }
        public int GetMAXSpeed()
        {
            return MAX_Speed;
        }
        public void SetMark(string n)
        {
            Mark = n;
        }
        public string GetMark()
        {
            return Mark;
        }

       public Car(string name, int age_birth,int MAX_sp, string mark)
        {
            Name = name;
            Age_birth = age_birth;
            Mark = mark;
            MAX_Speed = MAX_sp;
        }
      public  Car()
        {
            Name = "";
            Age_birth = 0;
            MAX_Speed =0;
            Mark = "";
        }
        public void Print()
        {
            Console.WriteLine($" Name:{Name} Age:{Age_birth} MAX Speed:{MAX_Speed}  Marck:{Mark} ");
        }
    }
    public Car[] cars1;

    public void InfTovar()
    {
        Console.Write("Введите количество товаров: ");
        int nTovar = int.Parse(Console.ReadLine());
        Car = new Car[nTovar];
        for (int i = 0; i < tovar.Length; ++i)
        {
            Console.WriteLine($"Введите данные о {i + 1} товаре:");
            tovar[i] = new Car();
            tovar[i].InputP();
        }
    }
    public void ShoW()
    {
        for (int i = 0; i < .Lenght; i++)
        {
            Car st =new Car();
                st.Print();
        }
    }
    
    internal class Program
    {
        static void Main(string[] args)
        {
            Car st = new Car();
            st.SetName("");
            st.SetMark("");
            st.SetAge_birth(1997);
            Console.WriteLine($"Name:{st.GetName()}  Age:{st.GetAge_birth()}  Mark:{st.GetMark()}");
            Car[] cars = new Car[] { new Car("",33,"") ,new Car ("",23,"") };
            Car[] cars2 = new Car[] { st };
            foreach (Car car in cars)
            {
                Console.Write($"{car}");
            }
            foreach (Car car in cars2)
            {
                Console.Write($"{car}");
            }
       
            
             Console.ReadKey();
        }
    }
}
