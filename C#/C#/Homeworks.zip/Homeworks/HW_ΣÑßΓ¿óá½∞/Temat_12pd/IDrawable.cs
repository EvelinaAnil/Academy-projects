﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temat_12pd
{
    interface IDrawable
    {
        void Draw();
        void Move();
    }
}
