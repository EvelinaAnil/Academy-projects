﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temat_08pd
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int menu;
            DoShape shapes = new DoShape();
            do
            {
                Console.WriteLine("\n\tMAIN MENU");
                Console.WriteLine("1. ADD");
                Console.WriteLine("2. DELETE");
                Console.WriteLine("3. SHAPE'S INFO");
                Console.WriteLine("4. ALL SHAPE'S INFO");
                Console.WriteLine("5. SHAPE'S AREA");
                Console.WriteLine("6. SHAPE'S PERIMETER");
                menu = int.Parse(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        shapes.AddShape();
                        break;

                    case 2:
                        shapes.DeleteShape();
                        break;

                    case 3:
                        shapes.ShowShape();
                        break;

                    case 4:
                        shapes.ShowAllShapes();
                        break;

                    case 5:
                        shapes.FindArea____OfFigure();
                        break;

                    case 6:
                        shapes.FindPerimeterOfFigure();
                        break;

                    default:
                        if (menu > 5 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
                        break;
                }
            } while (menu != 0);
        }
    }
}
