﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temat_08pd
{
    internal class DoShape
    {
        List<Shape> shape__s = new List<Shape>();
        public void AddShape()
        {
            double fal1, fal2, fal3;
            int menu;
            do
            {
                Console.WriteLine("\n\tMENU FOR ADDING FIGURES");
                Console.WriteLine("1| Add square");
                Console.WriteLine("2| Add triangle");
                Console.WriteLine("3| Add rectangle");
                Console.WriteLine("4| Add circle");
                menu = int.Parse(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        Console.Write("\nInput Side: ");
                        fal1 = Double.Parse(Console.ReadLine());
                        shape__s.Add(new Square(fal1));
                        break;

                    case 2:
                        Console.Write("\nInput Side_1: ");
                        fal1 = Double.Parse(Console.ReadLine());
                        Console.Write("Input Side_2: ");
                        fal2 = Double.Parse(Console.ReadLine());
                        Console.Write("Input Angle Between: ");
                        fal3 = Double.Parse(Console.ReadLine());
                        shape__s.Add(new Triangle(fal1, fal2, fal3));
                        break;

                    case 3:
                        Console.Write("\nInput  Side_1: ");
                        fal1 = Double.Parse(Console.ReadLine());
                        Console.Write("Input Side_2: ");
                        fal2 = Double.Parse(Console.ReadLine());
                        shape__s.Add(new Rectangle(fal1, fal2));
                        break;

                    case 4:
                        Console.Write("\nInput Radius: ");
                        fal1 = Double.Parse(Console.ReadLine());
                        shape__s.Add( new Circle(fal1));
                        break;

                    default:
                        if (menu > 4 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU\n");
                        break;
                }
            } while (menu != 0);

        }
        public void DeleteShape()
        {
            if (shape__s.Count != 0)
            {
                int id;
                Console.Write("\nInput the ID : ");
                id = int.Parse(Console.ReadLine());

                if (id >= 1 && id <= shape__s.Count)
                {
                    shape__s.RemoveAt(id - 1);
                    Console.WriteLine("\tDELETED succesfully!");
                }
                else
                {
                    Console.WriteLine("\tWRONG ID!\n");
                }
            }
            else
            {
                Console.WriteLine("\n\tNO SHAPE'S IN LIST. ADD NEW SHAPE!");
            }
        }
        public void FindArea____OfFigure()
        {
            if (shape__s.Count != 0)
            {
                int id;
                Console.Write("\nInput the ID : ");
                id = int.Parse(Console.ReadLine());
                double result = shape__s[id - 1].ShapeArea();
                Console.WriteLine("\tResult: {0:F2}", result);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("\n\tNO SHAPE'S IN LIST. ADD NEW SHAPE!");
            }
        }
        public void FindPerimeterOfFigure()
        {
            if (shape__s.Count != 0)
            {
                int id;
                Console.Write("\nInput the ID : ");
                id = int.Parse(Console.ReadLine());
                double result = shape__s[id - 1].ShapePerimeter();
                Console.WriteLine("\tResult: {0:F2}", result);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("\n\tNO SHAPE'S IN LIST. ADD NEW SHAPE!");
            }
        }
        public void ShowShape()
        {
            if (shape__s.Count != 0)
            {
                int id;
                Console.Write("\nInput the ID : ");
                id = int.Parse(Console.ReadLine());
                if (id > 0 && id <= shape__s.Count)
                {
                    Console.WriteLine();
                    shape__s[id - 1].Show();
                }
                else
                {
                    Console.WriteLine("\n\tWRONG ID!");
                }
            }
            else
            {
                Console.WriteLine("\n\tNO SHAPE'S IN LIST. ADD NEW SHAPE!");
            }
        }
        public void ShowAllShapes()
        {
            if (shape__s.Count != 0)
            {
                for (int i = 0; i < shape__s.Count; i++)
                {
                    Console.WriteLine($"\n\tShape # {i + 1}");
                    shape__s[i].Show();
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("\n\tThere's no shapes in this list. Add new shape.");
            }
        }
    }
}
