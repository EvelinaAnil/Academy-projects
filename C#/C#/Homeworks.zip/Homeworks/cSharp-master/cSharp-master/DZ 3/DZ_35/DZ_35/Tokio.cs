﻿using System;

namespace Japan
{
    class Tokio
    {
        private int population;
        public int Population { get; set; }
        public Tokio(int population)
        {
            Population = population;
        }
    }
}
