﻿using System;

namespace USA
{
    class NewYork
    {
        private int population;
        public int Population { get; set; }
        public NewYork(int population)
        {
            Population = population;
        }
    }
}
