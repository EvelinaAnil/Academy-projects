﻿using System;

namespace Ukraine
{
    class Kiev
    {
        private int population;
        public int Population { get; set; }
        public Kiev (int population)
        {
            Population = population;
        }
    }
}
