﻿using System;

namespace geiko.DZ_52.ui
{
    interface IRequest
    {
        float Sum { get; }

        void PrintRequest();
    }
}
