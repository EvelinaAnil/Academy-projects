﻿using System;

namespace geiko.DZ9.Entities
{
    /// <summary>
    /// Constant's list.
    /// </summary>
    public static class Constants
    {
        public const int BEST_SCORE = 21;
        public static int SHUFFLER_LIMT_SCORE = 17;
    }
}
