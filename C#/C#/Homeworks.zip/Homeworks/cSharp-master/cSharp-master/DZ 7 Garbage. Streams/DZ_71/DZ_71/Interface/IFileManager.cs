﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace geiko.DZ_71.Interface
{
    public interface IFileManager
    {
        /// <summary>
        /// User menu or map
        /// </summary>
        void FileManagerCarte();

    }
}
