﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace HW_05
{
    internal class Program
    {
       public struct KeyValueStruct
       {
            public int Key;
            public string Value;
       
            public static void ShoW(KeyValueStruct[] ss)
            {
                for (int i = 0; i < ss.Length; i++)
                {
                    Console.WriteLine($"{ss[i].Key} {ss[i].Value} {i}");
                }
            }
             public static void Sort(KeyValueStruct[] ss)
             {
                for (int i = 0; i < ss.Length; i++)
                {
                    for(int f = 0; f < ss.Length-1-i; f++) 
                        //"ss.Length-1-i" -> потому что -1 это след число ,а -i для сравнение прошлого 
                    {
                        if (ss[f + 1].Key < ss[f].Key) //по возрастанию "<"
                        { 
                             KeyValueStruct tmp = ss[i];
                            tmp = ss[f];
                            ss[f] = ss[f + 1];
                            ss[f + 1] = tmp;
                        }
                    }
                }
          
             }

            public static int BinarSearc(KeyValueStruct[] ss, int index, int length, int value)
            {
                for (int i = 0; i < length; i++)
                {
                    if (value==ss[i].Key)
                    {
                        Console.WriteLine(i);
                        return i;
                    }
                }
                return -1;
            }
            public static int BinarySearch(KeyValueStruct[] ss, int key)
            {
                /*Объявить статический метод 
                    * int BinarySearch(KeyValueStruct[] ss, int key), 
                    который по заданному ключу key находит индекс структуры в массиве ss. 
                    Если структуры с заданным ключом нет, метод возвращает -1. 
                   Элементы массива упорядочены по возрастанию ключа.*/
                if (ss == null)
                {
                    throw new ArgumentNullException("KeyValueStruct");
                }
                int Low = ss.GetLowerBound(0);
                return BinarSearc(ss, Low, ss.Length, key);

                //я попробовала переделать настоящий BinarySearch ,но не сильно получилось
            }
            //public static int BinarySearch(KeyValueStruct[] ss, int key)
            //{
            //     for (int i = 0; i < ss.Length; i++)
            //    {
            //        if (ss[i].Key == key)
            //        {
            //            return i;
            //        }
            //    }
            //    return -1;
            //}

            //[SecuritySafeCritical]
            //[ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
            //[__DynamicallyInvokable]
            //public static int BinarySearch(Array array, int index, int length, object value, IComparer comparer)
            //{
            //    if (array == null)
            //    {
            //        throw new ArgumentNullException("array");
            //    }

            //    int lowerBound = array.GetLowerBound(0);
            //    if (index < lowerBound || length < 0)
            //    {
            //        throw new ArgumentOutOfRangeException((index < lowerBound) ? "index" : "length", Environment.GetResourceString("ArgumentOutOfRange_NeedNonNegNum"));
            //    }

            //    if (array.Length - (index - lowerBound) < length)
            //    {
            //        throw new ArgumentException(Environment.GetResourceString("Argument_InvalidOffLen"));
            //    }

            //    if (array.Rank != 1)
            //    {
            //        throw new RankException(Environment.GetResourceString("Rank_MultiDimNotSupported"));
            //    }

            //    if (comparer == null)
            //    {
            //        comparer = Comparer.Default;
            //    }

            //    if (comparer == Comparer.Default && TrySZBinarySearch(array, index, length, value, out var retVal))
            //    {
            //        return retVal;
            //    }

            //    int num = index;
            //    int num2 = index + length - 1;
            //    object[] array2 = array as object[];
            //    if (array2 != null)
            //    {
            //        while (num <= num2)
            //        {
            //            int median = GetMedian(num, num2);
            //            int num3;
            //            try
            //            {
            //                num3 = comparer.Compare(array2[median], value);
            //            }
            //            catch (Exception innerException)
            //            {
            //                throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_IComparerFailed"), innerException);
            //            }

            //            if (num3 == 0)
            //            {
            //                return median;
            //            }

            //            if (num3 < 0)
            //            {
            //                num = median + 1;
            //            }
            //            else
            //            {
            //                num2 = median - 1;
            //            }
            //        }
            //    }
            //    else
            //    {
            //        while (num <= num2)
            //        {
            //            int median2 = GetMedian(num, num2);
            //            int num4;
            //            try
            //            {
            //                num4 = comparer.Compare(array.GetValue(median2), value);
            //            }
            //            catch (Exception innerException2)
            //            {
            //                throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_IComparerFailed"), innerException2);
            //            }

            //            if (num4 == 0)
            //            {
            //                return median2;
            //            }

            //            if (num4 < 0)
            //            {
            //                num = median2 + 1;
            //            }
            //            else
            //            {
            //                num2 = median2 - 1;
            //            }
            //        }
            //    }

            //    return ~num;
            //}

            //[MethodImpl(MethodImplOptions.InternalCall)]
            //[SecurityCritical]
            //[ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
            //private static extern bool TrySZBinarySearch(Array sourceArray, int sourceIndex, int count, object value, out int retVal);


            //private static int BinarySearch(KeyValueStruct[] ss, int low, int length, int key)
            //{
            //    return BinarySearch(ss,  length, key);
            //}

            //public static void FindMyObject(Array myArr, object myObject)
            //{

            //    [ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
            //    [__DynamicallyInvokable]
            //    public static int BinarySearch(Array array, object value)
            //    {
            //        if (array == null)
            //        {
            //            throw new ArgumentNullException("array");
            //        }

            //        int lowerBound = array.GetLowerBound(0);
            //        return BinarySearch(array, lowerBound, array.Length, value, null);
            //    }
            //    [ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
            //    [__DynamicallyInvokable]
            //    public static int BinarySearch(Array array, int index, int length, object value)
            //    {
            //        return BinarySearch(array, index, length, value, null);
            //    }
            //public static int BinarySearch(Array array, object value)
            //{
            //    if (array == null)
            //    {
            //        throw new ArgumentNullException("array");
            //    }

            //    int lowerBound = array.GetLowerBound(0);
            //    return BinarySearch(array, lowerBound, array.Length, value, null);
            //    if (myIndex < 0)
            //    {
            //        Console.WriteLine("The object to search for ({0}) is not found. The next larger object is at index {1}.", myObject, ~myIndex);
            //    }
            //    else
            //    {
            //        Console.WriteLine("The object to search for ({0}) is at index {1}.", myObject, myIndex);
            //    }
            //}
            //    if (myIndex < 0)
            //    {
            //        Console.WriteLine("The object to search for ({0}) is not found. The next larger object is at index {1}.", myObject, ~myIndex);
            //    }
            //    else
            //    {
            //        Console.WriteLine("The object to search for ({0}) is at index {1}.", myObject, myIndex);
            //    }
            //}

            /* Объявить статический метод KeyValueStruct[] 
             * Merge(KeyValueStruct[] s1, KeyValueStruct[] s2)
             * , который сливает два упорядоченных массива структур в третий,
             * тоже упорядоченный.Элементы массивов упорядочены по возрастанию ключа.*/
            public static KeyValueStruct[] Merge(KeyValueStruct[] s1, KeyValueStruct[] s2)
            {
                KeyValueStruct[] s3 = new KeyValueStruct[s1.Length + s2.Length]; 
                // S3 ->length делаем
                Array.Copy(s1, s3, s1.Length);
                //copy с S1 в S1
                Array.Copy(s2, 0, s3, s1.Length, s2.Length); 
                //copy с S2 в S3 (не забываем S1)
                KeyValueStruct.Sort(s3);            
                return s3;
            }

       }
        static void Main(string[] args)
        {
            KeyValueStruct[] ss = new KeyValueStruct[5];
            ss[0].Key = 11;
            ss[1].Key = 19;
            ss[2].Key = 1;
            ss[3].Key = 14;
            ss[4].Key = 15;
            
            
            ss[0].Value = "Tien";
            ss[1].Value = "Veertig";
            ss[2].Value = "Eenentwintig";
            ss[3].Value = "Vijftien";
            ss[4].Value = "Twee";
            

            KeyValueStruct.ShoW(ss);
            Console.WriteLine("=-p0=-=-=--=-=-=-=-==0=0==-=-=-=-=0=0=0=0==-=-=0==-");
            KeyValueStruct.Sort(ss);
            KeyValueStruct.ShoW(ss);


            Console.WriteLine("=-p0");
            Console.WriteLine("Index[4]:", KeyValueStruct.BinarySearch(ss,4));
            Console.WriteLine("Index[0]:", KeyValueStruct.BinarySearch(ss,11));
            //Console.WriteLine("Index[2]:", KeyValueStruct.BinarySearch(ss, 2));
            Console.WriteLine("=-p0=-=-=--=-=-=-=-==0=0==-=-=-=-=0=0=0=0==-=-=0==-");
            KeyValueStruct[] ss_1 = new KeyValueStruct[5];
            ss_1[0].Key = 21;
            ss_1[1].Key = 22;
            ss_1[2].Key = 43;
            ss_1[3].Key = 24;
            ss_1[4].Key = 25;
           

            ss_1[0].Value = "ZesTien";
            ss_1[1].Value = "Vijftig";
            ss_1[2].Value = "Tweeentwintig";
            ss_1[3].Value = "Veertien";
            ss_1[4].Value = "Tweede";



           
            KeyValueStruct[] r = KeyValueStruct.Merge(ss, ss_1);
            KeyValueStruct.ShoW(r);
            
            Console.ReadKey();
        }
    }
}
