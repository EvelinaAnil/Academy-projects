﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_еом_фигура
{
     class Program
    {
        abstract class Figures
        {
           public virtual void S()
            {

            }
            public virtual void P()
            {

            }
        }
          class Trangle : Figures
        {
            public override void S()
            {
                double x= Convert.ToDouble(Console.ReadLine()), y= Convert.ToDouble(Console.ReadLine());
                
                Console.WriteLine("Введите высоту:");
                Console.Write(x);
                if (x > 0) { 
                Console.WriteLine("Введите сторону:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s;
                        s = ((x * y) / 2);
                        Console.WriteLine($"Площадь треугольника:{s}");
                    }
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine()), x1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите сторону 1:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите сторону 2:");
                    Console.Write(y);
                    if(y> 0)
                    {
                        Console.WriteLine("Введите сторону 3:");
                            Console.Write(x1);
                        if(x1 > 0)
                        {
                            double p = x + y + x1;
                            Console.WriteLine($"Периметр треугольника:{p}");
                        }
                    }
                    
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }
        }

         class Square : Figures
        {
            public override void S()
            {
                double x = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите сторону :");
                Console.Write(x);
                if (x > 0)
                {
                    double r = x * x;
                    Console.WriteLine($"Площадь квадрата:{r}");
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите сторону :");
                Console.Write(x);
                if (x > 0)
                {
                    double r = x*4;
                    Console.WriteLine($"Периметр квадрата:{r}");
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }

            }
        }
         class Rectangle : Figures
        {
            
            public override void S()
            {double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите сторону 1:");
                Console.Write(x);
                if(x > 0)
                {
                    Console.WriteLine("Введите сторону 2:");
                    Console.Write(y);
                    if(y > 0)
                    {
                        double s = x * y;
                        Console.WriteLine($"Площадь прямоугольника:{s}");
                    }
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Введите сторону 1:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите сторону 2:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s = (x*2)+(y*2);
                        Console.WriteLine($"Периметр прямоугольника:{s}");
                    }
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }
        }

         class Parallelogram : Figures
        {
            public override void S()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Введите сторону 1:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите высоту:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s = x * y;
                        Console.WriteLine($"Площадь параллелограма:{s}");
                    }
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Введите сторону 1:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите сторону 2:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s = (x*2) + (y*2);
                        Console.WriteLine($"Периметр параллелограма:{s}");
                    }
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }

        }
         class Trapezoid : Figures
        {
            public override void S()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите высоту:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите среднюю линию:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s = x * y;
                        Console.WriteLine($"Периметр трапеции:{s}");
                    }
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());
                double x1 = Convert.ToDouble(Console.ReadLine()), y1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Введите сторону 1:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите сторону 2:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        Console.WriteLine("Введите сторону 3:");
                        Console.Write(x1);
                        if(x1 > 0) { 
                        Console.WriteLine("Введите сторону 4:");
                        Console.Write(y1);
                            if (y1 > 0)
                            {
                                double s = x + x1 + y + y1;
                                Console.WriteLine($"Периметр трапеции:{s}");
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine(" must be >=0");
                }
            }
        }
         class Circle : Figures
        {

            public override void S()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите радиус:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите радиус:");
                    Console.Write(y);
                    if(y > 0)
                    {
                        double s = x * y ;
                        Console.WriteLine($"Площадь круга:{s}");
                    }
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите радиус:");
                Console.Write(x);
                if (x > 0)
                {
                    
                  
                        double s = (2*x)*3.14;
                        Console.WriteLine($"Площадь круга:{s}");
                    
                }
            }
        }

         class Ellipsis : Figures
        {
            public override void S()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите большую полусть:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите малая полусть:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s = x*y*3.14;
                        Console.WriteLine($"Площадь круга:{s}");
                    }
                }
            }
            public override void P()
            {
                double x = Convert.ToDouble(Console.ReadLine()), y = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите большую полусть:");
                Console.Write(x);
                if (x > 0)
                {
                    Console.WriteLine("Введите малую полусть:");
                    Console.Write(y);
                    if (y > 0)
                    {
                        double s = ((x*x)/9) + ((y*y)/90.25);
                        Console.WriteLine($"Площадь круга:{s}");
                    }
                }
            }

        }
            static void Main(string[] args)
        {
            
            Circle circle = new Circle();
           Console.WriteLine( circle.S());


            Console.ReadKey();
        }
    }
}
