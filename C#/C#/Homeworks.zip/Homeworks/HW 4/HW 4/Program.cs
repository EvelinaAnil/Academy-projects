﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_4
{
     class Program
    {
        public struct Parsing
        {
            public int character, letter, upper, lower, digit, punctuation, gap;
            public void Print()
            {
                Console.WriteLine(String.Format("\n character = \t{0} \n letter = \t{1} \n upper = \t{2} \n lower = \t{3} \n digit = \t{4} \n punctuation = \t{5} \n gap = \t\t{6}",
                    character, letter, upper, lower, digit, punctuation, gap));
            }
        }
        static void Main(string[] args)
        {
            //1
            Console.WriteLine("Give me a string, please.");
            string line;
            line = Console.ReadLine();

            bool res = String.IsNullOrEmpty(line);
            if (res == true)
            {
                Console.WriteLine("String is empty.");
                Console.ReadKey();
                return;
            }
            else
            {
                Parsing Statistics = new Parsing();

                foreach (char elem in line)
                {
                    Statistics.character++;
                    if (Char.IsLetter(elem) == true) Statistics.letter++;
                    if (Char.IsUpper(elem) == true) Statistics.upper++;
                    if (Char.IsLower(elem) == true) Statistics.lower++;
                    if (Char.IsDigit(elem) == true) Statistics.digit++;
                    if (Char.IsPunctuation(elem) == true) Statistics.punctuation++;
                    if (Char.IsWhiteSpace(elem) == true) Statistics.gap++;
                }
                Statistics.Print();
            }


            //2

            Console.WriteLine("Input what you want to write: ");
            string str = Console.ReadLine();
            string[] mas = str.ToLower().Split(new char[] { ',', '.', ':', ';', ' ', '!', '?', '-' },
                StringSplitOptions.RemoveEmptyEntries);
            string[] newMas = new string[mas.Length];
            char ch;
            for (int i = 0; i < mas.Length; i++)
            {
                ch = mas[0][0];
                newMas[i] = mas[i].Replace(ch.ToString(), "");
                if (i == 0)
                    Console.Write(ch);
                Console.WriteLine(newMas[i]);
            }
            Console.WriteLine();

            //3
            string s = "";
            Console.Write("String:\n");
            s = Console.ReadLine();
            int n = s.Length;
            int k = 0;

            for (int i = n - 1; i >= 0; i--)
            {
                if (s[i] >= '0' && s[i] <= '9')
                {
                    for (int j = i; j < n - k - 1; j++)
                    {
                        s.Replace(s[j], s[j + 1]);
                       
                    }
                    k++;
                }
            }

            Console.Write(s);
            Console.Write("\n");


            Console.Write(s);




            //4


            //const int M = 6;
            //const int N = 5;
            //const int L = M+N;
            //int[] arrM = {M};
            //int[] arrN = {N};
            //int[] arrL = {L};
            //for (int i = 0; i < M; i++)
            //{
            //    Console.WriteLine("Введите ", i + 1, " элемент массива mas1: "); 
            //    Console.Write( arrM[i]);
            //}
            //for (int i = 0; i < N; i++)
            //{
            //    Console.WriteLine("Введите ", i + 1, " элемент массива mas1: ");
            //    Console.Write(arrN[i]);
            //}
            //int j = 0;
            //int k = 0;
            //while (j < M)
            //{
            //    for (int i = 0; i < N; i++)
            //    {                    
            //        int p = 0;
            //        if (arrM[i] == arrN[j]) 
            //        {
            //            for (int l = 0; l < L; l++)
            //                if (arrM[i] == arrL[l]) 
            //                    p += 1;
            //            if (p == 0) 
            //            {
            //                arrL[k] = arrM[i];
            //                Console.Write(k + 1);
            //                Console.WriteLine(" элемент массива mas3 равен ");
            //                Console.Write(arrL[k]);
            //                k += 1;
            //            }
            //        }
            //    }
            //    j++;
            //}


            //5
            //Random rand = new Random();
            //int size = 5;
            //int[,] arr = new int[size, size];
            //int sum = 0;
            //int min, max;


            //for (int i = 0; i < size; i++)
            //{
            //    for (int j = 0; j < size; j++)
            //    {
            //        arr[i, j] = rand.Next(-100, 100);
            //        Console.Write(arr[i, j] + " ");
            //    }
            //    Console.WriteLine();
            //}


            //int iMin = 0, jMin = 0;
            //int iMax = 0, jMax = 0;
            //min = arr[0, 0];
            //max = arr[0, 0];
            //for (int i = 0; i < size; i++)
            //{
            //    for (int j = 0; j < size; j++)
            //    {
            //        if (arr[i, j] < min)
            //        {
            //            min = arr[i, j];
            //            iMin = i;
            //            jMin = j;
            //        }
            //        if (arr[i, j] > max)
            //        {
            //            max = arr[i, j];
            //            iMax = i;
            //            jMax = j;
            //        }
            //    }
            //}

            //Console.WriteLine(iMin);
            //Console.WriteLine(jMin);
            //Console.WriteLine(iMax);
            //Console.WriteLine(jMax);
            //for (int i = iMin; i < iMax; i++)
            //{
            //    for (int j = jMin; j < jMax; j++)
            //    {
            //        sum += arr[i, j];
            //    }
            //}


            //Console.WriteLine(min);
            //Console.WriteLine(max);
            //Console.WriteLine(sum);


            //6
            int[] mass = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write("Число жильцов квартиры номер\t");
                Console.Write(i + 1);
                 Console.Write(ReferenceEquals(mass[i], "="));
            }

            for (int i = 0; i < n; i++)
            {
                Console.Write("masInt #");
                Console.Write(i + 1);
                Console.Write(" = ");
                Console.Write(mass[i]);
                Console.Write("\n");

            }
            int a;
            Console.Write("введите номер квартиры");
            Console.Write("\n");
            a = int.Parse(ConsoleInput.ReadToWhiteSpace(true));
            Console.Write("в квартире номер");
            Console.Write(a);
            Console.Write("\t\\");
            Console.Write(mass[a - 1]);
            Console.Write("жильцов");
            Console.Write("\n");

            Console.Write("многодетные живут в квартирах:");
            Console.Write("\n");
            for (int i = 0; i < n; i++)
            {

                if (mass[i] > 5)
                {
                    Console.Write(i + 1);
                    Console.Write("\n");
                }
            }
        }

        

        internal static class ConsoleInput
        {
            private static bool goodLastRead = false;
            public static bool LastReadWasGood
            {
                get
                {
                    return goodLastRead;
                }
            }

            public static string ReadToWhiteSpace(bool skipLeadingWhiteSpace)
            {
                string input = "";

                char nextChar;
                while (char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
                {
                    //accumulate leading white space if skipLeadingWhiteSpace is false:
                    if (!skipLeadingWhiteSpace)
                        input += nextChar;
                }
                //the first non white space character:
                input += nextChar;

                //accumulate characters until white space is reached:
                while (!char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
                {
                    input += nextChar;
                }

                goodLastRead = input.Length > 0;
                return input;
            }

            public static string ScanfRead(string unwantedSequence = null, int maxFieldLength = -1)
            {
                string input = "";

                char nextChar;
                if (unwantedSequence != null)
                {
                    nextChar = '\0';
                    for (int charIndex = 0; charIndex < unwantedSequence.Length; charIndex++)
                    {
                        if (char.IsWhiteSpace(unwantedSequence[charIndex]))
                        {
                            //ignore all subsequent white space:
                            while (char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
                            {
                            }
                        }
                        else
                        {
                            //ensure each character matches the expected character in the sequence:
                            nextChar = (char)System.Console.Read();
                            if (nextChar != unwantedSequence[charIndex])
                                return null;
                        }
                    }

                    input = nextChar.ToString();
                    if (maxFieldLength == 1)
                        return input;
                }

                while (!char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
                {
                    input += nextChar;
                    if (maxFieldLength == input.Length)
                        return input;
                }

                return input;
            }
            
        }





        
        }
}

