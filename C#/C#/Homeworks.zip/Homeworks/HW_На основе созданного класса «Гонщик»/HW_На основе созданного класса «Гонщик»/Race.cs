﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace HW_На_основе_созданного_класса__Гонщик_
{
    [Serializable]
    internal class Race
    {
        //страна, рейтинг, количество пройденных этапов
        public string AllName { get; set; } 
        public DateTime DateOfBirth { get; set; }
        public string Country { get; set; } 
        public int Rating { get; set; } 
        public int AmountOfParticipation { get; set; } 


        public Race()
        {
            AllName = "Wendy Krisofer Robert";
            DateOfBirth = Convert.ToDateTime("14.11.1998");
            Country = "Ukraine";
            Rating = 5;
            AmountOfParticipation = 10;
        }


        public Race(string _AllName, string _DateOfBirth, string _country, int _rating, int _AmountOfParticipation)
        {
            if 
                (String.IsNullOrWhiteSpace(_AllName)) 
                throw new Exception();

            if 
                (String.IsNullOrWhiteSpace(_DateOfBirth))
                throw new Exception();

            if 
                (String.IsNullOrWhiteSpace(_country)) 
                throw new Exception();

            if
                (_rating < 0 || _rating >= 100) 
                throw new Exception();

            if 
                (_AmountOfParticipation < 0)
                throw new Exception();

            AllName = _AllName;
            try
            {
                DateOfBirth = Convert.ToDateTime(_DateOfBirth);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Country = _country;
            Rating = _rating;
            AmountOfParticipation = _AmountOfParticipation;
        }


        public void Show()
        {
            Console.WriteLine( $"\nAll_name: {AllName}" +$"\nBirth_Of_Date: {DateOfBirth.ToShortDateString()}" +$"\nCountry: {Country}" +$"\nRating: {Rating}" +
$"\nAmount_Of_Participation : {AmountOfParticipation}");
        }
    }
}
