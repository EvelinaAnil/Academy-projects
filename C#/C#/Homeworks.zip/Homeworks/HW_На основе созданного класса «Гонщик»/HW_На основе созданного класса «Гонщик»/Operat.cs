﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace HW_На_основе_созданного_класса__Гонщик_
{
    internal class RacerList
    {
        private List<Race> _racers = null;
        public RacerList()
        {
            _racers = new List<Race>();
        }
        public void Add(Race obj)
        {
            _racers.Add(obj);
        }
        public void Del(int id)
        {
            _racers.RemoveAt(id);
            Console.WriteLine("\tDELETE SUCSESS!");
        }
        public void EditInfo(int id)
        {
            Race obj = _racers[id];
            int menu;
            do
            {
                Console.WriteLine("\tMENU FOR CHANGING INFORMATION");
                Console.WriteLine("1) ALL NAME");
                Console.WriteLine("2) BIRTH OF DATE");
                Console.WriteLine("3) COUNTRY");
                Console.WriteLine("4) RAITING");
                Console.WriteLine("5) AMOUNT OF PARTICIPATION");
                Console.WriteLine("6) ALL INFORMATION");
                menu = int.Parse(Console.ReadLine());
                switch (menu)
                {
                    case 1:
                        try
                        {
                            Console.WriteLine("Input all name:");
                            obj.AllName = Console.ReadLine();
                            Console.WriteLine("\tSET SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 2:
                        try
                        {
                            Console.WriteLine("Input birth of date (dd.MM.yyyy):");
                            obj.DateOfBirth = Convert.ToDateTime(Console.ReadLine());
                            Console.WriteLine("\tSET SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 3:
                        try
                        {
                            Console.WriteLine("Input country:");
                            obj.Country = Console.ReadLine();
                            Console.WriteLine("\tSET SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 4:
                        try
                        {
                            Console.WriteLine("Input rating(1-100):");
                            obj.Rating = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("\tSET SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 5:
                        try
                        {
                            Console.WriteLine("Input Amount Of Participation:");
                            obj.AmountOfParticipation = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("\tSET SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 6:
                        try
                        {
                            Console.WriteLine("Input full name:");
                            obj.AllName = Console.ReadLine();

                            Console.WriteLine("Input birth of date (dd.MM.yyyy):");
                            obj.DateOfBirth = Convert.ToDateTime(Console.ReadLine());

                            Console.WriteLine("Input country:");
                            obj.Country = Console.ReadLine();

                            Console.WriteLine("Input rating(1-100):");
                            obj.Rating = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Input Amount Of Participation:");
                            obj.AmountOfParticipation = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("\tSET ALL SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    default:
                        if (menu > 6 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
                        break;
                }
            } while (menu != 0);
        }
public void SortListByFullName()
        {
            _racers.Sort(SortByFullName);
        }
        public void SortListByAge()
        {
            _racers.Sort(SortByAge);
        }
        public void SortListByNumberOfParticipations()
        {
            _racers.Sort(SortByNumberOfParticipations);
        }
        private static int SortByFullName(Race f, Race s)
        {
            return f.AllName.CompareTo(s.AllName);
        }
        private static int SortByAge(Race f, Race s)
        {
            return f.DateOfBirth.CompareTo(s.DateOfBirth);
        }
        private static int SortByNumberOfParticipations(Race f, Race s)
        {
            return f.AmountOfParticipation.CompareTo(s.AmountOfParticipation);
        }

public int FindRacer(string fullName)
        {
            foreach (Race r in _racers)
            {
                if (r.AllName == fullName)
                {
                    return _racers.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE RACER WAS NOT FOUND");
        }
        public void ShowRacer(string fullName)
        {
            _racers[FindRacer(fullName)].Show();
        }
        public void ShowAll()
        {
            if (_racers.Count > 0)
            {
                for (int i = 0; i < _racers.Count; i++) 
                {
                    Console.WriteLine($"\tRacer # {i + 1}");
                    _racers[i].Show(); 
                    Console.WriteLine(); 
                }
            }
            else
            {
                Console.WriteLine("\tLIST IS EMPTY!!");
            }

        }
        public void Save(string path)
        {
            using (var fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, _racers);
            }
        }
        public void Load(string path)
        {
            List<Race> tmp = new List<Race>();
            try
            {
                using (var fr = new FileStream(path, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    tmp = bf.Deserialize(fr) as List<Race>;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            _racers = tmp;
        }
    }
}
