﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
             На основе созданного класса «Гонщик» (страна, рейтинг, количество пройденных этапов), написать программу “Система управления журналом соревнований”.

            1.Система должна поддерживать следующую функциональность: 

	        - запись в файл информации об участниках гонки (список участников)
	        - чтение из файла информации об участниках
	        - редактирование данных указанного участника в файле, а также основных характеристик соревнований  
	        - удаление данных из файла по указанному критерию (по имени участника, по стране, по рейтингу)
	        - добавление информации об участниках в файл (один участник, команда)

            2.Реализовать интерфейс (меню) осуществления управления через систему.

             */
namespace HW_На_основе_созданного_класса__Гонщик_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            RacerList racerList = new RacerList();

            string s1, s2, s3;
            int ival1, ival2;
            int menu;
            do
            {
                Console.WriteLine("\n\tMAIN MENU");
                Console.WriteLine("1. ADD");
                Console.WriteLine("2. DELETE");
                Console.WriteLine("3. EDIT INFO");
                Console.WriteLine("4. SHOW");
                Console.WriteLine("5. SHOW ALL");
                Console.WriteLine("6. SORT");
                Console.WriteLine("7. SAVE");
                Console.WriteLine("8. LOAD");
                menu = int.Parse(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        try
                        {
                            Console.WriteLine("Input Name:");
                            s1 = Console.ReadLine();

                            Console.WriteLine("Input birth of date (dd.MM.yyyy):");
                            s2 = Console.ReadLine();

                            Console.WriteLine("Input country:");
                            s3 = Console.ReadLine();

                            Console.WriteLine("Input rating(1-100):");
                            ival1 = int.Parse(Console.ReadLine());

                            Console.WriteLine("Input Amount Of Participation:");
                            ival2 = int.Parse(Console.ReadLine());

                            racerList.Add(new Race(s1, s2, s3, ival1, ival2));
                            Console.WriteLine("\tADD SUCSESS!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 2:
                        Console.WriteLine("Input name:");
                        racerList.Del(racerList.FindRacer(Console.ReadLine()));
                        break;

                    case 3:
                        Console.WriteLine("Input name:");
                        racerList.EditInfo(racerList.FindRacer(Console.ReadLine()));
                        break;

                    case 4:
                        try
                        {
                            Console.WriteLine("Input name:");
                            racerList.ShowRacer(Console.ReadLine());
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 5:
                        racerList.ShowAll();
                        break;

                    case 6:
                        do
                        {
                            Console.WriteLine("\n\tSORT MENU");
                            Console.WriteLine("1) Sort by name");
                            Console.WriteLine("2) Sort by age");
                            Console.WriteLine("3) Sort by Amount Of Participation");
                            menu = int.Parse(Console.ReadLine());

                            switch (menu)
                            {
                                case 1:
                                    racerList.SortListByFullName();
                                    break;

                                case 2:
                                    racerList.SortListByAge();
                                    break;
                                case 3:
                                    racerList.SortListByNumberOfParticipations();
                                    break;

                                default:
                                    if (menu > 4 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
                                    break;
                            }
                        } while (menu != 0);
                        break;

                    case 7:
                        try
                        {
                            Console.WriteLine("Input the name of file(for save):");
                            s1 = Console.ReadLine();
                            s1 += ".bin";
                            racerList.Save(s1);
                            Console.WriteLine("\tSAVED SUCSESS!");
                        }

                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 8:
                        try
                        {
                            Console.WriteLine("\n\tWil you save info before load this?");
                            Console.Write("\n1))) for continue\n2))) to back: \n");
                            ival1 = int.Parse(Console.ReadLine());
                            if (ival1 == 1)
                            {
                                Console.WriteLine("Input the name of file(for load):");
                                s1 = Console.ReadLine();
                                s1 += ".bin";
                                racerList.Load(s1);
                                Console.WriteLine("\tLOADED SUCSESS!");
                            }
                            else
                            {
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    default:
                        if (menu > 8 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
                        break;
                }
            } while (menu != 0);
        }
    }
}
