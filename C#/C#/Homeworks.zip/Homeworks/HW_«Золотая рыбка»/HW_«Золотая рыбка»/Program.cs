﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace HW__Золотая_рыбка_
{
     class Program
    {
        
        static void Main(string[] args)
        {
            OldBones oldBones = new OldBones("Old Bones", 57, "trough"); //trough->корыто
            int numberOfDesires = 3;

            for (int i = 0; i < numberOfDesires; i++)
            {
                Console.Write($"Input a wish {i + 1}: ");
                string property = Console.ReadLine();
                oldBones.ExecutionOfDesires(property, i + 1);
            }

            for (int i = 0; i <= numberOfDesires; i++)
            {
                oldBones.viewProperty(i);
            }

            Console.ReadLine();


        }
    }
}
