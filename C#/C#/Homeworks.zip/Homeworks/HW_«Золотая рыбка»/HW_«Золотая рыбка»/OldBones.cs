﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace HW__Золотая_рыбка_
{

    [Serializable]
     class OldBones //старуха "старые кости :)"
    {
        public string Naam;
        public int Age;
        public string Property;
        public OldBones()
        {
            Naam = "Old Bones";
            Age = 50;
            Property = "trough";//корыто
        }
        public OldBones(  string _Naam,int _Age,string _Property )
        {
            Naam = _Naam;
            Age = _Age;
            Property = _Property;
            ExecutionOfDesires(Property, 0);
        }
        BinaryFormatter format = new BinaryFormatter();
        public void ExecutionOfDesires(string _Property, int Num)
        {
            using (FileStream f_s = new FileStream(Num.ToString(), FileMode.OpenOrCreate))
            {
                format.Serialize(f_s, _Property);
            }
        }

        public void viewProperty(int Num)
        {
            using (FileStream f_s = new FileStream(Num.ToString(), FileMode.OpenOrCreate))
            {
                string Property = (string)format.Deserialize(f_s);
                Console.WriteLine($"Property: {Property}");
            }
        }

    }
}

    
        

   

