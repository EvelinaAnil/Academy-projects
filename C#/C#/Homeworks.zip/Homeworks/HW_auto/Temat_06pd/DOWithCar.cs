﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;

namespace Temat_06pd
{
    /*
      1.	Разработать класс Car, описывающий автомобиль 
      2.	Класс должен включать конструктор с параметрами, конструктор без параметров, поля, необходимые для описания автомобиля.
      3.	Создать класс, который будет содержать массив экземпляров класса Car.
      4.	Создать методы сортировки автомобилей по названию и по цене, методы для работы с данными (добавление, удаление), продемонстрировать работу этих методов.
    */
    internal class DoWithCar
    { 
        List<Car> cars = new List<Car>();
        public void Add(Car obj)
        {
            cars.Add(obj);
        }
        public void Del(int id)
        {
            cars.RemoveAt(id - 1);
        }
        public int SortByPrice(Car obj1, Car obj2)
        {
            return obj2.GetPrice().CompareTo(obj1.GetPrice()); 
        }
        public int SortByName(Car obj1, Car obj2)
        {
            return obj2.GetName().CompareTo(obj1.GetName()); 
        }
        public void SortCarsByPrice()
        {
            cars.Sort(SortByPrice);
        }
        public void SortCarsByName()
        {
            cars.Sort(SortByName);
        }
        public void Show()
        { for (int i = 0; i < cars.Count; i++)
            {
           Console.WriteLine($"\tCar# {i + 1}"); 
         cars[i].Show(); 
       Console.WriteLine(); 
            }
        }

    }
}
