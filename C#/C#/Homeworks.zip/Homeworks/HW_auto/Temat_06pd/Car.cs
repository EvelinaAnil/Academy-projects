﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Temat_06pd
{
    internal class Car
    {
        private string Name_;
        private string MOdel_;
        private string Type_; //like tayota,Sedan
        private string Gear_Box_;//like Automatic transmission
        private string Color_;
        private float Price_;
        private int Max_Speed_;
        private int Year_;//like Production year
        public Car()
        {
            Name_ = "Tayota";
            MOdel_ = "CH-R";
            Type_ = "Ren";
            Gear_Box_ = "Automatic transmission";
            Color_ = "White";
            Price_ = 8000;
            Max_Speed_ = 200;
            Year_ = 2019;
        }
        public Car(string name, string model, string type, string gearbox, string color, float price, int maxspeed, int year)
        {
            Name_ = name;
            MOdel_ = model;
            Type_ = type;
            Gear_Box_ = gearbox;
            Color_ = color;
            Price_ = price;
            Max_Speed_ = maxspeed;
            Year_ = year;
        }

        public Car(Car obj)
        {
            Name_ = obj.Name_;
            MOdel_ = obj.MOdel_;
            Type_ = obj.Type_;
            Gear_Box_ = obj.Gear_Box_;
            Color_ = obj.Color_;
            Price_ = obj.Price_;
            Max_Speed_ = obj.Max_Speed_;
            Year_ = obj.Year_;
        }
        //SET
        public void SetName(string name)
        {
            if (String.IsNullOrWhiteSpace(name))
            {
                throw new Exception("THE NAME Can't be empty!");
            }
            Name_ = name;
        }
        public void SetModel(string model)
        {
            if (String.IsNullOrWhiteSpace(model))
            {
                throw new Exception("THE MODEL Can't be empty!");
            }
            MOdel_ = model;
        }
        public void SetTypeOfVeh(string type)
        {
            if (String.IsNullOrWhiteSpace(type))
            {
                throw new Exception("THE TYPE Can't be empty!");
            }
            Type_ = type; 
        }
        public void SetGearBox(string gearbox)
        {
            if (String.IsNullOrWhiteSpace(gearbox))
            {
                throw new Exception("THE GWER BOX Can't be empty!");
            }
            Gear_Box_ = gearbox;
        }
        public void SetColor(string color)
        {
            if (String.IsNullOrWhiteSpace(color))
            {
                throw new Exception("THE COLOR Can't be empty!");
            }
            Color_ = color;
        }
        public void SetPrice(float price)
        {
            if (price == 0 || price < 0)
            {
                throw new Exception("THE PRICE Can't be NUL!, ZERO or LESS THAN ZERO!");
            }
            Price_ = price;
        }
        public void SetMaxSpeed(int maxspeed)
        {
            if (maxspeed == 0 || maxspeed < 0 || maxspeed > 500)
            {
                throw new Exception("THE MAX_SPEED Can't be ZERO or LESS THAN ZERO or MORE THEN 5 HUNDRED!");
            }
            Max_Speed_ = maxspeed;
        }
        public void SetProductionYear(int year)
        {
            if (year < 1999 || year > 2999 || year == 0 || year < 0)
            {
                throw new Exception("THE PRODUCTION_YEAR Can't be WRONG, CHECK input data!");
            }
            Year_ = year;
        }
       
        //GET
        public string GetName()
        {
            return Name_;
        }
        public string GetModel()
        {
            return MOdel_;
        }
        public string GetType()
        {
            return Type_;
        }
        public string GetGearBox()
        {
            return Gear_Box_;
        }
        public string GetColor()
        {
            return Color_;
        }
        public float GetPrice()
        {
            return Price_;
        }
        public int GetMaxSpeed()
        {
            return Max_Speed_;
        }
        public int GetProductionYear()
        {
            return Year_;
        }
        public void Show()
        {
            Console.WriteLine("Name: {0}\nModel: {1}\nType: {2}\nGear_box: {3}\nColor: {4}\nPrice(USD): {5}\nMaximal_Speed: {6}\nProduction_Year: {7}",
                Name_, MOdel_, Type_, Gear_Box_, Color_, Price_, Max_Speed_, Year_);
        }
      

        

        public string Type()
        {
            return "Car";
        }
        public string ToString()
        {
            return Type() + "-" + Name_ + "-" + MOdel_ + "-" + Type_ + "-" + Gear_Box_ + "-"
                + Color_ + "-" + Price_.ToString() + "-" + Max_Speed_.ToString() + "-" + Year_.ToString() + "-";
        }
    }
}
