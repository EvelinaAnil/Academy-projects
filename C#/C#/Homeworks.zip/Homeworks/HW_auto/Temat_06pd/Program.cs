﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temat_06pd
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DoWithCar a = new DoWithCar();
            a.Add(new Car());
            a.Add(new Car("Honda", "2023 ", "Civic", "Manual Transmission", "Black", 1500, 200, 2023));
            a.Add(new Car("Hyundai", "2022 ", "Elantra", "Automatic Transmission", "Green", 6900, 212, 2022));
            a.Show();
            Console.WriteLine("===============================");
            a.Del(2);
            a.Show();
            Console.ReadKey();
        }
    }
}
