﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1
            Console.Write("Введите A: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите B: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите C: ");
            int c = Convert.ToInt32(Console.ReadLine());
            int k = 0;
            int n = 0;
            int H = a / c;
            int V = b / c;
            if (a >= c)
            {
                while (a >= c)
                {
                    a -= c;
                    k++; //кол-во  по стороне А
                }
            }
            else
            {
                Console.WriteLine("a<c");
            }
            if (b >= c)
            {
                while (b >= c)
                {
                    b -= c;
                    n++; //кол-во  по стороне В
                }
            }
            else
            {
                Console.WriteLine("b < c");
            }
            int count = 0;
            for (int i = 0; i < k; i++)
                count += n;
            Console.WriteLine("N= " + count);
int y = a * b - c * c * H * V;
            Console.Write( "Незанятая площадь = ",y );


            //2
          
            float ii = 1000;
            int kk=0;
            Console.Write("Введите процент 0<P<25 p=: ");
            float oop =float.Parse(Console.ReadLine());
            if((oop > 0) &&(oop < 25))
            {
                kk = 0;
                while (ii <= 1100)
                {
                    ii = ii * (1 + oop / 100);
                    kk = kk + 1;
                }
            }
            else
            {
                Console.WriteLine("niet recht");
            }
            Console.WriteLine("Число месяцев=", kk);
            Console.WriteLine(" Pазмер вклада=", ii);

            //3
            int f= int.Parse(Console.ReadLine());
            int t = int.Parse(Console.ReadLine());

            for (Console.WriteLine(); f <= t; Console.WriteLine(), f++)
                for (int i = 1; i <= f; i++)
                    Console.Write("{0}", f);

            Console.ReadKey();
            //4
            Console.WriteLine("Введите N");
            int N = int.Parse(Console.ReadLine());
            string obr = "";

            while (N > 9)
            {
                obr += (N % 10).ToString();
                N = N / 10;
            }

            obr += N.ToString();
            Console.WriteLine("Число наоборот " + obr);

        }

    }
}
