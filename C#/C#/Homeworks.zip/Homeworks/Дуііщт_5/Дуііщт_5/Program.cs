﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Дуііщт_5
{
    struct Dimension
    {
       public double Height /* = 5.8 */;
        public double Weight;
        public Dimension(double h,double w) { Height = h; Weight = w; }

        public void SetW(double w)
        {
            Weight = w;
        }
        public double GetW()
        {
            return Weight;
        }

        public void Print()
        {
            Console.WriteLine($"Height: {Height} Width: {Weight}");
        }
    }

    class Program
    {
        enum Suits { Clubs, Diamonds, Hearts, Spades }

        enum Cats { Tiger = 1, Lion = 34, Puma/* = 35 */ , Barsik = Puma + 4 }
        enum CommodityType // тип товара
        {
            FrozenFood, Food, DomesticChemistry, BuildingMaterials, Petrol
        }

        enum TransportType // тип транспорта
        {
            Semitrailer, Coupling, Refrigerator, OpenSideTruck, FuelTruck
        }

        enum Cars :byte {Ford,BMW,Nissan=254,Opel }

        //struct MyStruct { }
        static void Main(string[] args)
        {
            //18^38
          /*  foreach(Suits item  in Enum.GetValues(typeof(Suits)))
            {
                Console.Write($"{(int)item}");
                Console.WriteLine(item);
            }

            Console.WriteLine(Enum.IsDefined(typeof(Suits),7));*/
            Cats cat = Cats.Barsik;
            Suits suit = Suits.Clubs;
            Console.WriteLine((int)cat);
            switch (cat)
            {
                case Cats.Tiger:
                    break;
                    case Cats.Lion:
                    switch (suit)
                    {
                        case Suits.Clubs:
                            break;
                        case Suits.Diamonds:
                            break;
                        case Suits.Hearts:
                            break;
                        case Suits.Spades:
                            break;
                    }
                    break;
                case Cats.Puma:
                    break;
                case Cats.Barsik:
                    break;
                
            }
     

       
            Console.WriteLine("Введите число от 1 до 5");

            int number = int.Parse(Console.ReadLine());

            if (number > 0 && number < 6)
            {
                //CommodityType commodity = (CommodityType)Enum.GetValues(typeof(CommodityType)).GetValue(number - 1);

                CommodityType commodity = (CommodityType)(number - 1);

                TransportType transport = TransportType.Semitrailer;

                switch (commodity)
                {
                    case CommodityType.FrozenFood:
                        transport = TransportType.Refrigerator;
                        break;
                    case CommodityType.Food:
                        transport = TransportType.Semitrailer;
                        break;
                    case CommodityType.DomesticChemistry:
                        transport = TransportType.Coupling;
                        break;
                    case CommodityType.BuildingMaterials:
                        transport = TransportType.OpenSideTruck;
                        break;
                    case CommodityType.Petrol:
                        transport = TransportType.FuelTruck;
                        break;
                }
                Console.WriteLine("Для товара - {0} необходим транспорт - {1}.", commodity, transport);
            }
            else
            {
                Console.WriteLine("Ошибка ввода");
            }



            Cars car = Cars.Nissan;

            byte n = (byte)car;
            Console.WriteLine(n);

            Dimension dim = new Dimension();
            dim.SetW(23.344);
            dim.Print();
            Console.WriteLine($"Height: {dim.Height} Width: {dim.Weight}");

            Dimension dim1=new Dimension();
            Console.WriteLine($"Height: {dim1.Height} Width: {dim1.Weight}");

            int ch=Console.Read();
            Console.WriteLine(ch);
            Console.WriteLine((char)ch);

            ConsoleKeyInfo key=Console.ReadKey();


            Console.ReadKey();
        }
    }
}
