﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Soap;

namespace HW_Разработать_класс__Счет_для_оплаты_
{
    [Serializable]
    public class PayBill : ISerializable
    {
        public double PayByOneday { get; set; } //оплата за день
        public int numberofDays { get; set; } //количество дней
        public double fine { get; set; } //штраф за один день задержки оплаты
        public int numDayFine { get; set; } //количество дней задержи оплаты
       
        
        
        public double payable;
        public double sumFine;
        public double rezult;
        public static bool paybill;

        public double Sum_no_Fine()
        {
            return payable = PayByOneday * numberofDays;
        }
        public double Sum_Fine()
        {
            return sumFine = fine * numDayFine;
        }
        public double Rezult()
        {
            return rezult = payable + sumFine;
        }
        public PayBill() { }
        public void setBill()
        {
           
            Console.WriteLine("Enter the amount of payment per day:");
            PayByOneday = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter number of days:");
            numberofDays = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a penalty for one day of late payment:");
            fine = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the number of days to delay payment");
            numDayFine = Convert.ToInt32(Console.ReadLine());
        }

        public override string ToString()
        {
            return $@"
                -- pay per day  - {PayByOneday}
                -- number of days - {numberofDays};
                -- penalty for one day of late payment - {fine};
                -- number of days to delay payment - {numDayFine};
              Total:
                  -- amount payable without penalty - {payable};
                  -- fine - {sumFine};
                  -- amount due - {rezult}";
        }
        private PayBill(SerializationInfo info, StreamingContext context)
        {
            PayByOneday = info.GetDouble("pay per day");
            numberofDays = info.GetInt32("number of days");
            fine = info.GetDouble("penalty for one day of late payment");
            numDayFine = info.GetInt32("number of days to delay payment");
            if (paybill)
            {
                payable = info.GetDouble("amount payable without penalty");
                sumFine = info.GetDouble("fine ");
                rezult = info.GetDouble("amount due");
            }
        }
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("pay per day", PayByOneday);
            info.AddValue("number of days", numberofDays);
            info.AddValue("penalty for one day of late payment", fine);
            info.AddValue("number of days to delay payment", numDayFine);
            if (paybill)
            {
                info.AddValue("amount payable without penalty", payable);
                info.AddValue("fine", sumFine);
                info.AddValue("amount due", rezult);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            Console.ForegroundColor = ConsoleColor.Cyan;
            PayBill pb = new PayBill();
            pb.setBill();
            pb.Sum_no_Fine();
            pb.Sum_Fine();
            pb.Rezult();
            Console.WriteLine(pb);
            Console.WriteLine("Has payment been made?\n Press: \n[1] - Yes\n [2] - No\n");
            int answer = Convert.ToInt32(Console.ReadLine());
            if (answer == 1)
            {
                PayBill.paybill = true;
                Console.WriteLine("Full serialization!");
                SoapFormatter soapFormat = new SoapFormatter();
                try
                {
                    using (Stream fStream = File.Create("test1.soap"))
                    {
                        soapFormat.Serialize(fStream, pb);
                    }
                    Console.WriteLine("SoapSerialize OK!\n");

                    PayBill p = null;
                    using (Stream fStream = File.OpenRead("test1.soap"))
                    {
                        p = (PayBill)soapFormat.Deserialize(fStream);
                    }
                    Console.WriteLine(p);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            else
            {
                PayBill.paybill = false;
                Console.WriteLine("Partial serialization!");
                SoapFormatter soapFormat = new SoapFormatter();
                try
                {
                    using (Stream fStream = File.Create("test2.soap"))
                    {
                        soapFormat.Serialize(fStream, pb);
                    }
                    Console.WriteLine("SoapSerialize OK!\n");

                    PayBill p = null;
                    using (Stream fStream = File.OpenRead("test2.soap"))
                    {
                        p = (PayBill)soapFormat.Deserialize(fStream);
                    }
                    Console.WriteLine(p);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            Console.ReadKey();

        }
    }
}