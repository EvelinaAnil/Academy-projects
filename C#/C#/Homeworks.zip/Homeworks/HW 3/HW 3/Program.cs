﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			
			string line = Console.ReadLine();
	
			line = Console.ReadLine();
		
			Int32 size = 10;
			int[] jaggedDouble = new int[size];
			int rep = 0;
			int a = 0;
			for (int i = 0; i < size; i++)
			{
				Console.WriteLine("Enter digit:");
				jaggedDouble[i]= int.Parse(line);
			}
			Console.WriteLine();
			for (int i = 0; i < size; i++)
			{
				rep = jaggedDouble[i];
				a = 0;
				for (int j = 0; j < size; j++)
				{
					if (rep == jaggedDouble[j])
						a++;

				}
				if (a >= 2)
					Console.WriteLine(rep);
				Console.WriteLine();
			}
			Console.ReadKey();
		}
	}
}
