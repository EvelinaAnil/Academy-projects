﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            /*   // int size = 5;   Зубчатый массив!
             double[][] jaggedDouble = new double[random.Next(4,8)][];
            // jaggedDouble[0] = new double[3];
            // jaggedDouble[1] = new double[6];

             for (int i = 0; i < jaggedDouble.Length; i++)
             {
                 jaggedDouble[i] = new double[random.Next(4,9)];
             }
             for (int i = 0; i < jaggedDouble.Length; i++)
             {
                 for (int j = 0; j < jaggedDouble[i].Length; j++)
                 {
                     jaggedDouble[i][j] = random.NextDouble() + random.Next(5, 39);
                     Console.WriteLine("{0:F3}",jaggedDouble[i][j]);
                 }Console.WriteLine();
             }
             Array.Resize(ref jaggedDouble,9);
             Array.Resize(ref jaggedDouble[1], 5);
             */


            int[] arr = {24, 262, 23, 25, 24 };
            /* Array.Resize(ref arr, arr.Length + 1);

             arr[arr.Length - 1] = 21331;

             foreach (int item in arr)
             {
                 Console.Write("{0}", item);
             }
             Console.WriteLine();

             Array.Resize(ref arr, arr.Length - 2);

             foreach (int item in arr)
             {
                 Console.Write("{0}", item);
             }
             Console.WriteLine();*/
            /*   Console.WriteLine(arr[4]);
               int index= Array.IndexOf(arr, 24);

               if (index >= 0)
               {
                   Console.WriteLine("{0} -> {1}", index, arr[index]);
               }

               else {
               Console.WriteLine("{0}",index);
               }


               index = Array.LastIndexOf(arr, 24);

               if (index >= 0)
               {
                   Console.WriteLine("{0} -> {1}", index, arr[index]);
               }

               else
               {
                   Console.WriteLine("{0}", index);
               }
            */
            string str = "Hello";
           // char[] arrch = { 'h', 'e', 'l', 'l', 'o' };
           // string str = new string(arrch);
           //string str=new string (arrch,1,3);       
           // string str = new string('o',5);
            Console.WriteLine(str);
            Console.WriteLine(str.Length);

            int n1=3,n2=5;
            Console.WriteLine($"{n1} + {n2} = {n1+n2}");
            Console.WriteLine($"{(n1 > n2 ? "n1>n2" : "n1<n2")}");

 Console.WriteLine(string.IsNullOrEmpty(str));//F
            str = "";
            Console.WriteLine(string.IsNullOrEmpty(str));//T
            Console.WriteLine(string.IsNullOrWhiteSpace(str));//T
            str = " ";
            Console.WriteLine(string.IsNullOrWhiteSpace(str));//T



           

            string str2= "Split  Console.WriteLine(str  str =  teLine(string.IsNullOrWhiteSpace(str));//T);//TConsole.WriteLine(string.IsNullOrWhiteSpace(str));//T.";
            string[] arr32 = str2.Split(new char[] {' ','.'}, StringSplitOptions.RemoveEmptyEntries);
            foreach(string item in arr32){
                Console.WriteLine(item);
            }
            


    
            Console.WriteLine(string.Join("=",arr));






            Console.ReadKey();
       
        
        
        
        
        
        
        }
    }
}
