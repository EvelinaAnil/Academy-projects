﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Lesson_14_файловая_система_
{
    internal class Program
    {
//        private static void Write(string path)
//        {
//            using (FileStream stream = new FileStream(path, FileMode.Create,
//                       FileAccess.Write, FileShare.None)) //with catch 
//            {
//                Console.WriteLine("Input text:");
//                string text = Console.ReadLine();
//                byte[] bytes = Encoding.UTF8.GetBytes(text);
//                stream.Write(bytes, 0, bytes.Length);
//                //0 -> в массиве байт, ленгс ->размер массива
//                Console.WriteLine("Information OK!");
//            }
//        }

//        private static string Read(string path)
//        {
//            using (FileStream stream = new FileStream(path,FileMode.Open
//                /*,FileAccess.Read*/))
//            {
//                byte[] bytes = new byte[stream.Length];
//                stream.Read(bytes, 0, bytes.Length);
//                return Encoding.UTF8.GetString(bytes); //ASCII not working
//            }
//        }
//        private static void WriteTXt(string path)
//        {
//            using (FileStream stream = new FileStream(path, FileMode.Create)) 
//                //with catch 
//            {
//                using (StreamWriter sw = new StreamWriter(stream, Encoding.Unicode))
//                {
//                    Console.Write("Input text: ");
//                    string text = Console.ReadLine();
//                    sw.WriteLine(text); //hello

//                    foreach (char item in text)
//                    {
//                        sw.Write($"{item} "); // h e l l o
//                    }

//                    Console.WriteLine("Information OK!");
//                }
//            } 
//        }


//        private static string ReadTXT(string pathtX)
//        {
//            using (FileStream stream = new FileStream(pathtX, FileMode.Open))
//            {
//                using (StreamReader wr = new StreamReader(stream, Encoding.Unicode))
//                {
//                    return wr.ReadToEnd();
//                }
//            }
//        }
//        private static void WriteBin(string pathX)
//        {
//            using (FileStream stream = new FileStream(pathX, FileMode.Create))
//            {
//                using (BinaryWriter sw = new BinaryWriter(stream, Encoding.Unicode))
//                {
//                    Console.Write("Input text:");
//                    string text = Console.ReadLine();

//                    double slary = 4354553.464;
//                    int number = 12313;
//                    char symbol = 'T';

//                    sw.Write(slary);
//                    sw.Write(text);
//                    sw.Write(number);
//                    sw.Write(symbol);

//                    Console.WriteLine("Information OK!");
//                }
//            }
//        }

//        private static string ReadBin(string pathX)
//        {
//            using (FileStream stream = new FileStream(pathX, FileMode.Open))
//            {
//                using (BinaryReader Sr = new BinaryReader(stream, Encoding.Unicode))
//                {
//                    return $"{Sr.ReadDouble()}\n{Sr.ReadString()}\n{Sr.ReadInt32()}\n{Sr.ReadChar()}\n";
//                    StringBuilder builder = new StringBuilder();
//                    builder.AppendLine(Sr.ReadDouble().ToString());
//                }
//            }
//        }

//        private static void WriteTextFile(string peth)
//        {
//            FileInfo fi = new FileInfo(peth);
//            using (FileStream stream = fi.OpenWrite()) //with catch 
//            {
//                Console.WriteLine("Input text:");
//                string text = Console.ReadLine();
//                byte[] bytes = Encoding.UTF8.GetBytes(text);
//                stream.Write(bytes, 0, bytes.Length);
//                //0 -> в массиве байт, ленгс ->размер массива
//                Console.WriteLine("Information OK!");
//            }

//        }
//        private static string ReadTextFile(string peth)
//        {
//            using (FileStream stream = new FileInfo(peth).OpenRead())
//            {
//                byte[] bytes = new byte[stream.Length];
//                stream.Read(bytes, 0, bytes.Length);
//                return Encoding.UTF8.GetString(bytes); 
//            }

//        }
//        static void Main(string[] args)
//          {
//            // Thread        //это поток выполнения потокого кода
//            // Stream       //это поток передачи данных (use "Dispose" or "Close")

//            //OR -FileStream- Or do -using-
//            //  FileStream strem = new FileStream(...);
//            ///*1*/  try
//            //  {
//            //  }
//            //  catch (...){
//            //  }
//            //  finally 
//            //  {
//            //      strem.Close();
//            //  }
//            //  /*2*/
//            //  using (FileStream stream) //без catch
//            //  {
//            //  }
//            //  /*3*/ try { 
//            //      using (FileStream stream) //без catch
//            //          {
//            //          }
//            //  }
//            //  catch ()
//            //  {
//            //  }


//            string pathc = @"E:\ШАГ\C#\Lessons\Lesson_14(файловая система)\Lesson_14(do_1_file)";
//  string pathTxt = @"E:\ШАГ\C#\Lessons\Lesson_14(файловая система)\Lesson_14__(do_1_file).txt";
//string pathB= @"E:\ШАГ\C#\Lessons\Lesson_14(файловая система)\Lesson_14__(do_1_file).bin";
////                try
////            {
////                //Write(pathc);
////                //Console.WriteLine(Read(pathc));
////                //    WriteTXt(pathTxt);
////                //Console.WriteLine(ReadTXT(pathTxt));
////                //    WriteBin(pathB);
////                //    Console.WriteLine(ReadBin(pathB));

////                //File     статический
////                //    Directory
////                //FileInfo  не статический
////                //    DirextoryInfo
////catch (Exception ex)
////                {
////                Console.WriteLine(ex.Message);
////                }


//                string direct = @"E:\ШАГ\C#\Lessons\Lesson_14(файловая система)\Lesson_14(do_1_direct)";
//                if (!Directory.Exists(direct))
//                {
//                    Directory.CreateDirectory(direct);
//                }
//            foreach (string item in Directory.GetDirectories(@"E:\"))
//            {
//                Console.WriteLine(item);
//            }

//            DirectoryInfo dir = new DirectoryInfo(@"E:\ШАГ\C#\Lessons\
//Lesson_14(файловая система)\Lesson_14(do_1_1_dir)");
//            if (!dir.Exists)
//            {
//                dir.Create();
//            }
//            Console.WriteLine(dir.LastAccessTime);
//            DirectoryInfo dir1 = dir.CreateSubdirectory("Subdir");
//            DirectoryInfo directory = new DirectoryInfo(@"E:\ШАГ\C#\Lessons\
//Lesson_14(файловая система)\Lesson_14(do_1_1_dirinf)");
//            DirectoryInfo directory_1 = new DirectoryInfo(@"E:\ШАГ");
//            foreach (DirectoryInfo item in directory.GetDirectories())
//            {
//                Console.WriteLine(item.Name);
//            }
//            foreach (FileInfo item in directory_1.GetFiles("*.txt"))
//            {
//                Console.WriteLine(item.Name);
//            }

//            WriteTXt("Tec.txt");
//                Console.WriteLine(ReadTXT("Tec.txt"));
                                

//            using(StreamWriter wr =File.CreateText("Tec.txt"))
//                {
//                Console.Write("Input text: ");
//                string text = Console.ReadLine();
//                wr.WriteLine(text); //hello

//                foreach (char item in text)
//                {
//                    wr.Write($"{item} "); // h e l l o
//                }

//                Console.WriteLine("Information OK!");
//            }

//            using (StreamReader red =File.OpenText("Tec.txt"))
               
//                //Интерфейс ==меню

//            Console.ReadKey();
//        }
        [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true , AllowMultiple = true)]
        class CoderAttribute : Attribute
        {
            private string _name;
            private DateTime _date;
            public CoderAttribute()
            {
                _name = "wjoowe";
                _date = DateTime.Now;
            }
            public CoderAttribute(string name, string v)
            {
                try
                {
                _name = name;
                _date = Convert.ToDateTime(v);
                }
                catch 
                {

                    _date = DateTime.Now;
                }
                
            }
            public override string ToString()
            {
                return $"{_name}:{_date}";
            }

        }
        [Coder]
        [Coder]///AllowMultiple thx for
        class Example
        {
            [Coder("Jaenns","2021-1-11")]
            [Coder("Jaenns", "2021-11-26")]
            public int Summ(int x,int y)
            {
                return x + y;
            }
        }
        class  Class : Example
        {

        }
        public class Prog
        {
            [Obsolete]
            private static void M()
            {
                Console.WriteLine("M");
            }
            public static void Main()  //Main
            {
                M();
                Example ex = new Example();
                foreach (object item in typeof(Example).GetCustomAttributes(true))
                {
                    Console.WriteLine(item);
                }
                foreach (MemberInfo item in typeof(Example).GetMembers())
                {
                    foreach (object itrib in typeof(/*Example*/ Class).GetCustomAttributes(true))
                    {
                        Console.WriteLine(itrib);
                    }
                }

                Console.ReadKey();
            }
        }
    }
}

