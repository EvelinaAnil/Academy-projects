﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_5
{
    internal class Class1
    {
        internal void Method(Student st)
        {
            Student.GetAge();
            Console.WriteLine("fojowjefew");
        }
    }
}
