﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_5
{
    internal class Student
    {
        public const string Univer = "ITStep.com";

        public readonly string Country = "ukr";
        //либо в конструкторе либо здесь пишеться 

        public string lastName;
        private string _firstName = "Doei~";
        private static string _age/*= "1254252"*/;

        static Student()
        {

            _age = "97";
        }

        // public Student(string wd)
        // {
        //     wd = wd.Trim();
        // }
        public Student(string country)
        {
            Country = country;
           
        }

        public static void SetCity(string age)
        {
            //_firstName = "Doei~~~"; ERROR because of static
            _age = age;
        }

        public static string GetAge()
        {
            return _age;
        }
        internal string GetAge_1()
        {


            _firstName = "Doei~~~";
            return _age;

        }

        public void Method(Class1 clas)
        {if (clas == null)
            {
                return;
            }
            clas.Method(this);
        }

        //public Print()
        //{ 
        //    Console.WriteLine($"{_age} {_age}");

        //}
        public void Add(int x, int y) { }
        public double Add(double x, int y) { return 0; }

        public double Add(double x, double y) { return 0; }

        public double Add(int x, double y) { return 0; }


        public Student(Student st) //(string...,string contry) :this(contry)
        {
            _firstName = st._firstName;
            this.lastName = st.lastName;

        }
        internal class Program
        {
            static void Main(string[] args)
            {
                //Student rt = new Student();  //OR
                Student st = null;
                st = new Student("uukr");
                st.lastName = "lsaas";

                Console.WriteLine(st);

                /*  Student._age = "12";
                  Console.WriteLine(st.GetAge());
                  st.GetAge();
                  Student._age = "1";
                  Console.WriteLine(st.GetAge());*/

                Student.SetCity("12");
                Console.WriteLine(Student.GetAge());
                Student.GetAge();
                Student.SetCity("1");
                Console.WriteLine(Student.GetAge());

                // Student str = new Student();

                Class1 clas = new Class1();
                st.Method(clas);

                Console.ReadKey();
            }
        }
    }
}
