﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_13
{
    internal class Program
    {
        class Poiny<T>where T: struct
        {
            public T X { get; set; }
            public T Y { get; set; }

            public Poiny()
            {

            }

            public Poiny(T x, T y)
            {
                X = x;
                Y = y;
            }
        }
        class MyClass<D> where D:class ,new()
        {

        }
        static void Main(string[] args)
        {
            //1 JavaScript
            //2 Windows Sorce
            //3 ADO.net
            //4 Системное  програмирование (паралельное програмированние)
            //5 Сетевое програмирование
            //6 UML (язык моделиворания -относятся к различным специальностям


            //---Дженерики--

            List<int> list = new List<int>();
            list.Add(7651);
            list.Add(862);

            list[0] = 12;
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            int n = 32;
            object obj = n;//boxing

            int t = (int)obj;//unboxing


            Dictionary<string, int> dict = new Dictionary<string, int>();
            dict.Add("k", 1);
            dict.Add("k1", 2);
            dict.Add("k3", 3);
            if (!dict.ContainsKey("k"))
            {
                dict.Add("k", 2);
            }
            foreach (string key in dict.Keys)
            {
                Console.WriteLine(/*dict[key]*/ $"{key}: {dict[key]}");
            }
            foreach (int key in dict.Values)
            {
                Console.WriteLine(key);
            }

            Dictionary< int, List<string>> dict2 = new Dictionary<int, List<string>>();
            dict2.Add(34,new List<string>());
            dict2[34].Add("sd");




            Poiny<int> poiny = new Poiny<int>();
            Console.WriteLine(poiny.X);
            Console.WriteLine(poiny.Y);
            Poiny<double> poiny_1 = new Poiny<double>();
            Console.WriteLine(poiny_1.X);
            Console.WriteLine(poiny_1.Y);

            MyClass<Poiny<int>> Exception = new MyClass<Poiny<int>>();

            Console.ReadKey();
        }
    }
}
