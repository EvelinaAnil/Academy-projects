﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Array

            /* 
             //ссылочный тип
             string str = null;
             //значный тип
             int? number = 34;
             number = null;//? need!! then -> ERROR
             number = number ?? 34;
             Console.WriteLine(number);//55
             number = number ?? 55;
             Console.WriteLine(number);//34
             double? d = null;
             //lable types только с баззами данных нужно
            */

            /* //type_dann [] name_massive;
            //type_dann =new type_dann[number]; OR type_dann [] name_massive = new type_dann[number];
           int[] arrInt;
            arrInt = new int[4];
            arrInt[0] = 10;
            arrInt[1] = 20;
            arrInt[2] = 30;
            arrInt[3] = 40;
            arrInt[4] = 50;
            arrInt[5] = 60;*/

            /*  const int size = 6;
              int[] arrInt = new int[size];*/

            /* int row =int.Parse(Console.ReadLine());
               int[] arrInt = new int[row];*/

            //int[] arrInt = new int[4] {3,78,232,56878};

            /*   int n = 4;
           int[] arrInt = new int[n] { 3, 78, 232, 56878 };//ERROR */

            /* int[] arrInt = { 3, 78, 232, 56878 };

             for (int i = 0; i < arrInt.Length; i++)
             {
                 Console.WriteLine("{0} ", arrInt[i]) ;
             }
             Console.WriteLine();*/

            /* Random random =new Random();//!!!! need for rand

             int[] arrInt = new int[6];


             for (int i = 0; i < arrInt.Length; i++)
             {
                 //arrInt[i] = random.Next();
                 arrInt[i] = random.Next(-12,67);
             }
             foreach (int item in arrInt)
             {
                 Console.WriteLine("{0} ", item);
                 //item = 5656;//ERROR
                 //Only for read dannuu
             }
             Console.WriteLine();

             double[] arrDouble = new double[4];
             for (int i = 0; i < arrDouble.Length; i++)
             {
                 arrDouble.SetValue(random.NextDouble() + random.Next(3,12),i);
             }
             foreach (double item in arrDouble)
             {
                 Console.WriteLine("{0:F3} ", item);
                 //item = 5656;//ERROR
                 //Only for read dannuu
             }
             */

            //type_dann [,,....,] name_massive = new type_dann[size,size2,....,size4]
            /* int[,] arr = new int[3, 4] { 
                 { 12,14,15,16},
                { 0,154,565,86},
                { 54612,1244,7676,906},
             };
             Console.WriteLine("Length: {0}",arr.Length);
             for (int i = 0; i < arr.GetLength(0); i++)
             {
                 for (int j = 0; j < arr.GetLength(1); j++)
                 {
                     Console.Write("{0}\t", arr[i, j]);
                 }Console.WriteLine();
             }
           */
            /* int row=3,col=4;
             char[,] arrChar = new char[row, col];
             for (int i = 0; i < arrChar.GetLength(0); i++)*/


            //3 size трехмерный массив
            int[,,] arr = new int[3, 2, 4] {
                { { 212,124,135,516}, {32,40,75,16 } },
                { { 62,44,55,156}, {12,14,15,16 }},
               { { 2,4,99,66}, {2,4,5,46 } }
            };
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    for (int k = 0; k < arr.GetLength(2); k++)
                    {
                        Console.Write("{0}\t", arr[i,j,k]);
                    }Console.WriteLine();
                }Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
