﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_6
{
    class Class1
    {
        internal void Method(Student student)
        {
            student.Print();
        }
    }

    internal class Student
    {


        public const string University = "ITStep";

        public readonly string Country;// = "Ukraine";

        private string _lastName = "Doe";

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        public string LastName {
            get { /*находиться все что угодно(for,if..)*/return _lastName; }
            set { _lastName = value; }
        }
        /*------------*/
        private string _firstName;

        public int FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
            public DateTime BirthDate { get; set; }
        /*------------*/

        private string firstName;

        private static string _city = "Kyiv";

        static Student()
        {
            _city = "Odesa";
        }

        public Student()
        {
            _lastName = "Doe";
            firstName = "John";
        }

        public Student(string country)
        {
            Country = country;
        }

        public Student(string lastName, string firstName, string country) : this(country)
        {
            _lastName = lastName;
            this.firstName = firstName;
        }

        public Student(Student student)
        {
            _lastName = student._lastName;
            firstName = student.firstName;
        }

        public static void SetCity(string city)
        {
            //_lastName = "Moore"; error
            _city = city;
        }

        public static string GetCity()
        {
            return _city;
        }

        internal string GetCity1()
        {
            //Country = "Ukraine"; error

            _lastName = "Moore";
            return _city;
        }

        public void SetLastName(string lastName)
        {
            _lastName = lastName;
        }

        public string GetLastName()
        {
            return _lastName;
        }

        public void Method(Class1 class1)
        {
            if (class1 == null)
            {
                return;
            }
            class1.Method(this);
        }

        public void Print()
        {
            Console.WriteLine($"{_lastName} {firstName} {_city} {Country} {University}");
        }

        //private void Add(int x, int y) { }
        ////public int Add(int x, int y) { return 0; } error
        ////public void Add(int x, int y) {  } error
        //public double Add(double x, int y) { return 0; }
        //public double Add(double x, double y) { return 0; }
        //public double Add(double x, double y, double a) { return 0; }
        //public double Add(int x, double y) { return 0; }
    }

    class Program
    {
        private static readonly int[] _arrayInt; //= new int[0];
        static Program()
        {
            _arrayInt = new int[3] { 56, 92, 18 };
        }
        private static void Incerment_ref(ref int n) //ref-> в самом ,так и в вызове
        {
            ++n;
        }
        private static void IntIncermentout(out int n) //ref-> в самом ,так и в вызове
        {
            n = 78; //!!!!обязательно!
            n+=3;
        }
        private static void IntIncerment_in(in int n) //ref-> в самом ,так и в вызове
        {
            // n = 78; //ERROR
            //  n += 3;
            Console.WriteLine(n);
        }
        private static void ArrayIncerment_ref(ref double[] a)
            //изменять или присвоение новый адрес памяти 
        {
            ++a[0];

            a = new double[3] { 12.6, 67.83, 59.38 };
        }
        private static void ArrayIncerment_out(out double[] a)
        {
           // ++a[0];

            a = new double[3] { 12.6 , 67.83, 59.38 };
        }
        private static void ArrayIncerment_in(in double[] a)
        {
            ++a[0];

           // a = new double[3] { 12.6, 67.83, 59.38 };
        }

        private static int Summ(int[] arr)
        {
            int result=0;
            foreach (int i in arr)
            {
                result += i;
            }
            return result;  
        }
        private static int Summ_1(/*int n, ПАРАМС ПОСЛЕДНИЙ В () ! */params int[] arr)
        {
            int result = 0;
            foreach (int i in arr)
            {
                result += i;
            }
            return result;
        }
        static void Main(string[] args)
        {
            _arrayInt[0] = 254;
            foreach (int i in _arrayInt)
            {
                Console.Write($"{i}");
            }
            Console.WriteLine();

            int number = 37;
                 int number1 = 47;
                     int number2 = 40;
            // Program program =new Program();
            /*program.*/
            Incerment_ref(ref number);
            Console.WriteLine(number);

                //  IntIncermentout(out number1);

            IntIncermentout(out  number1);

            Console.WriteLine(number1);

            IntIncerment_in(in number2);
            Console.WriteLine(number2);

            double[] arr = new double[] { 3.4, 6.7, 8.5 };

            ArrayIncerment_ref(ref arr);

            foreach (double d in arr)
            {
                Console.Write($"{d}");
            }

            Console.WriteLine();

   ArrayIncerment_out(out arr);

            foreach (double d in arr)
            {
                Console.Write($"{d}");
            }

            Console.WriteLine();

            ArrayIncerment_in(in arr);


            Console.WriteLine(arr[0]);


            Console.WriteLine($"Summ: {Summ(_arrayInt)}");
            Console.WriteLine($"Summ_1: {Summ_1(45,23,11,78,96)}");
            /*  //Student student = null;
              // ...
              student = new Student("Ukraine");

              Student.SetCity("Kharkiv");

              Console.WriteLine(Student.GetCity());

              Student student1 = new Student("Stevenson", "Robert", "Poland");
              student1.Print();

              Console.WriteLine(Student.GetCity());

              Student.SetCity("Kyiv");

              Console.WriteLine();

              Console.WriteLine(Student.GetCity());

              Console.WriteLine(Student.GetCity());


              Console.WriteLine(Student.University);

              Console.WriteLine();

              Student student2 = new Student(student1);
              student2.Print();

              Console.WriteLine();

              student2.SetLastName("Moore");
              student2.Print();
              student1.Print();

              Console.WriteLine();

              Student student3 = student2;
              student3.SetLastName("Biden");
              student3.Print();
              student2.Print();

              Console.WriteLine();

              Class1 class1 = new Class1();
              student.Method(class1);*/


            Student st = new Student();
            st.LastName = "morre";//set
            Console.WriteLine(st.LastName);//get

            st.BirthDate = new DateTime(1990, 3, 6);


            Console.ReadKey();
        }
    }

}
