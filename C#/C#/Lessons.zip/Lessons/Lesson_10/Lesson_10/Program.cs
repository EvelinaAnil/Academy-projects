﻿
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApp
//{
//    class Point2D
//    {
//        public int X { get; set; }
//        public int Y { get; set; }

//        // унарные операторы: - ++ --

//        public static Point2D operator -(Point2D p)
//        {
//            return new Point2D { X = -p.X, Y = -p.Y };
//        }

//        public static Point2D operator ++(Point2D p)
//        {
//            p.X++;
//            p.Y++;
//            return p;
//        }

//        public static Point2D operator --(Point2D p)
//        {
//            p.X--;
//            p.Y--;
//            return p;
//        }

//        // операторы сравнения: != == > < >= <=
//        public override bool Equals(object obj)
//        {
//            return this.ToString() == obj.ToString();
//        }

//        public override int GetHashCode()
//        {
//            return this.ToString().GetHashCode();
//        }

//        public static bool operator ==(Point2D p1, Point2D p2)
//        {
//            if (p1 is null || p2 is null)
//            {
//                throw new NullReferenceException();
//            }
//            return p1.Equals(p2);
//        }

//        public static bool operator !=(Point2D p1, Point2D p2)
//        {
//            return !(p1 == p2);
//        }

//        public static bool operator >(Point2D p1, Point2D p2)
//        {
//            return (p1.X * p1.X + p1.Y * p1.Y) > (p2.X * p2.X + p2.Y * p2.Y);
//        }

//        public static bool operator <(Point2D p1, Point2D p2)
//        {
//            return (p1.X * p1.X + p1.Y * p1.Y) < (p2.X * p2.X + p2.Y * p2.Y);
//        }

//        public static bool operator >=(Point2D p1, Point2D p2)
//        {
//            return !(p1 < p2);
//        }

//        public static bool operator <=(Point2D p1, Point2D p2)
//        {
//            return !(p1 > p2);
//        }

//        // true, false
//        public static bool operator true(Point2D p)
//        {
//            return p.X != 0 || p.Y != 0;
//        }

//        public static bool operator false(Point2D p)
//        {
//            return p.X == 0 && p.Y == 0;
//        }

//        public override string ToString()
//        {
//            return $"X = {X} Y = {Y}";
//        }
//    }

//    class Vector
//    {
//        public int X { get; set; }
//        public int Y { get; set; }

//        public Vector() { }

//        public Vector(Point2D p1, Point2D p2)
//        {
//            X = p2.X - p1.X;
//            Y = p2.Y - p1.Y;
//        }

//        // бинарные операторы: + - * / (+= -= *= /= --> auto)

//        public static Vector operator +(Vector v1, Vector v2)
//        {
//            return new Vector { X = v1.X + v2.X, Y = v1.Y + v2.Y };
//        }

//        public static Vector operator -(Vector v1, Vector v2)
//        {
//            return new Vector { X = v1.X - v2.X, Y = v1.Y - v2.Y };
//        }

//        public static Vector operator *(Vector vector, int n)
//        {
//            vector.X *= n;
//            vector.Y *= n;
//            return vector;
//        }

//        public override string ToString()
//        {
//            return $"X = {X} Y = {Y}";
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            /*
//            Point2D point1 = new Point2D { X = 12, Y = -34 };

//            Point2D point2 = -point1; // -12 34
//            Console.WriteLine(point2);
//            Console.WriteLine(point2++); // -11 35
//            Console.WriteLine(++point2);

//            point2--;
//            Console.WriteLine(point2);
//            */

//            /*
//            Point2D point1 = new Point2D { X = -2, Y = 2 };
//            Point2D point2 = new Point2D { X = 3, Y = 5 };

//            Vector vector1 = new Vector(point1, point2);
//            Console.WriteLine(vector1);

//            Vector vector2 = new Vector { X = 4, Y = 6 };
//            Console.WriteLine(vector1 + vector2);
//            Console.WriteLine(vector1 - vector2);
//            Console.WriteLine(vector1 * 2);
//            //Console.WriteLine(5 * vector1); Error
//            */

//            /*
//            double n = 6.7;
//            object obj = n; // boxing
//            Console.WriteLine(obj);

//            double m = (double)obj; // unboxing
//            Console.WriteLine(m);

//            int n1 = 34, n2 = 34, n3 = 56;
//            Console.WriteLine(object.Equals(n1, n2)); // True
//            Console.WriteLine(object.Equals(n1, n3)); // False
//            Console.WriteLine(object.ReferenceEquals(n1, n2)); // False

//            Console.WriteLine();

//            Point2D point = new Point2D { X = 3, Y = 7 };
//            Point2D point1 = point;            
//            Console.WriteLine(object.ReferenceEquals(point, point1)); // True

//            Console.WriteLine();

//            string str1 = "Helli", str2 = "Helli", str3;
//            str3 = str2;
//            Console.WriteLine(object.Equals(str1, str2)); // True
//            Console.WriteLine(object.ReferenceEquals(str1, str2)); // True ??????
//            Console.WriteLine(object.ReferenceEquals(str2, str3)); // True
//            */

//            /*
//            try
//            {
//                Point2D point1 = new Point2D { X = -2, Y = 2 };
//                Point2D point2 = new Point2D { X = 3, Y = 5 };
//                Console.WriteLine(point1 == point2);
//                Console.WriteLine(point1 != point2);

//                Console.WriteLine(point1 > point2);
//                Console.WriteLine(point1 < point2);

//                Console.WriteLine(point1 >= point2);
//                Console.WriteLine(point1 <= point2);

//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//            */

//            Point2D point1 = new Point2D { X = -2, Y = 0 };

//            if (point1)
//            {
//                Console.WriteLine("True");
//            }
//            Point2D point2 = new Point2D { X = 0, Y = 0 };
//            if (point2)
//            {
//            }
//            else
//            {
//                Console.WriteLine("False");
//            }

//            Console.ReadKey();
//        }
//    }
//}


//using static System.Console;

//namespace ConsoleApp
//{
//    abstract class Figure
//    {
//        public abstract void Draw();
//    }

//    abstract class Quadrangle : Figure { }

//    class Rectangle : Quadrangle
//    {
//        public int Width { get; set; }
//        public int Height { get; set; }

//        public static implicit operator Rectangle(Square s)
//        {
//            return new Rectangle { Width = s.Length * 2, Height = s.Length };
//        }

//        public override void Draw()
//        {
//            for (int i = 0; i < Height; i++, WriteLine())
//            {
//                for (int j = 0; j < Width; j++)
//                {
//                    Write("*");
//                }
//            }
//            WriteLine();
//        }

//        public override string ToString()
//        {
//            return $"Rectangle: Width = {Width}, Height = {Height}";
//        }
//    }

//    class Square : Quadrangle
//    {
//        public int Length { get; set; }

//        public static explicit operator Square(Rectangle rect)
//        {
//            return new Square { Length = rect.Height };
//        }

//        public static explicit operator int(Square s)
//        {
//            return s.Length;
//        }

//        public static implicit operator Square(int number)
//        {
//            return new Square { Length = number };
//        }

//        public override void Draw()
//        {
//            for (int i = 0; i < Length; i++, WriteLine())
//            {
//                for (int j = 0; j < Length; j++)
//                {
//                    Write("*");
//                }
//            }
//            WriteLine();
//        }

//        public override string ToString()
//        {
//            return $"Square: Length = {Length}";
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Rectangle rectangle = new Rectangle { Width = 5, Height = 10 };
//            Square square = new Square { Length = 7 };

//            Rectangle rectSquare = square;
//            WriteLine($"Неявное преобразование квадрата ({square}) к прямоугольнику.\n{rectSquare}\n");
//            //rectSquare.Draw();

//            Square squareRect = (Square)rectangle;
//            WriteLine($"Явное преобразование прямоугольника ({rectangle}) к квадрату.\n{squareRect}\n");
//            //squareRect.Draw();

//            WriteLine("Введите целое число.");
//            int number = int.Parse(ReadLine());
//            Square squareInt = number;
//            WriteLine($"Неявное преобразование целого ({number}) к квадрату.\n{squareInt}\n");
//            //squareInt.Draw();

//            number = (int)square;
//            WriteLine($"Явное преобразование квадрата ({square}) к целому.\n{number}");
//        }
//    }
//}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Console;
using static System.Math;
using static Lesson_10.StaticClass;

namespace Lesson_10
{
    //    class Student
    //    {
    //        public string LastName { get; set; }
    //        public string FirstName { get; set; }

    //        public override string ToString()
    //        {
    //            return $"{FirstName} {LastName}";
    //        }

    //    }

    //    public class MyClass
    //    {

    //    }
    //    class Group
    //    {
    //        private Student[] _students;
    //        public Group()
    //        {
    //            _students = new Student[]
    //            {
    //                new Student {LastName="Robert", FirstName="Young"},
    //                new Student {LastName="Borisov",FirstName="Kycher"},
    //                new Student {LastName="Milka",  FirstName="Chocolade"}
    //            };
    //        }

    //        public Student this[int index]
    //        {
    //            get { return _students[index]; }
    //            set { _students[index] = value; }
    //        }


    //    }

    //    internal class Program
    //    {
    //        static void Main(string[] args)
    //        {
    //            Group group = new Group();
    //            Console.WriteLine(group[0]);

    //            MyClass myClass = new MyClass();
    //            //shop[myClass]


    //            Console.ReadKey();
    //        }
    //    }

    //public class Laptop
    //{
    //    public string Vendor { get; set; }
    //    public double Price { get; set; }

    //    public override string ToString()
    //    {
    //        return $"{Vendor} {Price}";
    //    }
    //}

    //enum Vendors { Samsung, Asus, LG };

    //public class MyClass
    //{
    //    public int Number { get; set; }
    //}

    //public class Shop
    //{
    //    private Laptop[] _laptopArr;

    //    public Shop(int size)
    //    {
    //        _laptopArr = new Laptop[size];
    //    }
    //    public int Length
    //    {
    //        get { return _laptopArr.Length; }
    //    }

    //    public Laptop this[MyClass index]
    //    {
    //        get
    //        {
    //            if (index.Number >= 0 && index.Number < _laptopArr.Length)
    //            {
    //                return _laptopArr[index.Number];
    //            }
    //            throw new IndexOutOfRangeException();
    //        }
    //        private set {
    //            if (index.Number >= 0 && index.Number < _laptopArr.Length)
    //            {
    //                _laptopArr... ;
    //            }
    //            /* set the specified index to value here */
    //        }
    //    }

    //    public Laptop this[int index]
    //    {
    //        get
    //        {
    //            if (index >= 0 && index < _laptopArr.Length)
    //            {
    //                return _laptopArr[index];
    //            }
    //            throw new IndexOutOfRangeException();
    //        }
    //        set
    //        {
    //            if (index >= 0 && index < _laptopArr.Length)
    //            {
    //                _laptopArr[index] = value;
    //            }
    //        }
    //    }

    //    public Laptop this[string name]
    //    {
    //        get
    //        {
    //            if (Enum.IsDefined(typeof(Vendors), name))
    //            {
    //                return _laptopArr[(int)Enum.Parse(typeof(Vendors), name)];
    //            }
    //            else
    //            {
    //                return new Laptop();
    //            }
    //        }
    //        set
    //        {
    //            if (Enum.IsDefined(typeof(Vendors), name))
    //            {
    //                _laptopArr[(int)Enum.Parse(typeof(Vendors), name)] = value;
    //            }
    //        }
    //    }

    //    private int FindByPrice(double price)
    //    {
    //        for (int i = 0; i < _laptopArr.Length; i++)
    //        {
    //            if (_laptopArr[i].Price == price)
    //            {
    //                return i;
    //            }
    //        }
    //        return -1;
    //    }

    //    public Laptop this[double price]
    //    {
    //        get
    //        {
    //            int index = FindByPrice(price);
    //            if (index >= 0)
    //            {
    //                return this[index];
    //            }
    //            throw new Exception("Недопустимая стоимость.");
    //        }
    //        set
    //        {
    //            int index = FindByPrice(price);
    //            if (index >= 0)
    //            {
    //                this[index] = value;
    //            }
    //        }
    //    }
    //}

    //public class Program
    //{
    //    public static void Main()
    //    {
    //        Shop shop = new Shop(3);
    //        shop[0] = new Laptop { Vendor = "Samsung", Price = 5200 };
    //        shop[1] = new Laptop { Vendor = "Asus", Price = 4700 };
    //        shop[2] = new Laptop { Vendor = "LG", Price = 4300 };



    //       MyClass myClass = new MyClass { Number = 1 };
    //        Console.WriteLine(shop[myClass]);
    //        Console.WriteLine();
    //        try
    //        {
    //            for (int i = 0; i < shop.Length; i++)
    //            {
    //                Console.WriteLine(shop[i]);
    //            }
    //            Console.WriteLine();

    //            Console.WriteLine($"Производитель Asus: {shop["Asus"]}.");

    //            Console.WriteLine($"Производитель HP: {shop["HP"]}.");

    //            shop["HP"] = new Laptop(); // игнорирование

    //            Console.WriteLine($"Стоимость 4300: {shop[4300.0]}.");

    //            // недопустимая стоимость
    //            Console.WriteLine($"Стоимость 10500: {shop[10500.0]}.");

    //            shop[10500.0] = new Laptop(); // игнорирование
    //        }
    //        catch (Exception ex)
    //        {
    //            Console.WriteLine(ex.Message);
    //        }
    //    }
    //}




  static  class StaticClass
    {
       //ERROR protected static int number;
        public static double Price { get; set; }
        static StaticClass()
        {

        }
    }
    class MyClass
    {
    }

    interface IIn
    {

    }
    interface IIn12
    {

    }
    class MyClass1
    {
    }
    class MyClass2 : MyClass1, IIn, IIn12 
    {
    }
    //class MyClass :StaticClass 
    //{  } ERROR

    interface IFly
    {
        void Fly();
    }

    interface ISwim
    {
        void Swim();
    }
    interface IRun
    {
        void Run();
    }
    abstract class Insect
    {
        protected string name;
    }
    class Butterfly : Insect, IFly
    {
        public Butterfly()
        {
            name = "Butterfly";
        }
        public void Fly()
        {
            Console.WriteLine(name);
        }
    }
    class Plane : IFly
    {
        
        public void Fly()
        {
            throw new NotImplementedException();
        }
    }
    abstract class Bird
    {
        protected string name;

        
        public int IsEggs { get; set; }

        public abstract void Fly();
    }

    class Duck : Bird , IFly   , ISwim
    {
        public Duck()
        {
            name = "Duck";
        }

        public override void Fly()
        {
            throw new NotImplementedException();
        }
        //public override void Fly()
        //{
        //    Console.WriteLine(name);
        //}
        public void Swim() { }
    }

    class Penguin : Bird , ISwim
    {
        public Penguin()
        {
            name = "Penguin";
        }
        public override void Fly()
        {
            throw new NotImplementedException();
        }

        public void Swim()
        {
           
        }
    }

    class Ostrich : Bird , IRun
    {
        public Ostrich()
        {
            name = "Ostrich";
        }
        public override void Fly()
        {
            throw new NotImplementedException();
        }

        public void Run()
        {
           //
        }
    }
    public class Program
    {
        static void Main(/*string[] args*/)
        {
            /* StaticClass staticClass = new StaticClass();
             staticClass.Equals( staticClass );*/

            /*StaticClass.*/Price = 4567;

          WriteLine( Price );
            
            WriteLine(PI);


            //ИНТЕРФЕЙС -- сравнивает с неким обьязательством в случаи реализации данного
            //интерфейса

            ISwim swim =new Penguin();

            IFly[] flies = { new Duck() , new Butterfly(),new Plane()};
            foreach (IFly item in flies)
            {
                item.Fly();
            }
            Bird[] bird = { new Duck(), new Ostrich(), new Penguin() };
            foreach (Bird item in bird) { 
                if(item is IFly fly)
            {
                fly.Fly();  
            }}
            ReadKey();
        }
    }

}


