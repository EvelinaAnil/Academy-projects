﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Lesson_11
{
    
    interface IA
    {
        void Show();
    }

    interface IB
    {
        void Show();
    }
    interface IC
    {
        void Show();
    }
    class EXapleClass : IA, IB, IC
    {
        public void Show() //if  not IC =IC ? yes that = only SHOW
        {
           Console.WriteLine("Show");
        }
        void IA.Show()
        {
            Console.WriteLine("Show IA");
        }

        void IB.Show()
        {
            Console.WriteLine("Show IB");
        }

        //void IC.Show() //IC 
        //{
        //    Console.WriteLine("Show IC");
        //}
    }
    /*================================= 2*/

    internal class MyEnumerator : IEnumerator
    {
        public object Current { get; }

        public bool MoveNext()
        {
            throw new NotImplementedException();
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }
    }
    class ArrayClass : IEnumerable
    {
        public IEnumerator GetEnumerator()
        {
            IEnumerator en = new MyEnumerator();
            return en;
        }
        }
        public class Passport
    {
        public int Number { get; set; }
        public string Series { get; set; }
        public override string ToString()
        {
            return $"{Series}{Number}";
        }
    }
    class Person : IComparable , ICloneable
    {
        public string Name{ get;set; }
        public int Age { get; set; }
        public Passport Passport { get; set; }

        int IComparable.CompareTo(object obj)
        {
            if(obj is Person person)
            {
                return Age.CompareTo(person.Age);

            }
            throw new ArgumentException();
        }

        public override string ToString()
        {
            return $"{Name } {Age} {Passport}";
        }

        public object Clone()
        {
            return this.MemberwiseClone() ;
        }
    }

    class Room: IEnumerable
    {
        private Person[] _people;

        public Room() 
        {
            _people = new Person[]
            {
                new Person{Name="Boom Boom",Age=56, Passport = new Passport{Number=125612,Series="KB"} },
              new Person{Name="Bim Boom",Age=25, Passport = new Passport{Number=125712,Series="HA"} },
              new Person{Name="Booss",Age=40, Passport = new Passport{Number=122892,Series="QP"} },
              new Person{Name="Keuken",Age=50, Passport = new Passport{Number=122109,Series="WL"} }

            };
        }

        public IEnumerator GetEnumerator()
        {
            return _people.GetEnumerator();
        }
         IEnumerator IEnumerable.GetEnumerator()
        {
            return _people.GetEnumerator();
        }
        //IEnumerable

        public void Sort()
        {
            Array.Sort(_people);
        }
        public void Sort(IComparer comparer)
        {
            Array.Sort(_people, comparer);
        }
    }
    public   class Program
    {
        static void Main(string[] args)
        {
            EXapleClass ex = new EXapleClass();
            ex.Show();  //Show

            (ex as IA).Show();//Show IA
            (ex as IB).Show();//Show IB

            IB  ib = new EXapleClass();
            ib.Show();//Show IB
            Console.WriteLine();
            /*================================= 2*/
            Room room=new Room();
            room.GetEnumerator();
            room.Sort();
           
            foreach (var item in room)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            IComparer comp = new NameComp();
            room.Sort(comp);

            room.Sort(new NameComp());//тоже самое ,но сразу


            foreach (var item in room)
            {
                Console.WriteLine(item);
            }

            Person p1 = new Person
            {
                Name = "Bim Boom",
                Age = 25,
                Passport = new Passport { Number = 125712, Series = "HA" }
            };
            Person p2 = p1.Clone() as Person;

            Console.WriteLine(p1);
            Console.WriteLine(p2);

            p2.Name = "AAAAA";
            p2.Age = 00;
            p2.Passport.Number = 111111;
            p2.Passport.Series = "AA";

            Console.WriteLine(p1);
            Console.WriteLine(p2);

            Console.ReadKey();
        }
    }
    internal class NameComp : IComparer
    {
         int IComparer.Compare(object x, object y)
        {
           if(x is Person p1 && y is Person p2)
            {
                return string.Compare(p1.Name,p2.Name);
            }
            throw new ArgumentException();
        }

        
    }
}
