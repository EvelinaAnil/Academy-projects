﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace Lesson_1_
{ 
     class Program
    {
        enum Cars { ford=1,Nissan=2,Tayot=3 };
      
        static void Main(string[] args)
        {
 

            Console.WriteLine("Hoi");
            


            int num;

            int number;
            //Console.Read();
            //Console.WriteLine(int.MaxValue);
            // Console.ReadKey();  
            //ConsoleInfo consoleKey = Console.ReadKey();
          
          //  number = int.Parse(Console.ReadLine());
            //number=Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine(number);
            double d =double.Parse(Console.ReadLine());
            Console.WriteLine(d);
            //===============-=-=-=-===--
            //3/8=0
            //3/8.0=0.0
            //Console.WriteLine(  3/8.0 );
            //Console.WriteLine(3 %5);
            //// 1%2=1-2*(1/2)
            //Console.WriteLine(33 % 5.2);//1.8
            //Console.WriteLine(33 - 5.2*(33/ 5.2));
            //Console.WriteLine(5.3 / 0);// infinity
            //double n = 5.3 / 0;
            //n += 4;
            //Console.WriteLine(double.IsInfinity(n));//infinity


            //int n1 = 45, n2 = 57, n3 = 33;

            //Console.WriteLine(n1 > n3 && n2 < n1);//F

            //Console.WriteLine(n1 < n3 && n2 > n1);//F

            //Console.WriteLine(n1 < n3 & n2 > n1);//F  
            ////--------------------------------------
            ////& -> проверяеться и до & и после & 
            ////&&->только перед
            ////| -> проверяеться и до | и после | 
            ////||->только перед
            ////--------------------------------------
            //Console.WriteLine(n1 < n3 || n2 > n1);//T

            //Console.WriteLine(n1 < n3 | n2 > n1);//T

            //          // if (number == 12) { 
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(659, 300);
            //            Console.Beep(783, 300);
            //            Console.Beep(523, 300);
            //            Console.Beep(587, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(261, 300);
            //            Console.Beep(293, 300);
            //            Console.Beep(329, 300);
            //            Console.Beep(698, 300);
            //            Console.Beep(698, 300);
            //            Console.Beep(698, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(698, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(659, 300);
            //            Console.Beep(587, 300);
            //            Console.Beep(587, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(587, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(783, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(659, 300);
            //            Console.Beep(783, 300);
            //            Console.Beep(523, 300);
            //            Console.Beep(587, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(261, 300);
            //            Console.Beep(293, 300);
            //            Console.Beep(329, 300);
            //            Console.Beep(698, 300);
            //            Console.Beep(698, 300);
            //            Console.Beep(698, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(698, 300);
            //            Console.Beep(659, 300);
            //            Console.Beep(659, 300);
            //            Thread.Sleep(300);
            //            Console.Beep(783, 300);
            //            Console.Beep(783, 300);
            //            Console.Beep(698, 300);
            //            Console.Beep(587, 300);
            //            Console.Beep(523, 600);
            //            Thread.Sleep(600);
            //        }
            //          // else {
            //
            //            }

            //int n = 1;
            //if (n+112>0)
            //{

            //}
            //else if (n>0)
            //{


            //}
            //else
            //{

            //}

            
            int y = 5;
            
            string str = "fg";

            switch (y)
            {
            case 1:
                    Console.WriteLine("1y"); 
                    break;
            case 4:
                    Console.WriteLine("4y");

                    break;

                default:
            break;
            }
            //char ch = '2';
            //switch (ch)
            //{
            //    case 2:
            //        Console.WriteLine("1c");
            //        break;
            //    case 3:
            //        Console.WriteLine("4c");

            //        break;

            //    default:
            //        break;
            //}
            //switch (str)
            //{
            //    case 8:
            //        Console.WriteLine("1s");
            //        break;
            //    case 9:
            //        Console.WriteLine("4s");

            //        break;

            //    default:
            //        break;
            //}
            //Cars car = Cars.ford;
            //switch (car)
            //{
            //    case Cars.ford:
            //        break;
            //    case Cars.Nissan:
            //        break;
            //    case Cars.Tayot:
            //        break;
            //    default:
            //        break;
            //}

            // ? :
            int n = 34;
            Console.WriteLine(n% 2==0?"Even":"Odd");

            if (n == 0)
            {
             
            }


Console.ReadKey();
        }
    }
}
