﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Linq;

//namespace Lesson_16__
//{
//    delegate void ExameDelegate(string t); 
//    class Student
//    {
//        public string FirstName { get; set; }
//        public string LastName { get; set; }
//        public DateTime BirthDate { get; set; }

//        public override string ToString()
//        {
//            return $"{FirstName} {LastName} {BirthDate.ToLongDateString()}";
//        }
//        public void ExamStudent(string task)
//        {
//            Console.WriteLine($"Student {LastName} made {task}");
//        }
//    }
//    class Teacher
//    {
//        //событие!
//       public /*event*/ EventHandler<ExameDelegate> exame;
//        public void ExamTeacher(string task)
//        {
//            //if (exame != null)
//            //{
//            //    exame.Invoke(task);
//            //}
//            // exame?.Invoke(task); //Invoke->в каждом  delegate  есть это
//        }
//    }
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Student> group = new List<Student> {
//                new Student {
//                    FirstName = "John",
//                    LastName = "Miller",
//                    BirthDate = new DateTime(2003,3,12)
//                },
//                new Student {
//                    FirstName = "Candice",
//                    LastName = "Leman",
//                    BirthDate = new DateTime(2004,7,22)
//                },
//                new Student {
//                    FirstName = "Joey",
//                    LastName = "Finch",
//                    BirthDate = new DateTime(2002,11,30)
//                },
//                new Student {
//                    FirstName = "Nicole",
//                    LastName = "Taylor",
//                    BirthDate = new DateTime(2002,5,10)
//                }
//            };
//            //------------------------------------0---------------

//            // Action ---тип возврата void (.....in T16)
//            // Action<Student> act = new Action(FullName);   //OR
//            // Action<Student> act = FullName;
//            ////  group.ForEach(FullName); //каждому ел. списка прмен
//            // group.ForEach(act);

//            //Func ---параметры могут отсутствувать,но ОБЯЗАТЕЛЬНО 
//            //    что-то возварщать(.....in T16)
//            Func<Student, string/*string-> тип возврата*/> fc =
//                new Func<Student, string>(FLName);
//           // group.Select(fc);
//           IEnumerable<string> list = group.Select(FLName);
//            //group.Select(FLName);
//            foreach (string item in list)
//            {
//                Console.WriteLine(item);
//            }


//            //Predicate --принимает параметр ,но возвращает bool
//           List<Student> lst = group.FindAll(OnlySpring);
//            foreach (Student item in lst)
//            {
//                Console.WriteLine(item);
//            }

//            group.Sort(SortBirthDate); 
//            foreach (Student item in lst)
//            {
//                Console.WriteLine(item);
//            }

//            /*=====================================================*/
//            Console.WriteLine(" /*===========================1==========================*/");
//            //СОБЫТИЕ 
//            Teacher teacher= new Teacher();
//            foreach (Student item in group)
//            { //!!!!     +=
//                teacher.exame += item.ExamStudent;
//                teacher.exame -= item.ExamStudent;
//            }
//           // teacher.exame.Invoke("##!#!!$%^^&&*&");
//           // teacher.exame = null; ERROR
//            teacher.ExamTeacher("Task #1");


//            Console.ReadKey();
//        }
//        /*=====================================================*/
//        private static int SortBirthDate(Student x, Student y)
//        {
//           return x.BirthDate.CompareTo(y.BirthDate);
//        }

//        private static bool OnlySpring(Student obj)
//        {
//            return obj.BirthDate.Month > 2 && obj.BirthDate.Month < 6;
//        }

//        private static string FLName(Student arg)
//        {
//            return $"{arg.FirstName} {arg.LastName}";
//        }

//        private static void FullName(Student obj)
//        {
//            Console.WriteLine($"{obj.FirstName} {obj.LastName}");
//        }
//        /*=====================================================*/
//    }
//}






using System;
using System.Collections.Generic;
using static System.Console;

namespace ConsoleApp
{
    class ExamEventArgs : EventArgs
    {
        public string Task { get; set; }
    }

    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }

        public void ExamStudent(object sender, ExamEventArgs e)
        {
            Console.WriteLine($"Студент {LastName} решил {e.Task}");
        }
    }

    class Teacher
    {
        public EventHandler<ExamEventArgs> examEvent;

        public void ExamTeacher(ExamEventArgs task)
        {
            if (examEvent != null)
            {
                examEvent(this, task);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Student> group = new List<Student> {
                new Student {
                    FirstName = "John",
                    LastName = "Miller",
                    BirthDate = new DateTime(2003,3,12)
                },
                new Student {
                    FirstName = "Candice",
                    LastName = "Leman",
                    BirthDate = new DateTime(2004,7,22)
                },
                new Student {
                    FirstName = "Joey",
                    LastName = "Finch",
                    BirthDate = new DateTime(2002,11,30)
                },
                new Student {
                    FirstName = "Nicole",
                    LastName = "Taylor",
                    BirthDate = new DateTime(2002,5,10)
                }
            };

            Teacher teacher = new Teacher();

            foreach (Student item in group)
            {
                teacher.examEvent += item.ExamStudent;
            }

            ExamEventArgs eventArgs = new ExamEventArgs { Task = "Задача" };

            teacher.ExamTeacher(eventArgs);
        }
    }
}

