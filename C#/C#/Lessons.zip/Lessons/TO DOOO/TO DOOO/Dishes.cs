﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TO_DOOO
{
     class Dishes
    {
        public string Name_dish { get; set; }
        public int price { get; set; }

        //enum Time
        //{
        //    Morning,
        //        Day,
        //        Evening
        //}

        public Dishes(string name, int _price)
        {
            Name_dish = name;
            price = _price;

        }
        public void Show()
        {
            Console.WriteLine($"---------DISH--------- \nName:{Name_dish}" + $" \nPrice:{price}" /*+ $" \nType:{Type_dish} "*/);
        }
    }
}
