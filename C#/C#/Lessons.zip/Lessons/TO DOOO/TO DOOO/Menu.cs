﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TO_DOOO
{
     class Menu
    {
        enum DataTime
        {
            Morgen,
            Day,
            Evening
        }

    }
}
