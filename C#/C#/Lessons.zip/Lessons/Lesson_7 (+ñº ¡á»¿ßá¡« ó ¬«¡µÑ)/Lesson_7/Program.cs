﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temat_08
{

   abstract class Shape
    {
        private int _x;
        public double S { get;  set; }

        public Shape()
        {

        }

        public abstract void M();
    }

    abstract class Human
    {
        private int _id;
        protected string lastName;
        public virtual void Print()
        {
            Console.WriteLine($"{lastName}"); //num не видит тут
              // object.ReferenceEquals(lastName, lastName); //сравнение ссылок
        }

        public Human(string name)
        {
            lastName = name;
        }

        public abstract void Think();

        public override string ToString()
        {
            
            return lastName;
        }
    }
  abstract  class UnEmployee : Human // без модификаторов доступа
    {
        public UnEmployee(string name) : base(name)
        {

        }
        }

      abstract   class  Employee : Human // без модификаторов доступа
    {
        public int num; // это не передастся туда
        private double _salary;

        public Employee(string name, double salary)
            : base(name)
        {
            //_id не видит
            //lastName = name; - больше не нужно, есть : base(name)

            _salary = salary;
            Print(); //видно
        }

        public void Show()
        {
            //PrintH();
            base.Print();
            Console.WriteLine($"{_salary}");
        }

        public override void Print()
        {
            Console.WriteLine($"{lastName} {_salary}");
        }
        public override string ToString()
        {
            //return base.ToString();
            return $"{base.ToString()} {_salary}";
        }
    }

   sealed  class Teacher : Employee
    {
        private string _logbook;
        public Teacher(string name,double salary) :base(name,salary)
            {

        }
        public override void Print()
        {
            base.Print();
            Console.WriteLine($"{_logbook}");
        }

        public override void Think()
        {
            Console.WriteLine("Theacher think");
        }
        public override string ToString()
        {
            //return base.ToString();
            return $"{base.ToString()} {_logbook}";
        }
    }

    class Manager : Employee
    {
        public Manager(string name, double salary) : base(name, salary)
        {
        }

        public void Lead() {
       
    }
        public override void Think()
        {
            Console.WriteLine("Manager think");
        }
       
    }


    internal class Program
    {
        static void Main(string[] args)
        {/*
            // Human human = new Human("Noore");

            Employee employee = new Employee("Moore", 2567.82);
            employee.Show();
            employee.Print();

            Human human_1 = new Employee("Devis", 1582.74);
            //human_1.Print();

            Human[] people = { new Employee("Moore", 2567.82), new UnEmployee("Doe") };

          /*  foreach (Human item in people)
            {
                try
                {

                
                //1
                ((Employee)item).Show();
                }
                catch  { }

                //2
                Employee empl = item as Employee;
                if (empl != null)
                {
                    empl.Show();
                }

                //3
                if (item is Employee)
                {
                    (item as Employee).Show();
                }

                //4
                if(item is Employee employee1)
                {
                    employee1.Show();
                }
            }
            */
/*
            Human human2 = new Employee("Devis", 1582.74);
            human2.Print();

            Human[] people_1 = { new Employee("Moore", 2567.82), new UnEmployee("Doe"), new Teacher("Tailor", 12134.44) };

            foreach (Human item in people_1)
            {
                item.Print();
                Console.WriteLine();
            }

            // Human h = new Human(); ERROR
            */
            Human h = new Teacher("Tailor",2178.41);

            Human[] empll = { h,new Manager("Allien",2123.45)};
            //Employee[] emplll = { };

            foreach (Human item in empll)
            {
                item.Think();//полиморфизм
            }
            
            
            Human emplll = new Teacher("Tailor", 2178.41);
            Console.WriteLine(emplll);


            Console.ReadKey();
        }
    }
}
//ЗАДАНИЕ 1 7_домашка  "Сост фигур"-: контейнер



