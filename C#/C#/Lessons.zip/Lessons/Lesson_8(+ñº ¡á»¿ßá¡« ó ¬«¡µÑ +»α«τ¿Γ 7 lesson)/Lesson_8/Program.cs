﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Security.Cryptography;
using System.Security;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Data.Common;
using System.Runtime.Remoting.Messaging;

namespace Lesson_8
{
   
  
  
    ///*1*/     class MyException : ApplicationException//обязательно если создаешь свой exept
    // {
    //    private string _message;
    //    public DateTime TimeExeption { get; }

    //    public MyException()
    //    {
    //        _message = "MyException";
    //        TimeExeption = DateTime.Now;
    //    }
    //        public override string Message
    //        {
    //            get { return _message; }
    //        }
    //    }

    /*2*/
    //class MyException : ApplicationException//обязательно если создаешь свой exept
    //{
        
    //    public DateTime TimeExeption { get; }

    //    public MyException() : base("MyException")
    //    {
    //        TimeExeption =DateTime.Now;
    //    }
      
    //}

/*3*/
    [Serializable]
    public class MyException : Exception
    {
        public DateTime TimeException { get; }
        public MyException() : this("MyException") { }
        public MyException(string message) : base(message) { 
        TimeException= DateTime.Now;
                }
        public MyException(string message, Exception inner) : base(message, inner) { }
        protected MyException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }

    //class MyException : ApplicationException
    //{
    //    private string _message;
    //    public DateTime TimeException { get; }
    //    public MyException()
    //    {
    //        _message = "MyException";
    //        TimeException = DateTime.Now;
    //    }
    //    public override string Message
    //    {
    //        get { return _message; }
    //    }
    //}

    //private static int Divide(int n)
    //{
    //    try
    //    {

    //    }
    //    catch 
    //    {

    //        throw;
    //    }
    //}

    /*4*/
    /* public class A//in ..class Program {..
     {
         private int num;

         public A(int num)
         {
             this.num = num;
         }
         public void MethodA()
         {
             Console.WriteLine("Entering MethodA");
             try
             {
                 this.MethodB();
                 Console.WriteLine("Class A");
             }
             catch (Exception e)
             {
                 throw new Exception(e.Message);
                 // throw; передача исходного объекта исключения
                 Console.WriteLine("Exception MethodA");
             }
             Console.WriteLine("Leaving MethodA");
         }
         public void MethodB()
         {
             Console.WriteLine("Entering MethodB");
             if (this.num > 10 || this.num < 0)
                 throw new System.Exception("Exception in MethodB - out of range");
             Console.WriteLine("Leaving MethodB");
         }
     }
     public class Tester
     {
         public static void Main()
         {
             Console.WriteLine("Entering Main");
             A a = new A(15);
             try
             {
                 a.MethodA();
                 Console.WriteLine("Main");
             }
             catch (Exception e)
             {
                 Console.WriteLine("Exception Main");

                 // причина возникновения исключения
                 Console.WriteLine(e.Message);
                 // имена, сигнатуры и нахождение методов, вызов которых привел к возникновению исключения
                 Console.WriteLine(e.StackTrace);
                 // метод, сгенерировавший исключение
                 Console.WriteLine(e.TargetSite);
             }
             Console.WriteLine("Leaving Main");
         }
     }
    //}
    */

    class Program
    {
        private static int Divide(int n)
        {
            try
            {
                return 100 / n;
            }
            catch 
            {

                throw;
            }
        }
        static void Main(string[] args)
        {
            /*
             Разговор++
            ? Сборщик мусора
            язык англ. есть,но не самое главное 
             
             */
            /*       Exception //базовый класс для всех
           /*1*/ // ApplicationException 


            /*  CodeDomSerializerException
              InvalidPrinterException
              IOException //работа с файловой системой
              IsolatedStorageException
              PathTooLongException
              CookieException
              ProtocolViolationException
              WebException
              MissingManifestResourceException
              SUDSGeneratorException
              SUDSParserException
              SystemException
              UriFormatException
              SoapException */

            /*2*/
            /*  SystemException //базовый класс для всех проблем с 
                        //базой данных
              AppDomainUnloadedException
                 ArgumentException
                 ArithmeticException
                 ArrayTypeMismatchException
                 BadImageFormatException
                 CannotUnloadAppDomainException
                 LicenseException
                 WarningException
                 ConfigurationException
                 InstallException
                 ContextMarshalException
                 DataException
                 DBConcurrencyException
                 SqlException
                 SqlTypeException
                 RegistrationException
                 ServicedComponentException
                 ExecutionEngineException
                 FormatException
                 IndexOutOfRangeException
                 InvalidCastException
                 InvalidOperationException
                 InvalidProgramException
                 InternalBufferOverflowException
                 ManagementException
                 MemberAccessException
                 MulticastNotSupportedException
                 NotImplementedException
                 NotSupportedException
                 NullReferenceException // =null
                                        //,если не правильно
                 OutOfMemoryException
                 RankException
                 AmbiguousMatchException
                 ReflectionTypeLoadException
                 ExternalException
                 InvalidComObjectException
                 InvalidOleVariantTypeException
                 MarshalDirectiveException
                 SafeArrayRankMismatchException
                 SafeArrayTypeMismatchException
                 RemotingException
                 ServerException
                 SerializationException
                 CryptographicException
                 PolicyException
                 SecurityException
                 VerificationException
                 XmlSyntaxException
                 TimeoutException
                 StackOverflowException
                 SynchronizationLockException
                 ThreadAbortException
                 ThreadInterruptedException
                 ThreadStateException
                 TypeInitializationException
                 TypeLoadException
                 TypeUnloadedException
                 UnauthorizedAccessException
                 XmlSchemaException
                 XmlException
                 XsltException
                        */
            //            try
            //            {
            //Console.WriteLine("Enter two numbers:");
            //            int n1 = int .Parse(Console.ReadLine());
            //            int n2 = int .Parse(Console.ReadLine());

            //            int result = n1 / n2;
            //                Console.WriteLine($"Result:{result}");
            //            }
            //            catch (DivideByZeroException de)
            //            {
            //                Console.WriteLine(de.Message);
            //            }
            //            catch (FormatException fe)
            //            {
            //                Console.WriteLine(fe.Message);
            //            }
            //            catch(Exception ex)//all exeptions
            //            {
            //                Console.WriteLine(ex.Message);
            //            }

            //try
            //{
            //    Console.WriteLine("Enter two numbers:");
            //    int n1 = int.Parse(Console.ReadLine());
            //    int n2 = int.Parse(Console.ReadLine());

            //    int result = n1 / n2;
            //    Console.WriteLine($"Result:{result}");
            //}
            //catch 
            //{

            //   Console.WriteLine("Error!");
            //}

            //try
            //{

            //}
            //catch//only if there is mistake
            //{

            //}
            //finally//work all time
            //{

            //}

            //try
            //{

            //}
            //catch (Exception)//only if there is mistake
            //{

            //    throw;
            //}

            //try
            //{

            //}
            //finally//work all time //niet catch exeption
            //{

            //}

            //try
            //{
            //    Console.WriteLine("Enter two numbers:");
            //        int n1 = int.Parse(Console.ReadLine());
            //        int n2 = int.Parse(Console.ReadLine());

            //       int result = n1 / n2;
            //        Console.WriteLine($"Result:{result}");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    Console.WriteLine($"Result");
            //}
            //Console.WriteLine($"Resultqwew");





            //static public int SomeMethod(int x)
            //{
            //    try
            //    {
            //        return 100 / x;
            //    }
            //    catch (DivideByZeroException e)//перехват исключения деления на 0
            //    {
            //        //генерация исключения недопустимого значения аргумента
            //        //исходное исключение передается как внутреннее исключение
            //        throw new ArgumentOutOfRangeException("x can't be 0", e);
            //    }
            //    finally
            //    {
            //        Console.WriteLine("Finally");
            //    }
            //    Console.WriteLine("Bye!"); // никогда не выполниться
            //}

            //static void Main()
            //{
            //    try
            //    {
            //        SomeMethod(0);
            //    }
            //    catch (ArgumentOutOfRangeException e)
            //    {
            //        Console.WriteLine(e.Message);
            //        //вывод внутренного исключения
            //        Console.WriteLine("InnerException: {0}", e.InnerException.Message);
            //    }
            //Console.ReadKey();   
            //}

            //string st = null;
            //try
            //{
            //    Console.WriteLine("Enter two numbers:");
            //    int n1 = int.Parse(Console.ReadLine());
            //    int n2 = int.Parse(Console.ReadLine());

            //    if (n2%2==0)
            //    {
            //        throw new MyException();
            //    }
            //    Divide(n1);
            //    int result = n1 / n2 ;
            //    Console.WriteLine($"Result:{result}");
            //    st = "Hello";
            //    Console.WriteLine(st.Contains(":Hell"));//write always
            //}
            //catch (MyException x)
            //{
            //    Console.WriteLine($"{x.TimeExeption} {x.Message}");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //Console.WriteLine(st.Contains(":Hell"));//if exception niet zie

            //Console.WriteLine("HeLL");


            //-----INFORMATION------
            //Сборщик мусора !! (heap) GC
            //Память(три уровня|| ,,Поколение,, (0,1,2)||):
            // 0.  256KB (кило байт) |
            // 1.  2MB               |
            // 2.  10MB              |
            //object A -> 0 
            // when 0-> full => Входит в игру сборщик мусора
            //if you need object A ,then => A->1 
            //else if niet need -> delete
            //AND 0-> EMPTY
            //when 0-> full  again  
            // 0->1 (0->EMPTY) AND 1->will full 
            //1->2 (1->EMPTY) 
            //when 2->full ,then 
            //if you need -> stay in 2
            //niet need ->delete
            //THEN 2 +...MB  (if we need all object)
            //...MB (то чего не хватает+ запас в 2 раза)
            //GC.Collect();
            //ви си шарп рихтера
            GC.Collect();


            //ДЗ+7 читать лессон!!//Разработать приложение, в котором бы
            //сравнивалось население трёх столиц из
            //разных стран. Причём страна бы обозначалась
            //пространством имён, а город – классом в
            //данном пространстве.
            Console.ReadKey();  }
    }
}
