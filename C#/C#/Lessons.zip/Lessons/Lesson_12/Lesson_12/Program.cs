﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_12
{
    class Example : IDisposable
    {

        //~Example()
        //{
        //    Console.WriteLine("Finalize");
        //}
        private bool disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: освободить управляемое состояние (управляемые объекты)
                }

                // TODO: освободить неуправляемые ресурсы (неуправляемые объекты) и переопределить метод завершения
                // TODO: установить значение NULL для больших полей
                disposedValue = true;
            }
        }

        // // TODO: переопределить метод завершения, только если "Dispose(bool disposing)" содержит код для освобождения неуправляемых ресурсов
        // ~Example()
        // {
        //     // Не изменяйте этот код. Разместите код очистки в методе "Dispose(bool disposing)".
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Не изменяйте этот код. Разместите код очистки в методе "Dispose(bool disposing)".
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrayList = new ArrayList(8);
            arrayList.Add(569);
            Console.WriteLine($"Count: {arrayList.Count}");
            Console.WriteLine($"Capacity: {arrayList.Capacity}");

            arrayList.Add("Ok");
            arrayList.Add(4.123);
            arrayList.Add(true);
            Console.WriteLine($"Count: {arrayList.Count}");
            Console.WriteLine($"Capacity: {arrayList.Capacity}");

            arrayList.Add(new Exception("Error"));
                 Console.WriteLine($"Count: {arrayList.Count}");
            Console.WriteLine($"Capacity: {arrayList.Capacity}");

            arrayList.AddRange(new int[] {67,23,345,66,767,7666 });
            Console.WriteLine($"Count: {arrayList.Count}");
            Console.WriteLine($"Capacity: {arrayList.Capacity}");

            arrayList.TrimToSize();
            Console.WriteLine($"Count: {arrayList.Count}");
            Console.WriteLine($"Capacity: {arrayList.Capacity}");

            foreach(object obj in arrayList)
            {
                Console.WriteLine(obj);
            }

            Stack stack = new Stack();
            stack.Push(arrayList);
            stack.Pop();
            Console.WriteLine();

            
            Console.ReadKey();
        }
    }
}
