﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temat_05pd
{
    struct KeyValueStruct
    {
        public int Key;
        public string Value;

        public static void Sort(KeyValueStruct[] ss)
        {
            //1. Объявить статический метод void Sort(KeyValueStruct[] ss), который упорядочит структуры в массиве по возрастанию ключа.

            for (int i = 0; i < ss.Length; i++)
            {
                for (int j = 0; j < ss.Length - 1 - i; j++)
                {
                    if (ss[j + 1].Key < ss[j].Key) // По возрастанию
                    {

                        //KeyValueStruct tmp = ss[j];
                        //tmp.Key = ss[j].Key;
                        ////tmp = ss[j].Key;
                        //ss[j].Key = ss[j + 1].Key;
                        //ss[j + 1].Key = tmp.Key;
                        //==
                        //KeyValueStruct tmp = ss[i];
                        //tmp = ss[j];
                        //ss[j] = ss[j + 1];
                        //ss[j + 1] = tmp;

                        KeyValueStruct tmp = ss[j + 1];

                        ss[j + 1] = ss[j];
                        ss[j] = tmp;
                    }
                }
            }
        }

        public static int BinarySearch(KeyValueStruct[] ss, int key)
        {
            /*Объявить статический метод int BinarySearch(KeyValueStruct[] ss, int key), 
             который по заданному ключу key находит индекс структуры в массиве ss. 
             Если структуры с заданным ключом нет, метод возвращает -1. Элементы массива упорядочены по возрастанию ключа.*/

            for (int i = 0; i < ss.Length; i++)
            {
                if (ss[i].Key == key)
                {
                    return i;
                }
            }
            //int value = Array.IndexOf(ss, key);
            //return value;
            return -1;
        }

        public static KeyValueStruct[] Merge(KeyValueStruct[] s1, KeyValueStruct[] s2)
        {
            /*3. Объявить статический метод KeyValueStruct[] Merge (KeyValueStruct[] s1, KeyValueStruct[] s2), 
             который сливает два упорядоченных массива структур в третий, тоже упорядоченный. 
             Элементы массивов упорядочены по возрастанию ключа.*/

            KeyValueStruct[] s3 = new KeyValueStruct[s1.Length + s2.Length]; // определяем, насколько большая третья будет
            Array.Copy(s1 , s3, s1.Length); // копируем с первой в третью
            Array.Copy(s2 , 0, s3, s1.Length, s2.Length); // так же и со второй в третью
            KeyValueStruct.Sort(s3); // сортируем нашим методом
            //for (int i = 0; i < s3.Length; i++)
            //{
            //    s3[i] = s1[i];
            //    s3[i + s2.Length] = s2[i];
            //}
            return s3; // подкидываем
        }

        public static void Show(KeyValueStruct[] s) // ДоработОчКа
        {
            for (int i = 0; i < s.Length; i++)
            {
                Console.WriteLine($"{i} {s[i].Key} {s[i].Value}");
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            KeyValueStruct[] a = new KeyValueStruct[4];
            a[0].Key = 5;
            a[0].Value = "Null";
            a[1].Key = 2;
            a[1].Value = "One";
            a[2].Key = 10;
            a[2].Value = "Two";
            a[3].Key = 4;
            a[3].Value = "Three";

            KeyValueStruct[] b = new KeyValueStruct[5];
            b[0].Key = 7;
            b[0].Value = "Bull";
            b[1].Key = 12;
            b[1].Value = "Van";
            b[2].Key = 25;
            b[2].Value = "Too";
            b[3].Key = -9;
            b[3].Value = "Tree";
            b[4].Key = 66;
            b[4].Value = "For";
            KeyValueStruct.Show(a);
            Console.WriteLine("====================================================================\n");
            KeyValueStruct.Sort(a);
            KeyValueStruct.Show(a);

            Console.WriteLine("Indexation: {0}", KeyValueStruct.BinarySearch(a, 2)); // 0
            Console.WriteLine("Indexation: {0}", KeyValueStruct.BinarySearch(a, 0)); // -1
            Console.WriteLine("====================================================================\n");

            KeyValueStruct[] c = KeyValueStruct.Merge(a, b); // Сливаем воедино две структуры в одну
            KeyValueStruct.Show(c);

            Console.ReadKey();
        }
    }
}
