﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RESTAURANT
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Fraction f = new Fraction(3, 4);
            //double d = 1.5;
            //Fraction f3 = f + d;
            //Console.WriteLine("f3 = {0} + {1} = {2};\n", f, d, f3);

            //Fraction f5 = new Fraction(7, 9);
            //Fraction f4 = f - f5;
            //Console.WriteLine("f2 = {0} - {1} = {2};\n", f, f5, f4);
             int menu; int menu1; int menu2;
            Dishes obj = new Dishes();
            List<Dishes> _dish = null;
            List<Menu> _menu = null;
            int prt;
            Client _client = new Client(); 
            Menu _ooo = new Menu();
            Operat_Dishes rep=null;

            string s;string f;
            int pr; string s1;
            string pp;
            int men;
            Dish_client _cl=new Dish_client();
            int u;
            //var returnBack = true;
            do
            {
                Console.WriteLine("\n1.Personal");
                Console.WriteLine("\n2.Guest");
                menu = int.Parse(Console.ReadLine());
                switch (menu)
                {
                    case 1:
                        do
                        {
                            Console.WriteLine("\n1.Add dish");
                            Console.WriteLine("\n2.Del dish");
                            Console.WriteLine("\n3.Save");
                            Console.WriteLine("\n4.Load");
                            Console.WriteLine("\n5.Find");//!
                            Console.WriteLine("\n6.Redaction");//!
                            Console.WriteLine("\n7.Sort");//!
                            Console.WriteLine("\n8.Show All");
                            menu1 = int.Parse(Console.ReadLine());
                            while (menu1 < 0 || menu1 > 9)
                            {
                                Console.Write("Incorrect option. Please Re-Enter: ");
                                menu1 = Convert.ToInt32(Console.ReadLine());
                            }
                            switch (menu1)
                            {
                                case 1:
                                    Console.WriteLine("Input full name:");
                                    s = Console.ReadLine();
                                    if (String.IsNullOrWhiteSpace(s)) throw new Exception();



                                    Console.WriteLine("Input price:");
                                    pr = Convert.ToInt32(Console.ReadLine());
                                    if (pr <= 0)
                                    {
                                        Console.WriteLine("\tSET WRONG NIET NULL!");
                                        pr = Convert.ToInt32(Console.ReadLine());
                                    }


                                    Console.WriteLine("Input Type of dish:\n (Hot  Cold  Decert)\n");

                                    f = Console.ReadLine();
                                    if (f == "cold" || f == "hot" || f == "decert" || f == "Cold" || f == "Hot" || f == "Decert")
                                    {
                                        

                                        _ooo.Add(new Dishes(s, pr, f));
                                        Console.WriteLine("\tadded sucsess!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Wrong Type!");
                                    }
                                     
                                    break; 
                                case 2:
                                    
                                    Console.WriteLine("Input name:");
                                    _ooo.Del(_ooo.FindByName(Console.ReadLine()));
                                    break;
                                case 3:
                                    Console.WriteLine("Input the name of file(for save):");
                                    pp = Console.ReadLine();
                                    pp += ".bin";
                                    _ooo.Save(pp);
                                    Console.WriteLine("\tSAVED SUCSESS!");
                                    break;
                                case 4:
                                   
                                    
                                      Console.WriteLine("Input the name of file(for load):");
                                        s1 = Console.ReadLine();
                                        s1 += ".bin";
                                        _ooo.Load(s1);
                                        Console.WriteLine("\tLOADED SUCSESS!");
                                   
                                    break;
                                case 5:
                                    do
                                    {
                                        Console.WriteLine("\n-----FIND------");
                                        Console.WriteLine("\n1.Find By Name");
                                        Console.WriteLine("\n2.Find By Price");
                                        Console.WriteLine("\n3.Find By Type");
                                        men = int.Parse(Console.ReadLine());
                                        switch (men)
                                        {
                                            case 1:
                                                Console.WriteLine("Input name:");
                                                _ooo.ShowNaamDish((Console.ReadLine()));
                                                break;
                                            case 2:
                                                Console.WriteLine("Input price:");
                                                _ooo.ShowPriceDish(int.Parse(Console.ReadLine()));
                                                //Console.WriteLine(_ooo.FindByPricer(int.Parse(Console.ReadLine())));
                                                break;
                                                case 3:
                                                Console.WriteLine("Input type:");
                                                _ooo.ShowTypeDish((Console.ReadLine()));
                                                break;

                                            default:
                                                if (menu > 3 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");

                                                break;
                                        }

                                    } while (men!=0);
                                   
                                    break;
                                case 6:
                                    Console.WriteLine("Input name:");
                                    _ooo.EditInfo(_ooo.FindByName(Console.ReadLine()));
                                    break;
                                case 7:do
                                    {
                                        Console.WriteLine("\n-----SORT------");
                                        Console.WriteLine("\n1.Sort by Name");
                                        Console.WriteLine("\n2.Sort by Price");
                                        Console.WriteLine("\n3.Sort by type");
                                        men = int.Parse(Console.ReadLine());
                                        switch (men)
                                        {
                                            case 1:
                                                _ooo.SortListByFullName();
                                                break;
                                                case 2:
                                                _ooo.SortListByPrice();
                                                break;
                                                case 3:
                                                _ooo.SortListByType_dish();
                                                    break;
                                            default:
                                                if (menu > 3 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");

                                                break;
                                        }

                                    } while (men!=0);

                                    break;
                                case 8:
                                    _ooo.ShowAll();   
                                    break;
                               
                                default:
                                    if (menu > 8 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");

                                    break;
                            }
                        } while (menu!=0); 
                   break;
                  case 2:
                        do
                        {
                            Console.WriteLine("\n1.Take dish");
                            Console.WriteLine("\n2.Show your dishes");
                            Console.WriteLine("\n3.Show chek");
                                Console.WriteLine("\n4.Load dishes from menu");
                                Console.WriteLine("\n5.Show All");
                            Console.WriteLine("\n6.Load dishes from client");
                            Console.WriteLine("\n7.Save dishes from client");
                            menu2 = int.Parse(Console.ReadLine());
                            switch (menu2)
                            {
                                case 1:
                                    Console.WriteLine("Input full name:");
                                    s = Console.ReadLine();
                                    if (String.IsNullOrWhiteSpace(s)) throw new Exception();



                                    Console.WriteLine("Input price:");
                                    pr = Convert.ToInt32(Console.ReadLine());
                                    if (pr <= 0)
                                    {
                                        Console.WriteLine("\tSET WRONG NIET NULL!");
                                        pr = Convert.ToInt32(Console.ReadLine());
                                    }


                                    Console.WriteLine("Input Type of dish:\n (Hot  Cold  Decert)\n");

                                    f = Console.ReadLine();
                                    if (f == "cold" || f == "hot" || f == "decert" || f == "Cold" || f == "Hot" || f == "Decert")
                                    {


                                        Console.WriteLine("Input amount of dishes:");
                                        prt = Convert.ToInt32(Console.ReadLine());
                                        if (prt <= 0)
                                        {
                                            Console.WriteLine("\tSET WRONG NIET NULL!");
                                            prt = Convert.ToInt32(Console.ReadLine());
                                        }
                                        _ooo.FindFull(s, pr, f);
                                        _cl.Add(new Client(s,pr,f,prt));
                                        Console.WriteLine("\tadded sucsess!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Wrong Type!");
                                    }
                                    



                                    break;
                                case 2:
                                    _cl.ShowAll();
                                    break;
                                case 3:

                                    _cl.ShowAllPrice_Check(_client);
                                    break;
                                    case 4:
                                        Console.WriteLine("Input the name of file(for load):");
                                        s1 = Console.ReadLine();
                                        s1 += ".bin";
                                        _ooo.Load(s1);
                                        Console.WriteLine("\tLOADED SUCSESS!");

                                    break;
                                case 5:
                                    _ooo.ShowAll();
                                    break;
                                case 6:
                                    Console.WriteLine("Input the name of file(for load):");
                                    s1 = Console.ReadLine();
                                    s1 += ".bin";
                                    _cl.Load(s1);
                                    Console.WriteLine("\tLOADED SUCSESS!");
                                    break;
                                    case 7:
                                    Console.WriteLine("Input the name of file(for save):");
                                    pp = Console.ReadLine();
                                    pp += ".bin";
                                    _cl.Save(pp);
                                    Console.WriteLine("\tSAVED SUCSESS!");
                                    break;

                                default:
                                    break;
                            }
                        } while ( menu != 0 );
                  break;
                    
                    default:
                        break;
                }                                     /**/    
            } while ( menu != 0);

        }
    }
}
