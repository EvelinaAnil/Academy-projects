﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RESTAURANT
{
   
        class Fraction
        {
            public int numerator;
            private int denominator;

            public Fraction(int x, int y)
            {
                numerator = x;
                denominator = y;
            }

            public override string ToString()
            {
                return string.Format("({0} / {1})",
                    numerator, denominator);
            }



        //public static explicit operator double(Dishes obj)
        //{
        //    return obj.price;
        //}

        public static Fraction operator +(Fraction a, Fraction b)
            {
                Fraction z = new Fraction(a.numerator * b.denominator
                    + b.numerator * a.denominator,
                    a.denominator * b.denominator);

                while (true)
                {
                    if (z.numerator % 10 == 0 && z.denominator % 10 == 0)
                    {
                        z.numerator = z.numerator / 10;
                        z.denominator = z.denominator / 10;
                    }
                    else break;
                }
                return z;
            }

            public static Fraction operator -(Fraction a, Fraction b)
            {
                return new Fraction(a.numerator * b.denominator
                    - b.numerator * a.denominator,
                    a.denominator * b.denominator);
            }

            public static Fraction operator *(Fraction a, Fraction b)
            {
                return new Fraction(a.numerator * b.numerator,
                    a.denominator * b.denominator);
            }

           

            public override bool Equals(object obj)
            {
                if (obj == null) return false;
                Fraction p = obj as Fraction;
                if (p == null) return false;
                return ((numerator == p.numerator)
                    && (denominator == p.denominator));
            }

            public override int GetHashCode()
            {
                return numerator ^ denominator;
            }

           

        }
    }

