﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace RESTAURANT
{
    [Serializable]
    class Dish_client
    { Dishes obj_;
        Client obj;
        private List<Dishes> _dish = null;
        private List<Client> _client = null;
        int j = 0;
        //private  List<Dish_client> = null;
        public Dish_client()
        {
            _dish = new List<Dishes>();
            _client=new List<Client>();
        }
        public void ShowAll()
        {
            if (_client.Count > 0)
            {
                for (int i = 0; i < _client.Count; i++)
                {
                    Console.WriteLine($"\tDish Client # {i + 1}");
                    _client[i].ShowClient();
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("\tLIST IS EMPTY!!");
            }

        }
        public void ShowAllPrice_Check(Client obj)
        {
          
            
            if (_client.Count > 0)
            {
                for ( int i = 0; i < _client.Count; i++)
                {int f;int j = 0;
                    
                  f= _client[i].AmountOfDishes * _client[i].price_Client;
                    j = j + f;
                    Console.WriteLine();
                    i++;
                }
                Console.WriteLine($"All price:{j}");
            }
            else
            {
                Console.WriteLine("\tLIST IS EMPTY!!");
            }

        }
            public int FindByName(string rt)
        {
            foreach (Dishes r in _dish)
            {
                if (r.Name_dish == rt)
                {
                    return _dish.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE Name WAS NOT FOUND");
        }
        public void ShowNaamCl_Dish(string rt)
        {
            _dish[FindByName(rt)].Show();
        }
        public void Add(Client obj)
        {
            _client.Add(obj);

        }
        //---
        public void Save(string path)
        {
            using (var fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, _dish);
            }
        }
        public void Load(string path)
        {
            List<Client> tmp = new List<Client>();
            try
            {
                using (var fr = new FileStream(path, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    tmp = bf.Deserialize(fr) as List<Client>;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            _client = tmp;
        }
    }
}
