﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace RESTAURANT
{
    [Serializable]
    internal class Menu
    {
        
        private List<Dishes> _dish = null;
        int allprice;
        Dishes op=new Dishes();
        public Menu()
        {
            _dish = new List<Dishes>();
        }
        enum DataTime{
            Morgen,
            Day,
            Evening
        }
        //
        //public void Add_(Menu obj)
        //{
        //    _menu.Add(obj);

        //    allprice = allprice + op.price;
        //}
        //public void AllPricee()
        //{
        //    Console.WriteLine("All Price:", allprice);
        //   _menu.Clear();
        //}
        //public void Delll(int id)
        //{
        //    _menu.RemoveAt(id);
        //}
        //
        public void ShowAll()
        {
            if (_dish.Count > 0)
            {
                for (int i = 0; i < _dish.Count; i++)
                {
                    Console.WriteLine($"\tDish # {i + 1}");
                    _dish[i].Show();
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("\tLIST IS EMPTY!!");
            }

        }
        public void ShowTime()
        { 
           // DateTime time =DateTime.Now.ToShortTimeString() /*DateTime.Now.GetDateTimeFormats('T')[0]*/;
           //DateTime time_6 = DateTime.Now.GetDateTimeFormats('T')[6];
           // DateTime time_12 = DateTime.Now.GetDateTimeFormats('T')[12];
           // DateTime time_4 = DateTime.Now.GetDateTimeFormats('T')[4];
           // DateTime time_23 = DateTime.Now.GetDateTimeFormats('T')[23];
            //Console.WriteLine("The current time is {0}", time);
            //if (i.CompareTo(DateTime _op) >= time_6 && _op <= time_12 )
                if(DateTime.Now.Hour<= 6 && DateTime.Now.Hour>=12)
                {
                Console.WriteLine(DataTime.Morgen.ToString());
                }
            if (DateTime.Now.Hour <= 12 && DateTime.Now.Hour >= 16)
            {
                Console.WriteLine(DataTime.Day.ToString());
            }
            if (DateTime.Now.Hour <= 16 && DateTime.Now.Hour >= 23)
            {
                Console.WriteLine(DataTime.Evening.ToString());
            }

        }
        
        //----
        public void SortListByFullName()
        {
            _dish.Sort(SortByFullName);
        }
        public void SortListByPrice()
        {
            _dish.Sort(SortByPrice);
        }
        public void SortListByType_dish()
        {
            _dish.Sort(SortByType_dish);
        }
        private static int SortByFullName(Dishes f, Dishes s)
        {
            return f.Name_dish.CompareTo(s.Name_dish);
        }
        private static int SortByPrice(Dishes f, Dishes s)
        {
            return f.price.CompareTo(s.price);
        }
        private static int SortByType_dish(Dishes f, Dishes s)
        {
            return f.Type_dish.CompareTo(s.Type_dish);
        }

        public int FindByName(string fullName)
        {
            foreach (Dishes r in _dish)
            {
                if (r.Name_dish == fullName)
                {
                    return _dish.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE Name WAS NOT FOUND");
        }
        public void FindFull(string fullName, int pr, string x)
        {
            foreach (Dishes r in _dish)
            {
                if (r.Name_dish == fullName &&
                    r.price == pr
                    && r.Type_dish == x)
                {

                     r.Show();
                    Console.WriteLine("Yes");
                }
            }
        }
        public int FindByPricer(int fullName)
        {
            foreach (Dishes r in _dish)
            {
                if (r.price == fullName)
                {
                    return _dish.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE Price WAS NOT FOUND");
        }
        public int FindByType(string x)
        {

            //int menu = 0;
            foreach (Dishes r in _dish)
            {
                if (r.Type_dish == x || r.Type_dish == x)
                {
                    return _dish.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE Type WAS NOT FOUND");

        }
        
        //----- allprice= allprice + obj.price;
        public void Add(Dishes obj)
        {
            _dish.Add(obj);
          
        }
        
        public void ShowPriceDish(int fullName)
        {
            _dish[FindByPricer(fullName)].Show();
        }
        public void ShowNaamDish(string fullName)
        {
            _dish[FindByName(fullName)].Show();
        }
        public void ShowTypeDish(string fullName)
        {
            _dish[FindByType(fullName)].Show();
        }
        public void Del(int id)
        {
            
            _dish.RemoveAt(id);
            Console.WriteLine("\tDELETE SUCSESS!");
        }
        public void EditInfo(int id)
        {
            Dishes obj = _dish[id];
            int menu;
            do {
                Console.WriteLine("\tMENU FOR CHANGING INFORMATION");
                Console.WriteLine("1) ALL NAME");
                Console.WriteLine("2) PRICE");
                Console.WriteLine("3) TYPE");
                Console.WriteLine("4) ALL INFORMATION");
                menu = int.Parse(Console.ReadLine());
                switch (menu)
                {
                    case 1:
                        try
                        {
                            Console.WriteLine("Input Name of dish:");
                            obj.Name_dish = Console.ReadLine();

                            Console.WriteLine("\tSET SUCSESS!");



                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 2:
                        try
                        {
                            Console.WriteLine("Input price:");
                            obj.price = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("\tSET SUCSESS!");



                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 3:
                        try
                        {
                            Console.WriteLine("Input Type of dish:\n (Hot  Cold  Decert)\n");

                            obj.Type_dish = Console.ReadLine();

                            if (obj.Type_dish != "cold" || obj.Type_dish != "hot" || obj.Type_dish != "decert" || obj.Type_dish != "Cold" || obj.Type_dish != "Hot" || obj.Type_dish != "Decert")
                            {
                                Console.WriteLine("\tSET WRONG TYPE!");
                                obj.Type_dish = Console.ReadLine();
                            }
                            else
                            {
                                Console.WriteLine("\tSET SUCSESS!");
                            }




                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;





                    case 4:
                        try
                        {
                            Console.WriteLine("Input full name:");
                            obj.Name_dish = Console.ReadLine();




                            Console.WriteLine("Input price:");
                            obj.price = Convert.ToInt32(Console.ReadLine());
                            if (obj.price <= 0)
                            {
                                Console.WriteLine("\tSET WRONG NIET NULL!");
                                obj.price = Convert.ToInt32(Console.ReadLine());
                            }


                            Console.WriteLine("Input type:");
                            obj.Type_dish = Console.ReadLine();
                            if (obj.Type_dish != "cold" || obj.Type_dish != "hot" || obj.Type_dish != "decert" || obj.Type_dish != "Cold" || obj.Type_dish != "Hot" || obj.Type_dish != "Decert")
                            {
                                Console.WriteLine("\tSET WRONG TYPE! ('cold' 'hot' 'decert')"); obj.Type_dish = Console.ReadLine();
                            }

                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    default:
                        if (menu > 5 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
                        break;
                }
            } while (menu != 0);
        }
        //----

        public void Save(string path)
        {
            using (var fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, _dish);
            }
        }
        public void Load(string path)
        {
            List<Dishes> tmp = new List<Dishes>();
            try
            {
                using (var fr = new FileStream(path, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    tmp = bf.Deserialize(fr) as List<Dishes>;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            _dish = tmp;
        }
    }
}
