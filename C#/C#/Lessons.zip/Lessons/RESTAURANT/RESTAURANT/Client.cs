﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RESTAURANT
{    [Serializable]
     class Client 
    {   Dishes obj;
        private List<Dishes> _dish = null;

        //public void ShowAllClientOrder()
        //{
        //    if (_dish.Count > 0)
        //    {
        //        for (int i = 0; i < _dish.Count; i++)
        //        {
        //            Console.WriteLine($"\tDish # {i + 1}");
        //            _dish[i].Show(); //?
        //            Console.WriteLine();
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("\tLIST IS EMPTY!!");
        //    }

        //}
        //-----
        public int FindByName(string fullName)
        {
            foreach (Dishes r in _dish)
            {
                if (r.Name_dish == fullName)
                {
                    return _dish.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE Name WAS NOT FOUND");
        }
        public void ShowNaamClDish(string fullName)
        {
            _dish[FindByName(fullName)].Show();
        }

        public string Name_Clientdish { get; set; }
            public int price_Client { get; set; }
            public string Type_dish_Client { get; set; }
        public int AmountOfDishes { get; set; }

        public void SetClName(string n)
            {

            Name_Clientdish = n;

            }
            public string GetClName()
            {
                return Name_Clientdish;
            }
            public void SetClPrice(int n)
            {

            price_Client = n;
                if (n <= 0) throw new Exception();
            }
            public int GetClPrice()
            {
                return price_Client;
            }
        public void SetClAmount(int n)
        {

            AmountOfDishes = n;
            if (n <= 0) throw new Exception();
        }
        public int GetClAmount()
        {
            return AmountOfDishes;
        }
        public void SetClType(string n)
            {

            Type_dish_Client = n;
                if (String.IsNullOrWhiteSpace(Type_dish_Client)) throw new Exception();
                if (n != "cold" || n != "hot" || n != "decert" || n != "Cold" || n != "Hot" || n != "Decert") throw new Exception();
            }
            public string GetClType()
            {
                return Type_dish_Client;
            }



            public Client(string name, int _price, string _type,int amount)
           
            {
            Name_Clientdish = name;
            price_Client = _price;
            Type_dish_Client = _type;
            AmountOfDishes= amount;
            }
       
        public Client()
            {
            Name_Clientdish = "";
            price_Client = 0;
            Type_dish_Client = "";
            }
            public void ShowClient()
            {
                Console.WriteLine($"---------DISH--------- \nName:{Name_Clientdish}" + $" \nPrice:{price_Client}" + $" \nType:{Type_dish_Client} " 
                    + $"\nAmount of dishes:{AmountOfDishes}");
            }
        }
    
}
