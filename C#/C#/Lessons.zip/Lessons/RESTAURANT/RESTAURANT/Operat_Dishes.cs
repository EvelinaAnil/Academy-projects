﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace RESTAURANT
{
    internal class Operat_Dishes
    {
        private List<Dishes> _dish = null;
        public Operat_Dishes()
        {
            _dish = new List<Dishes>();
        }
        //public void Add(Dishes obj)
        //{
        //    _dish.Add(obj);
        //}
        //public void Del(int id)
        //{
        //    _dish.RemoveAt(id);
        //    Console.WriteLine("\tDELETE SUCSESS!");
        //}
        //public void EditInfo(int id)
        //{
        //    Dishes obj = _dish[id];
        //    int menu;
        //    do
        //    {
        //        //do
        //        //{
        //            //    switch (menu)
        //            //    {
        //            //        case 1:
        //            //            break;
        //            //        default:
        //            //            if (menu > 5 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
        //            //            break;
        //            //    }
        //            //} while (menu != 0);
        //            Console.WriteLine("\tMENU FOR CHANGING INFORMATION");
        //            Console.WriteLine("1) ALL NAME");
        //            Console.WriteLine("2) PRICE");
        //            Console.WriteLine("3) TYPE");
        //            Console.WriteLine("4) ALL INFORMATION");
        //            menu = int.Parse(Console.ReadLine());
        //            switch (menu)
        //            {
        //                case 1:
        //                    try
        //                    {
        //                        Console.WriteLine("Input Name of dish:");
        //                        obj.Name_dish = Console.ReadLine();

        //                        Console.WriteLine("\tSET SUCSESS!");



        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        Console.WriteLine(ex.Message);
        //                    }
        //                    break;

        //                case 2:
        //                    try
        //                    { Console.WriteLine("Input price:");
        //                        obj.price = Convert.ToInt32(Console.ReadLine());

        //                        Console.WriteLine("\tSET SUCSESS!");



        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        Console.WriteLine(ex.Message);
        //                    }
        //                    break;

        //                case 3:
        //                    try
        //                    {
        //                        Console.WriteLine("Input Type of dish:\n (Hot  Cold  Decert)\n");

        //                        obj.Type_dish = Console.ReadLine();

        //                        if (obj.Type_dish != "cold" || obj.Type_dish != "hot" || obj.Type_dish != "decert" || obj.Type_dish != "Cold" || obj.Type_dish != "Hot" || obj.Type_dish != "Decert")
        //                        {
        //                            Console.WriteLine("\tSET WRONG TYPE!");
        //                            obj.Type_dish = Console.ReadLine();
        //                        }
        //                        else
        //                        {
        //                            Console.WriteLine("\tSET SUCSESS!");
        //                        }




        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        Console.WriteLine(ex.Message);
        //                    }
        //                    break;





        //                case 4:
        //                    try
        //                    {
        //                        Console.WriteLine("Input full name:");
        //                        obj.Name_dish = Console.ReadLine();




        //                        Console.WriteLine("Input price:"); 
        //                        obj.price = Convert.ToInt32(Console.ReadLine());
        //                        if (obj.price <= 0) {
        //                            Console.WriteLine("\tSET WRONG NIET NULL!");
        //                            obj.price = Convert.ToInt32(Console.ReadLine()); }


        //                        Console.WriteLine("Input type:");
        //                    obj.Type_dish = Console.ReadLine();
        //                    if (obj.Type_dish != "cold" || obj.Type_dish != "hot" || obj.Type_dish != "decert" || obj.Type_dish != "Cold" || obj.Type_dish != "Hot" || obj.Type_dish != "Decert")
        //                    {
        //                        Console.WriteLine("\tSET WRONG TYPE! ('cold' 'hot' 'decert')"); obj.Type_dish = Console.ReadLine();
        //                    }

        //                }
        //                    catch (Exception ex)
        //                    {
        //                        Console.WriteLine(ex.Message);
        //                    }
        //                    break;

        //                default:
        //                    if (menu > 5 || menu != 0 || menu < 0) Console.WriteLine("\tWRONG MENU!\n");
        //                    break;
        //            }
        //        } while (menu != 0);
        //    }
        //public void SortListByFullName()
        //{
        //    _dish.Sort(SortByFullName);
        //}
        //public void SortListByPrice()
        //{
        //    _dish.Sort(SortByPrice);
        //}
        //public void SortListByType_dish()
        //{
        //    _dish.Sort(SortByType_dish);
        //}
        //private static int SortByFullName(Dishes f, Dishes s)
        //{
        //    return f.Name_dish.CompareTo(s.Name_dish);
        //}
        //private static int SortByPrice(Dishes f, Dishes s)
        //{
        //    return f.price.CompareTo(s.price);
        //}
        //private static int SortByType_dish(Dishes f, Dishes s)
        //{
        //    return f.Type_dish.CompareTo(s.Type_dish);
        //}

        public int FindByName(string fullName)
        {
            foreach (Dishes r in _dish)
            {
                if (r.Name_dish == fullName)
                {
                    return _dish.IndexOf(r);
                }
            }
            throw new Exception($"\tTHE Name WAS NOT FOUND");
        }
        //public int FindByPricer(int fullName)
        //{
        //    foreach (Dishes r in _dish)
        //    {
        //        if (r.price == fullName)
        //        {
        //            return _dish.IndexOf(r);
        //        }
        //    }
        //    throw new Exception($"\tTHE Price WAS NOT FOUND");
        //}
        //public int FindByType(string x)
        //{

        //    int menu = 0;
        //    foreach (Dishes r in _dish)
        //    {
        //        if (r.Type_dish == x || r.Type_dish == x)
        //        {
        //            return _dish.IndexOf(r);
        //        }
        //    }
        //    throw new Exception($"\tTHE Type WAS NOT FOUND");

        //}

        //public void ShowRacer(string fullName)
        //{
        //    _dish[FindByName(fullName)].Show();
        //}
        //public void ShowAll()
        //{
        //    if (_dish.Count > 0)
        //    {
        //        for (int i = 0; i < _dish.Count; i++)
        //        {
        //            Console.WriteLine($"\tDish # {i + 1}");
        //            _dish[i].Show();
        //            Console.WriteLine();
        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("\tLIST IS EMPTY!!");
        //    }

        //}
        //public void Save(string path)
        //{
        //    using (var fs = new FileStream(path, FileMode.OpenOrCreate))
        //    {
        //        BinaryFormatter bf = new BinaryFormatter();
        //        bf.Serialize(fs, _dish);
        //    }
        //}
        //public void Load(string path)
        //{
        //    List<Dishes> tmp = new List<Dishes>();
        //    try
        //    {
        //        using (var fr = new FileStream(path, FileMode.Open))
        //        {
        //            BinaryFormatter bf = new BinaryFormatter();
        //            tmp = bf.Deserialize(fr) as List<Dishes>;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    _dish = tmp;
        //}
    }
}

