﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace RESTAURANT
{
    [Serializable]
    class Dishes
    {
        public string Name_dish { get; set; }
        public int price { get; set; }
        public string Type_dish { get; set; }
        // («холодное», «горячее», «десерт»)

        //enum Time
        //{
        //    Morning,
        //        Day,
        //        Evening
        //}
        
        public void SetName(string n)
    {
           
            Name_dish = n;
            
    }
    public string GetName()
    {
        return Name_dish;
    }
        public void SetPrice(int n)
        {

            price = n;
            if(n<=0) throw new Exception();
        }
        public int GetPrice()
        {
            return price;
        }
        public void SetType(string n)
        {

            Type_dish = n;
            if (String.IsNullOrWhiteSpace(Type_dish)) throw new Exception();
            if (n != "cold" || n != "hot" || n != "decert" || n != "Cold" || n != "Hot" || n != "Decert") throw new Exception();
        }
        public string GetType()
        {
            return Type_dish;
        }



        public Dishes(string name, int _price, string _type)
        {
            Name_dish = name;
            price = _price;
            Type_dish = _type;
        }
        public Dishes()
        {
            Name_dish = "";
            price = 0;
            Type_dish = "";
        }
        public void Show()
        {
            Console.WriteLine($"---------DISH--------- \nName:{Name_dish}" + $" \nPrice:{price}" +$" \nType:{Type_dish} ");
        }
    }
    
}
