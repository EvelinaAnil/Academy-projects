﻿







using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Text;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Diagnostics;

namespace ConsoleApp
{
    //[Serializable]
    internal delegate void VoidDelegate();
    delegate int IntDelegate(int x, int y);
    //MulticastDelegate
    [DataContract]
    public class Person
    {
       


        [NonSerialized]
        private const string Planet = "Earth";

        [DataMember]
        private int _id;
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int Age { get; set; }

        public Person()
        {
            _id = new Random().Next(1000, 10000);
        }

        public override string ToString()
        {
            return $"{_id} {Name} {Age} {Planet}";
        }
    }

   
    public class Program
    {
        private static void Hello()
        {
            Console.WriteLine("HEllO");
        }
        public static void Main()
        {
            VoidDelegate voidDelegate = new VoidDelegate(Program.Hello);
            voidDelegate();
            //Calculator calculator= new Calculator();
            //IntDelegate intDelegate = new IntDelegate(calculator.Add);

            //++Class Calculator EVELINA!!!!!!!!!!!!!!!!!!!

            //intDelegate += calculator.Sub;
            //intDelegate -= calculator.Sub;
            //intDelegate += Calculator.Mult;
            //intDelegate += calculator.Div;
            //Console.WriteLine( intDelegate(45, 7));



            Person person = new Person { Age = 37, Name = "Geena" };
            Console.WriteLine(person);
            
            /* Simple Object Access Protocol (SOAP)

            SoapFormatter formatter = new SoapFormatter();

            try
            {
                using (FileStream stream = File.Create("Test.soap"))
                {
                    formatter.Serialize(stream, person);
                }
                Console.WriteLine("\nSerialize OK!\n");

                Person p = null;
                using (FileStream stream = File.OpenRead("Test.soap"))
                {
                    p = formatter.Deserialize(stream) as Person;
                }
                Console.WriteLine(p);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            */

            /* eXtensible Markup Language (XML)

            XmlSerializer formatter = new XmlSerializer(person.GetType()); // typeof(Person)

            try
            {
                using (FileStream stream = File.Create("Test.xml"))
                {
                    formatter.Serialize(stream, person);
                }
                Console.WriteLine("\nSerialize OK!\n");

                Person p = null;
                using (FileStream stream = File.OpenRead("Test.xml"))
                {
                    p = formatter.Deserialize(stream) as Person;
                }
                Console.WriteLine(p);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            */

            List<Person> people = new List<Person>
            {
                new Person{ Name = "Jack", Age = 45 },
                new Person{ Name = "Bob", Age = 18 },
                new Person{ Name = "Nick", Age = 21 }
            };

            XmlSerializer formatter = new XmlSerializer(typeof(List<Person>));

            try
            {
                using (FileStream stream = File.Create("TestList.xml"))
                {
                    formatter.Serialize(stream, people);
                }
                Console.WriteLine("\nSerialize OK!\n");

                List<Person> list = null;
                using (FileStream stream = File.OpenRead("TestList.xml"))
                {
                    list = formatter.Deserialize(stream) as List<Person>;
                }
                foreach (Person p in list)
                {
                    Console.WriteLine(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //JavaScript Obgect Notation (JSON)
            DataContractJsonSerializer formaer = new DataContractJsonSerializer(person.GetType());

            try
            {
                using (FileStream stream = File.Create("TestList.xml"))
                {
                    formaer.WriteObject(stream, people);
                }
                Console.WriteLine("\nSerialize OK!\n");

                List<Person> list = null;
                using (FileStream stream = File.OpenRead("TestList.xml"))
                {
                    list = formaer.ReadObject(stream) as List<Person>;
                }
                foreach (Person p in list)
                {
                    Console.WriteLine(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}