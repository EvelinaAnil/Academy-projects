# Card-Game
The card game War written as a C# console app (just because).

A C# version of the old card game "War" in which two players recieve one half of a randomized set of cards sourced from a single 52 card deck. The goal of the game is to lose all of your cards before your opponent. The game does not have much strategy involved but it's faithful to the origin card game, which doesn't have much strategy either.
